"""Schemas for motif system"""

