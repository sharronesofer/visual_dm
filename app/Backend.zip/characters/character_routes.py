
#This route file handles character creation, loading, and listing by integrating CharacterBuilder logic and saving/loading from Firebase. It is tightly coupled to asset and firebase systems and acts as a core entry point for character management.

from flask import current_app
from app.visuals.tile_utils import reveal_tile_to_player
from flask import Blueprint, request, jsonify
from app.characters.character_utils import (
    build_character_from_input,
)
from app.characters.character_utils import (
    save_character_to_firebase,
    load_character_from_firebase
)
from firebase_admin import db
from uuid import uuid4
import random
from datetime import datetime
from app.combat.combat_utils import generate_scaled_encounter
from app.quests.player_arc_utils import generate_character_arc

character_bp = Blueprint("character", __name__)

@character_bp.route('/move_player', methods=['POST'])
def move_player():
    data = request.get_json(force=True)
    character_id = data.get("character_id")
    new_location = data.get("new_location")

    if not character_id or not new_location:
        return jsonify({"error": "character_id and new_location are required"}), 400

    character_ref = db.reference(f"/players/{character_id}")
    character = character_ref.get() or {}

    prev_location = character.get("location", "0_0")

    def parse_coords(loc):
        try:
            return map(int, loc.split("_"))
        except:
            return None, None

    x1, y1 = parse_coords(prev_location)
    x2, y2 = parse_coords(new_location)

    if None in [x1, y1, x2, y2]:
        return jsonify({"error": "Invalid coordinate format. Expected 'x_y'."}), 400

    path = []
    dx = x2 - x1
    dy = y2 - y1
    steps = max(abs(dx), abs(dy))
    for i in range(1, steps + 1):
        x = x1 + round(i * dx / steps)
        y = y1 + round(i * dy / steps)
        path.append(f"{x}_{y}")

    combat_info = None

    for coord_key in path:
        x, y = map(int, coord_key.split("_"))

        # --- Terrain Check ---
        terrain = db.reference(f"/terrain_map/{coord_key}").get()
        if not terrain:
            from worldgen import choose_land_type
            region_id = character.get("region_id", "default")
            terrain = choose_land_type(x, y, region_id)

        # --- Tile Data Check ---
        tile_ref = db.reference(f"/locations/{coord_key}")
        tile_data = tile_ref.get() or {}

        if "danger_level" not in tile_data:
            from worldgen import roll_danger_for_tile
            tile_data["danger_level"] = roll_danger_for_tile(x, y)

        if "POI" not in tile_data:
            from worldgen import should_generate_poi
            if should_generate_poi(x, y):
                # 🧠 Trigger GPT POI generation (hook this to your existing GPT poi builder)
                tile_data["POI"] = True
                tile_data["description"] = "A mysterious location shrouded in fog."
                tile_data["terrain"] = terrain
                tile_data["region_id"] = character.get("region_id", "default")
                # Expand: generate name, buildings, lore, etc.

        tile_ref.set(tile_data)

        # --- Combat Chance Check ---
        danger = tile_data.get("danger_level", 0)
        combat_chance = danger * 7.5
        roll = random.randint(0, 99)

        if roll < combat_chance:
            # COMBAT TRIGGERED!
            encounter = generate_scaled_encounter(character_id, coord_key, danger)

            character["location"] = coord_key
            character_ref.set(character)

            return jsonify({
                "combat_triggered": True,
                "combat_tile": coord_key,
                "combat_roll": roll,
                "combat_chance_percent": combat_chance,
                "encounter": encounter
            })

    # If survived whole path without combat
    character["location"] = new_location
    character_ref.set(character)

    return jsonify({
        "combat_triggered": False,
        "new_location": new_location,
        "character_state": character
    })

@character_bp.route("/character/create", methods=["POST"])
def create_character():
    try:
        from app.rules.character_gen_rules_utils import validate_character_creation

        data = request.get_json(force=True)
        print("📥 Incoming raw data:", data)

        # Build character
        character = build_character_from_input(data)
        print("✅ Built character:", character)

        # Validation
        validation = validate_character_creation(character)
        if not validation["valid"]:
            print("❌ Validation errors:", validation["errors"])
            return jsonify({"errors": validation["errors"]}), 400

        # Default starting tile (can be replaced later)
        character.setdefault("position", {"x": 0, "y": 0})
        character.setdefault("known_coordinates", ["0_0"])

        # Ensure region_id
        character.setdefault("region_id", "capital_hub")

        # Save character background if generated
        if "background" not in character and "background" in data:
            character["background"] = data["background"]

        # Character ID assignment
        character_id = character.get("character_id")
        if not character_id:
            character_id = "char_" + uuid.uuid4().hex[:8]
            character["character_id"] = character_id
            print(f"📛 Auto-generated character ID: {character_id}")

        # Save to Firebase
        save_character_to_firebase(character_id, character)

        # Optional: Generate character arc
        generate_character_arc(character_id, character)

        print("✅ Character saved and setup complete.")
        return jsonify(character), 200

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@character_bp.route("/character/<character_id>", methods=["GET"])
def load_character(character_id):
    """
    Loads a character from Firebase based on character_id.
    """
    try:
        character = load_character_from_firebase(character_id)
        if not character:
            return jsonify({"error": f"Character '{character_id}' not found."}), 404
        return jsonify(character), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@character_bp.route('/character/all', methods=['GET'])
def list_all_characters():
    try:
        ref = db.reference('/players')  # 🔥 Was /characters — now /players
        all_chars = ref.get() or {}
        summaries = []

        for char_id, data in all_chars.items():
            summaries.append({
                "character_id": char_id,
                "character_name": data.get("character_name", "Unknown"),
                "race": data.get("race", "???"),
                "region_id": data.get("region_id", "unknown"),
                "level": data.get("level", 1)
            })

        return jsonify(summaries)

    except Exception as e:
        from flask import current_app
        current_app.logger.error("Error listing characters: %s", str(e))
        return jsonify({"error": str(e)}), 500

@character_bp.route("/character/delete/<character_id>", methods=["DELETE"])
def delete_character(character_id):
    try:
        db.reference(f"/players/{character_id}").delete()
        return jsonify({"message": f"Character '{character_id}' deleted successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500


