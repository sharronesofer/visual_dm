
#This module acts as the character management engine—handling character construction, save/load to Firebase, and performing skill checks. It acts as the bridge between frontend inputs, the builder class, and persistent backend storage.

import os
import json
import random
from firebase_admin import db
from app.characters.character_builder_class import CharacterBuilder
from datetime import datetime
import os
from app.rules.character_gen_rules_utils import (
    load_feat_data, load_starter_kits, load_race_data, load_skill_list
)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
RULES_PATH = os.path.join(PROJECT_ROOT, "rules_json")

# === CHARACTER CREATION ===
def assign_skills(self, skills: dict):
    for skill, rank in skills.items():
        self.skills[skill] = rank



def build_character_from_input(input_data: dict) -> dict:
    race_data = load_race_data()
    feat_data = load_feat_data()
    skill_list = load_skill_list()
    starter_kits = load_starter_kits()

    builder = CharacterBuilder(race_data, feat_data, skill_list)

    # Patch for frontend sending skills as list instead of dict
    if isinstance(input_data.get("skills"), list):
        input_data["skills"] = {skill_name: 1 for skill_name in input_data["skills"]}

    builder.load_from_input(input_data)

    if not builder.is_valid():
        raise ValueError("Character validation failed.")

    character = builder.to_dict()

    # Handle starter kit if provided
    starter_kit_name = input_data.get("kit")
    if starter_kit_name:
        builder.apply_starter_kit(starter_kit_name, starter_kits)
        kit_data = starter_kits.get(starter_kit_name, {})
        character["inventory"] = kit_data.get("inventory", [])
        character["equipment"] = kit_data.get("equipment", [])
        character["gold"] = kit_data.get("gold", 0)

    return character

# === GENERAL UTILITIES ===
def parse_coords(loc):
    try:
        return tuple(map(int, loc.split("_")))
    except Exception:
        return None, None

def perform_skill_check(character, skill, dc=12):
    SKILL_TO_ABILITY = {
        "stealth": "DEX", "pickpocket": "DEX", "intimidate": "CHA", "diplomacy": "CHA",
        "persuasion": "CHA", "deception": "CHA", "perception": "WIS", "insight": "WIS", "arcana": "INT"
    }
    ability = SKILL_TO_ABILITY.get(skill.lower(), "INT")
    modifier = (character.get(ability, 10) - 10) // 2
    if skill.lower() in [s.lower() for s in character.get("skills", [])]:
        modifier += 2
    roll = random.randint(1, 20)
    total = roll + modifier
    return {
        "skill": skill,
        "roll": roll,
        "modifier": modifier,
        "total": total,
        "success": total >= dc,
        "dc": dc
    }

def save_character_to_firebase(character_id: str, character_data: dict, is_npc=False):
    path = f"/npcs/{character_id}" if is_npc else f"/players/{character_id}"
    db.reference(path).set(character_data)

def load_character_from_firebase(character_id: str, is_npc=False):
    path = f"/npcs/{character_id}" if is_npc else f"/players/{character_id}"
    return db.reference(path).get()