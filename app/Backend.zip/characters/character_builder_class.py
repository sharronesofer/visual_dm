
#This class is responsible for character creation logic, translating input into structured JSON-compatible data ready for storage or gameplay. It supports race selection, attribute assignment, feats, skills, starter kits, and various derived attributes like HP, MP, and AC.

#It touches character building, derived attribute rules, and narrative motif scaffolding, but does not currently persist data or connect to world attributee or memory systems.

import random
from datetime import datetime
from app.rules.rules_utils import calculate_dr
from uuid import uuid4

class CharacterBuilder:
    def __init__(self, race_data, feat_data, skill_list):
        self.race_data = race_data
        self.feat_data = feat_data
        self.skill_list = skill_list

        self.character_name = None
        self.selected_race = None
        self.attributes = {key: 8 for key in ["STR", "DEX", "CON", "INT", "WIS", "CHA"]}
        self.selected_feats = []
        self.selected_skills = []
        self.skill_points = 0
        self.starter_kit = {}
        self.level = 1
        self.gold = 0
        self.hidden_personality = self.generate_hidden_traits()

    def load_from_input(self, input_data):
        self.character_name = input_data.get("character_name") or input_data.get("name")
        self.set_race(input_data["race"])

        for attribute, value in input_data.get("attributes", {}).items():
            self.assign_attribute(attribute, value)

        for feat in input_data.get("feats", []):
            self.add_feat(feat)

        if "skills" in input_data:
            self.assign_skills(input_data["skills"])

        if "starter_kit" in input_data:
            starter_kits = input_data.get("starter_kits", {})  # must be passed in externally
            self.apply_starter_kit(input_data["starter_kit"], starter_kits)

    def set_race(self, race_name):
        if race_name not in self.race_data:
            raise ValueError(f"Unknown race: {race_name}")
        self.selected_race = race_name
        self.apply_racial_modifiers()

    def apply_racial_modifiers(self):
        mods = self.race_data[self.selected_race].get("ability_modifiers", {})
        for attribute, bonus in mods.items():
            if attribute in self.attributes:
                self.attributes[attribute] += bonus

    def assign_attribute(self, attribute, value):
        if attribute not in self.attributes:
            raise ValueError(f"Unknown attribute: {attribute}")
        self.attributes[attribute] = value

    def add_feat(self, feat_name):
        if feat_name not in self.feat_data:
            raise ValueError(f"Unknown feat: {feat_name}")
        self.selected_feats.append(feat_name)

    def assign_skill(self, skill_name):
        skill_map = {s.lower(): s for s in self.skill_list}
        skill_key = skill_name.lower()
        if skill_key not in skill_map:
            raise ValueError(f"Unknown skill: {skill_name}")
        self.selected_skills.append(skill_map[skill_key])

    def assign_skills(self, skills_dict):
        for skill_name, rank in skills_dict.items():
            if skill_name.lower() in [s.lower() for s in self.skill_list]:
                self.selected_skills.append(skill_name)
                
    def apply_starter_kit(self, kit_name, starter_kits):
        kit = starter_kits.get(kit_name)
        if not kit:
            raise ValueError(f"Unknown starter kit: {kit_name}")
        self.starter_kit = kit
        self.gold = kit.get("gold", 0)

    def is_valid(self):
        valid = True
        if self.selected_race is None:
            print("❌ Validation: No race selected.")
            valid = False
        if len(self.selected_feats) > 7:
            print(f"❌ Validation: Too many feats ({len(self.selected_feats)} > 7)")
            valid = False
        if len(self.selected_skills) > 18:
            print(f"❌ Validation: Too many skills ({len(self.selected_skills)} > 10)")
            valid = False
        return valid


    def finalize(self):
        import uuid  # 🛠 Fix: Make sure UUID is loaded properly here

        INT = self.attributes.get("INT", 0)
        CON = self.attributes.get("CON", 0)
        DEX = self.attributes.get("DEX", 0)
        level = self.level

        character_id = (
            self.character_name.lower().replace(" ", "_") + "_" + uuid.uuid4().hex[:4]
            if self.character_name else "unnamed_character_" + uuid.uuid4().hex[:4]
        )

        char = {
            "character_name": self.character_name,
            "character_id": character_id,
            "race": self.selected_race,
            "attributes": self.attributes,
            "feats": self.selected_feats,
            "skills": self.selected_skills,
            "HP": level * (12 + CON),
            "MP": (level * 8) + (INT * level),
            "AC": 10 + DEX,
            "XP": 0,
            "level": level,
            "alignment": "Neutral",
            "languages": ["Common"],
            "created_at": datetime.utcnow().isoformat(),
            "inventory": self.starter_kit.get("inventory", []),
            "equipment": self.starter_kit.get("equipment", []),
            "gold": self.gold,
            "dr": calculate_dr(self.starter_kit.get("equipment", [])),
            "features": [],
            "proficiencies": [],
            "faction_affiliations": [],
            "reputation": 0,
            "cooldowns": {},
            "attributeus_effects": [],
            "notable_possessions": [],
            "spells": [],
            "known_languages": ["Common"],
            "rumor_index": [],
            "beliefs": {},
            "narrative_motif_pool": {
                "active_motifs": [],
                "motif_history": [],
                "last_rotated": datetime.utcnow().isoformat()
            },
            "narrator_style": "Cormac McCarthy meets Lovecraft"
        }

        return char

    def to_dict(self):
        return self.finalize()

    def generate_hidden_traits(self):
        return {
            "hidden_ambition": random.randint(0, 6),
            "hidden_integrity": random.randint(0, 6),
            "hidden_discipline": random.randint(0, 6),
            "hidden_impulsivity": random.randint(0, 6),
            "hidden_pragmatism": random.randint(0, 6),
            "hidden_resilience": random.randint(0, 6)
        }