
# This route handles party creation and management including adding/removing NPCs, viewing party data, and simulating NPC abandonment based on loyalty logic. It serves as a bridge between npc, faction, and firebase systems.

from flask import Blueprint, request, jsonify
from firebase_admin import db
from app.characters.party_utils import (
    create_party,
    add_to_party,
    remove_from_party,
    abandon_party,
)
from app.npc.npc_loyalty_utils import should_abandon

party_bp = Blueprint("party", __name__)

# === PARTY CREATION ===
@party_bp.route("/party/create", methods=["POST"])
def create_party_route():
    data = request.get_json(force=True)
    character_id = data.get("character_id")
    npc_ids = data.get("npc_ids", [])
    party_name = data.get("party_name", "Adventuring Party")

    if not character_id:
        return jsonify({"error": "Missing character_id."}), 400

    party_id = create_party(character_id, npc_ids, party_name)

    # Link party to player
    db.reference(f"/players/{character_id}/party_id").set(party_id)

    return jsonify({"message": "Party created.", "party_id": party_id}), 201

# === ADD NPC TO PARTY BY PARTY ID ===
@party_bp.route("/party/<party_id>/add_npc", methods=["POST"])
def add_npc_to_party_route(party_id):
    data = request.get_json(force=True)
    npc_id = data.get("npc_id")

    if not npc_id:
        return jsonify({"error": "Missing npc_id."}), 400

    result = add_to_party(party_id, npc_id)
    return jsonify(result), 200 if result["success"] else 400

# === ADD NPC TO PARTY BY PLAYER ID ===
@party_bp.route("/player/<character_id>/party/add_npc", methods=["POST"])
def add_npc_to_party_by_player(character_id):
    data = request.get_json(force=True)
    npc_id = data.get("npc_id")

    if not npc_id:
        return jsonify({"error": "Missing npc_id."}), 400

    party_id = db.reference(f"/players/{character_id}/party_id").get()
    if not party_id:
        return jsonify({"error": "Player has no party."}), 404

    result = add_to_party(party_id, npc_id)
    return jsonify(result), 200 if result["success"] else 400

# === REMOVE MEMBER FROM PARTY ===
@party_bp.route("/party/<party_id>/remove_member", methods=["POST"])
def remove_member_route(party_id):
    data = request.get_json(force=True)
    member_id = data.get("member_id")
    member_type = data.get("member_type", "npc")  # Accepts 'npc' or 'player'

    if not member_id:
        return jsonify({"error": "Missing member_id."}), 400
    if member_type not in {"npc", "player"}:
        return jsonify({"error": "member_type must be 'npc' or 'player'."}), 400

    result = remove_from_party(party_id, member_id, member_type)
    return jsonify(result), 200 if result["success"] else 400

# === VIEW PARTY DETAILS ===
@party_bp.route("/party/<party_id>", methods=["GET"])
def get_party_details(party_id):
    party_data = db.reference(f"/parties/{party_id}").get()

    if not party_data:
        return jsonify({"error": "Party does not exist."}), 404

    return jsonify(party_data), 200

# === ABANDONMENT CHECK ===

@party_bp.route("/npc/<npc_id>/abandon_party", methods=["POST"])
def abandon_party(npc_id):
    ref = db.reference(f"/npcs/{npc_id}")
    npc = ref.get()
    if not npc:
        return jsonify({"error": "NPC not found"}), 404

    party_id = npc.get("party_affiliation")
    if not party_id:
        return jsonify({"message": "NPC was not in a party."})

    # Remove from party
    party_ref = db.reference(f"/parties/{party_id}/members")
    members = party_ref.get() or []
    if npc_id in members:
        members.remove(npc_id)
        party_ref.set(members)

    # Clear affiliation
    npc["party_affiliation"] = None
    ref.set(npc)

    # Log permanent memory event
    db.reference(f"/npc_memory/{npc_id}/rag_log").push({
        "interaction": f"Left party {party_id}",
        "timestamp": datetime.utcnow().isoformat()
    })

    return jsonify({"message": f"{npc_id} left party {party_id}"})
