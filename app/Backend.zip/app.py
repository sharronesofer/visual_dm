from flask import Flask
from flask_cors import CORS
from firebase_admin import credentials, initialize_app
import json
from apscheduler.schedulers.background import BackgroundScheduler
from app.utils.world_tick_utils import tick_world_day
import os
from dotenv import load_dotenv
load_dotenv()

# === Blueprint Imports ===
from app.auth.auth_routes import auth_bp
from app.characters.character_routes import character_bp
from app.combat.combat_routes import combat_bp
from app.equipment.inventory_routes import inventory_bp
from app.visuals.menu_routes import menu_bp
from app.characters.party_routes import party_bp
from app.dm_engine.dm_routes import dm_engine_bp
from app.memory.memory_routes import memory_bp
from app.motifs.motif_routes import motif_bp
from app.npc.npc_routes import npc_routes_bp
from app.quests.quest_routes import quest_bp
from app.regions.region_routes import region_bp
from app.regions.tension_routes import tension_bp
from app.regions.worldgen_routes import worldgen_bp
from app.rules.rules_routes import rules_bp
from app.rules.rules_validation_routes import rules_validation_bp
from app.visuals.tile_routes import tiles_bp
from app.pois.poi_tilemap_routes import poi_tilemap_bp
from app.equipment.shop_routes import shop_bp
from app.equipment.loot_routes import loot_bp
from app.equipment.identify_routes import identify_bp
from app.factions.faction_routes import faction_bp
from app.utils.world_tick_routes import world_tick_bp
from app.utils.debug import debug_bp
from app.quests.journal_routes import journal_bp
from app.regions.world_routes import world_bp
from app.utils.start_game_routes import start_game_bp


# === App Setup ===
app = Flask(__name__)
CORS(app)

# === Register Blueprints ===
app.register_blueprint(auth_bp)
app.register_blueprint(character_bp)
app.register_blueprint(combat_bp)
app.register_blueprint(inventory_bp)
app.register_blueprint(menu_bp)
app.register_blueprint(party_bp)
app.register_blueprint(dm_engine_bp)
app.register_blueprint(memory_bp)
app.register_blueprint(motif_bp)
app.register_blueprint(npc_routes_bp)
app.register_blueprint(quest_bp)
app.register_blueprint(region_bp)
app.register_blueprint(tension_bp)
app.register_blueprint(worldgen_bp)
app.register_blueprint(rules_bp)
app.register_blueprint(rules_validation_bp)
app.register_blueprint(tiles_bp)
app.register_blueprint(poi_tilemap_bp)
app.register_blueprint(shop_bp)
app.register_blueprint(loot_bp)
app.register_blueprint(identify_bp)
app.register_blueprint(faction_bp)
app.register_blueprint(world_tick_bp)
app.register_blueprint(debug_bp)
app.register_blueprint(journal_bp)
app.register_blueprint(world_bp)
app.register_blueprint(start_game_bp)


# === Scheduler Setup ===
scheduler = BackgroundScheduler()
scheduler.add_job(tick_world_day, trigger="cron", hour=0, minute=1)  # Runs daily at 12:01 AM
scheduler.start()

# === Run App ===
if __name__ == "__main__":
    app.run(debug=True, port=5050)
