
#This file defines Flask routes for item identification, allowing players to either reveal effects progressively (based on level) or fully. It exposes the logic from identify_item_utils through a clean API.
#It connects to asset, narrative, and economy systems.

from flask import Blueprint, request, jsonify
from app.equipment.identify_item_utils import (
    calculate_identification_cost,
    reveal_item_name_and_flavor
)
from firebase_admin import db
from app.utils.gpt_utils import gpt_flavor_identify_effect, gpt_flavor_reveal_full_item
from datetime import datetime

identify_bp = Blueprint("identify", __name__)


@identify_bp.route("/identify_item", methods=["POST"])
def route_identify_item():
    data = request.get_json()
    character_id = data.get("character_id")
    item_id = data.get("item_id")
    region = data.get("region")
    faction = data.get("faction_id")

    if not character_id or not item_id:
        return jsonify({"error": "Missing character or item ID"}), 400

    inv_ref = db.reference(f"/players/{character_id}/inventory/{item_id}")
    item = inv_ref.get()
    if not item:
        return jsonify({"error": "Item not found"}), 404

    gold = db.reference(f"/players/{character_id}/gold").get() or 0
    cost = calculate_identification_cost(item, region, faction)

    if gold < cost:
        return jsonify({"error": "Not enough gold", "required": cost, "current": gold}), 402

    # Pay and apply
    db.reference(f"/players/{character_id}/gold").set(gold - cost)

    if item.get("unknown_effects"):
        revealed = item["unknown_effects"].pop(0)
        item.setdefault("identified_effects", []).append(revealed)
        flavor = gpt_flavor_identify_effect(item["name"], revealed)
        reveal_item_name_and_flavor(item)  # name/flavor logic unified
        inv_ref.set(item)
    else:
        return jsonify({"message": "Item already fully identified"})

    return jsonify({
        "message": f"Effect '{revealed}' identified.",
        "flavor": flavor,
        "gold_spent": cost,
        "remaining_gold": gold - cost,
        "item_name": item.get("identified_name"),
        "reveal_flavor": item.get("reveal_flavor")
    })


@identify_bp.route("/identify_item_full", methods=["POST"])
def route_identify_item_full():
    data = request.get_json()
    character_id = data.get("character_id")
    item_id = data.get("item_id")
    npc_id = data.get("npc_id")

    if not all([character_id, item_id, npc_id]):
        return jsonify({"error": "Missing required data"}), 400

    # Validate NPC permissions
    npc_data = db.reference(f"/npcs/{npc_id}").get()
    if not npc_data or npc_data.get("title") != "Wandering Wizard":
        return jsonify({"error": "This NPC cannot fully identify items."}), 403

    item_ref = db.reference(f"/players/{character_id}/inventory/{item_id}")
    item = item_ref.get()
    if not item:
        return jsonify({"error": "Item not found"}), 404

    # Name reveal
    reveal_item_name_and_flavor(item)

    # Reveal all unknown effects
    identified = item.get("identified_effects", [])
    identified += item.get("unknown_effects", [])
    item["identified_effects"] = identified
    item["unknown_effects"] = []

    item_ref.set(item)

    gpt_response = gpt_flavor_reveal_full_item(item)

    return jsonify({
        "message": "All effects revealed.",
        "item_name": item.get("identified_name"),
        "flavor": item.get("flavor_text"),
        "gpt_narration": gpt_response,
        "effects": identified
    })