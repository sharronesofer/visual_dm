
#This module handles economic logic and presentation for shops:
#Gold curve scaling by level
#Sale/resale price calculations
#Shop inventory formatting
#Pagination, filtering, and cleanup utilities
#It powers the logic for the /shop routes and connects to economy, asset, and UI systems.

from datetime import datetime, timedelta
import random
from firebase_admin import db
from app.equipment.loot_utils import generate_item_identity
from app.equipment.inventory_utils import equipment_rules
from uuid import uuid4

RARITY_COLORS = {
    "common": "gray",
    "uncommon": "blue",
    "rare": "green",
    "epic": "purple",
    "legendary": "orange"
}

def get_shop_inventory(npc_id):
    inventory = db.reference(f"/npcs/{npc_id}/shop_inventory").get() or {}

    for item_id, item in inventory.items():
        if item.get("name_revealed"):
            rarity = item.get("rarity", "common")
            item["rarity_color"] = RARITY_COLORS.get(rarity, "gray")

    return inventory

def get_expected_gold_at_level(level):
    xp_to_level = {
        1: 0,
        2: 300,
        3: 900,
        4: 2700,
        5: 6500,
        6: 14000,
        7: 23000,
        8: 34000,
        9: 48000,
        10: 64000
    }
    xp = xp_to_level.get(level, 64000 + (level - 10) * 20000)
    return xp // 10

def calculate_sale_value(item, player_level):
    rarity = item.get("rarity", "normal")
    base = get_expected_gold_at_level(player_level)
    multiplier = {"normal": 0.25, "epic": 0.5, "legendary": 1.0}.get(rarity, 0.25)
    return round(base * multiplier)

def calculate_resale_value(item, player_level):
    sale = calculate_sale_value(item, player_level)
    return round(sale * 1.5)

def format_shop_inventory(inventory):
    lines = []
    for item in inventory:
        name = item.get("display_name") or item.get("base_item", "Unnamed")
        rarity = item.get("rarity", "normal").title()
        price = item.get("resale_price", "?")
        weight = item.get("weight_lbs", "?")
        lines.append(f"[{rarity}] {name} — {price}g, {weight} lbs")
    return "\n".join(lines)

def summarize_shop(shop_id, shop_data, sort_by=None, filter_type=None, page=1, page_size=10):
    inventory = shop_data.get("inventory", [])

    if filter_type:
        inventory = [i for i in inventory if i.get("category") == filter_type]

    if sort_by == "value":
        inventory.sort(key=lambda x: x.get("resale_price", 0), reverse=True)
    elif sort_by == "rarity":
        rarity_order = {"legendary": 3, "epic": 2, "normal": 1}
        inventory.sort(key=lambda x: rarity_order.get(x.get("rarity", "normal"), 0), reverse=True)
    elif sort_by == "weight":
        inventory.sort(key=lambda x: x.get("weight_lbs", 0), reverse=True)

    total_items = len(inventory)
    total_pages = (total_items + page_size - 1) // page_size
    start = (page - 1) * page_size
    end = start + page_size
    page_items = inventory[start:end]

    return {
        "shop_id": shop_id,
        "total_items": total_items,
        "total_pages": total_pages,
        "current_page": page,
        "page_size": page_size,
        "items_on_page": len(page_items),
        "preview": format_shop_inventory(page_items)
    }

# Optional cleanup tick: remove items older than X days
def tick_shop_inventory(shop_data, max_days=2):
    now = datetime.utcnow()
    inventory = shop_data.get("inventory", [])
    cleaned = []

    for item in inventory:
        timestamp = item.get("added_at")
        if timestamp:
            try:
                item_time = datetime.fromisoformat(timestamp)
                if now - item_time <= timedelta(days=max_days):
                    cleaned.append(item)
            except ValueError:
                cleaned.append(item)  # If timestamp broken, keep

    shop_data["inventory"] = cleaned
    return shop_data

def buy_item_from_shop(character_id, npc_id, item_id):
    player_ref = db.reference(f"/players/{character_id}")
    gold = player_ref.child("gold").get() or 0
    attributes = player_ref.child("attributes").get() or {}
    cha_mod = attributes.get("CHA", 0)

    # Load item from NPC shop
    shop_ref = db.reference(f"/npcs/{npc_id}/shop_inventory/{item_id}")
    item = shop_ref.get()
    if not item:
        return {"error": "Item not found in shop"}, 404

    base_price = item.get("gold_value", 0)

    # Load goodwill
    opinion_ref = db.reference(f"/npc_opinion_matrix/{npc_id}/{character_id}")
    goodwill = opinion_ref.get() or 0

    # Calculate modifier
    modifier = 1.0
    modifier *= 1.0 - (cha_mod * 0.02)
    modifier *= 1.0 - (goodwill * 0.02)
    modifier = max(0.7, min(modifier, 1.3))

    final_price = int(base_price * modifier)

    if gold < final_price:
        return {"error": "Not enough gold", "price": final_price, "current": gold}, 402

    # Transaction
    player_ref.child("gold").set(gold - final_price)
    inventory_ref = player_ref.child("inventory")
    inventory = inventory_ref.get() or []
    inventory.append(item)
    inventory_ref.set(inventory)
    shop_ref.delete()

    return {
        "message": "Item purchased",
        "item": item,
        "gold_spent": final_price,
        "gold_remaining": gold - final_price
    }, 200

def restock_shop_inventory(npc_id):
    npc_ref = db.reference(f"/npcs/{npc_id}")
    npc = npc_ref.get()

    if not npc:
        return {"error": "NPC not found"}

    # Tags determine what kinds of items the shop should carry
    building_tags = npc.get("shop_profile", {}).get("inventory_tags", ["gear"])
    inventory = {}

    matching_items = [
        item for item in equipment_rules.values()
        if item.get("category") in building_tags
    ]

    for _ in range(random.randint(3, 6)):
        base = random.choice(matching_items)
        item = generate_item_identity(base.copy())
        inventory[f"item_{uuid4().hex[:6]}"] = item

    db.reference(f"/npcs/{npc_id}/shop_inventory").set(inventory)
    return {"npc_id": npc_id, "new_items": list(inventory.values())}


def generate_inventory_from_tags(tags):
    """
    Given a list of tags like ["armor", "weapons"], return a randomized inventory list.
    """
    item_pools = {
        "armor": ["Leather Armor", "Chain Shirt", "Breastplate", "Plate Armor"],
        "weapons": ["Short Sword", "Longbow", "Warhammer", "Dagger"],
        "food": ["Rations", "Ale Cask", "Dried Fruits", "Hardtack"],
        "magic": ["Potion of Healing", "Scroll of Fireball", "Wand of Light", "Amulet of Protection"],
        "tools": ["Thieves' Tools", "Carpenter's Kit", "Alchemy Set", "Smithing Kit"]
    }

    inventory = []
    for tag in tags:
        pool = item_pools.get(tag, [])
        if pool:
            inventory.extend(random.sample(pool, k=min(3, len(pool))))  # Pick 1-3 items per tag

    # Shuffle inventory for flavor
    random.shuffle(inventory)

    return inventory