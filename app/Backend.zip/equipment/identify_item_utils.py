
#This module manages how magical items are identified progressively based on player level, item rarity, and effect unlock thresholds. It's part of the broader equipment and discovery systems.
#It integrates lightly with asset, narrative, and character progression systems.

from firebase_admin import db
from app.utils.gpt_utils import gpt_flavor_reveal_full_item

RARITY_MULTIPLIER = {
    "common": 1.0,
    "uncommon": 1.25,
    "rare": 1.5,
    "epic": 2.0,
    "legendary": 4.0
}

def calculate_identification_cost(item_data, region_name=None, faction_id=None):
    """
    Cost = base × rarity × regional economic modifier × faction discount
    """
    rarity = item_data.get("rarity", "common").lower()
    base_cost = 20 * len(item_data.get("unknown_effects", []))
    multiplier = RARITY_MULTIPLIER.get(rarity, 1.0)

    economic_mod = 1.0
    if region_name:
        tension = db.reference(f"/regions/{region_name}/economic_modifier").get()
        if tension:
            economic_mod = tension

    faction_discount = 1.0
    if faction_id:
        faction_data = db.reference(f"/factions/{faction_id}").get()
        if faction_data and faction_data.get("type") == "mage":
            faction_discount = 0.85  # Mage Guild discount

    return int(base_cost * multiplier * economic_mod * faction_discount)

def identify_item(item, player_level):
    effects = item.get("effects", [])
    known = set(item.get("identified_levels", []))
    new_levels = sorted(e["level"] for e in effects if e["level"] > player_level and e["level"] not in known)
    if not new_levels:
        return item
    next_level = new_levels[0]
    item.setdefault("identified_levels", []).append(next_level)
    return item

def fully_identify_item(item):
    effects = item.get("effects", [])
    all_levels = [e["level"] for e in effects]
    item["identified_levels"] = list(sorted(set(all_levels)))
    return item

def is_fully_identified(item):
    levels = set(e["level"] for e in item.get("effects", []))
    known = set(item.get("identified_levels", []))
    return levels == known

def get_next_identifiable_level(item, player_level):
    effects = item.get("effects", [])
    known = set(item.get("identified_levels", []))
    new_levels = sorted([e["level"] for e in effects if e["level"] > player_level and e["level"] not in known])
    return new_levels[0] if new_levels else None

def reveal_item_name_and_flavor(item: dict) -> str:
    """
    Reveals generated item name and flavor, stores it for narrative delivery.
    Only runs once per item.
    """
    if not item.get("name_revealed", False):
        item["name_revealed"] = True
        item["identified_name"] = item.get("generated_name", item.get("name", "Unnamed Item"))
        item["reveal_flavor"] = item.get("flavor_text", "It gives off a subtle magical hum...")

    return item.get("reveal_flavor", "")

