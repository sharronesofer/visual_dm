
#This route exposes a test endpoint for generating loot bundles, combining monster level, equipment pools, item effects, and GPT-based naming/flavor. It integrates several structured rule files and generative functions.
#It directly supports asset, combat, and gpt systems.

from flask import Blueprint, request, jsonify
import json
from app.equipment.loot_utils import (
    group_equipment_by_type,
    generate_loot_bundle,
    gpt_name_and_flavor
)

loot_bp = Blueprint("loot", __name__)

# Load your JSON data once at startup
with open("rules_json/equipment.json") as f:
    EQUIPMENT_LIST = json.load(f)

with open("rules_json/item_effects.json") as f:
    ITEM_EFFECTS = json.load(f)

with open("rules_json/monster_only_feats.json") as f:
    MONSTER_FEATS = json.load(f)

EQUIPMENT_POOL = group_equipment_by_type(EQUIPMENT_LIST)

@loot_bp.route("/generate_loot", methods=["POST"])
def generate_loot():
    data = request.get_json(force=True)
    monster_levels = data.get("monster_levels", [1, 1, 1])

    loot = generate_loot_bundle(
        monster_levels=monster_levels,
        equipment_pool=EQUIPMENT_POOL,
        item_effects=ITEM_EFFECTS,
        monster_feats=MONSTER_FEATS,
        gpt_name_and_flavor=gpt_name_and_flavor
    )

    return jsonify(loot), 200
