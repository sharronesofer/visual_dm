
#This utility loads and returns a dictionary of equipment rules from a JSON file, intended to support DR calculations, equip checks, and item metadata. It supports inventory_routes.py and combat stat calculations.
#It’s a core data loader for the asset and combat systems.

import json
import os
import logging
from firebase_admin import db

# Configure basic logging
logging.basicConfig(level=logging.INFO)

def get_weight(inventory, carry_modifiers=None):
    total_weight = 0

    def compute(item):
        if item.get("type") == "container" and "contents" in item:
            container_weight = item.get("weight", 0)
            contents_weight = sum(compute(i) for i in item["contents"])
            if item.get("magic_reduction"):
                contents_weight *= (1 - item["magic_reduction"])
            return container_weight + contents_weight
        return item.get("weight", 0)

    for item in inventory:
        total_weight += compute(item)

    if carry_modifiers and carry_modifiers.get("str_bonus"):
        total_weight -= carry_modifiers["str_bonus"] * 2

    return round(max(total_weight, 0), 2)


def load_equipment_rules(filepath="rules_json/equipment.json"):
    """
    Loads equipment rules from the specified JSON file.
    Returns a dictionary indexed by equipment name.
    """
    if not os.path.exists(filepath):
        logging.error(f"Equipment file not found: {filepath}")
        return {}

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            equipment_data = json.load(f)
            return {item["name"]: item for item in equipment_data}
    except json.JSONDecodeError as jde:
        logging.error(f"JSON decoding error in {filepath}: {jde}")
    except Exception as e:
        logging.error(f"Unexpected error loading {filepath}: {e}")

    return {}

# Initial load on module import
equipment_rules = load_equipment_rules()


def calculate_inventory_weight(character_id):
    """
    Calculates total inventory and equipment weight for a player.
    Saves it to /players/<id>/encumbrance/total_weight_lbs
    """
    inventory = db.reference(f"/players/{character_id}/inventory").get() or {}
    equipped = db.reference(f"/players/{character_id}/equipment").get() or {}

    def get_weight(item): return item.get("weight_lbs", 0)

    total_weight = sum(get_weight(item) for item in inventory.values())
    total_weight += sum(get_weight(item) for item in equipped.values())

    db.reference(f"/players/{character_id}/encumbrance/total_weight_lbs").set(total_weight)
    return total_weight

def get_carry_capacity(character_id):
    """
    Determines carry capacity from STR and mount data.
    STR x 15 by default, plus bonuses from mules, carts, etc.
    """
    attributes = db.reference(f"/players/{character_id}/attributes").get() or {}
    base_str = attributes.get("STR", 10)
    base_capacity = base_str * 15

    encumbrance_info = db.reference(f"/players/{character_id}/encumbrance").get() or {}
    bonus = 0

    if encumbrance_info.get("mount") == "mule":
        bonus += 150
    if encumbrance_info.get("cart") is True:
        bonus += 300

    total_capacity = base_capacity + bonus
    db.reference(f"/players/{character_id}/encumbrance/carry_limit_lbs").set(total_capacity)
    return total_capacity