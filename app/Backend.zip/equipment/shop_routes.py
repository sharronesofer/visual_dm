
#This module provides a Flask API for shop inventory management, including:
#Selling and buying items
#Querying inventory
#Viewing filtered/sorted shop summaries
#It integrates with asset, economy, firebase, and inventory systems.

from flask import Blueprint, request, jsonify
from firebase_admin import db
from app.equipment.shop_utils import calculate_sale_value, calculate_resale_value, summarize_shop

shop_bp = Blueprint("shop", __name__)

@shop_bp.route("/sell_item_to_shop", methods=["POST"])
def sell_item_to_shop():
    data = request.get_json(force=True)
    shop_id = data.get("shop_id", "default_shop")
    item = data.get("item")
    player_level = data.get("player_level")

    if not item or player_level is None:
        return jsonify({"error": "Missing item or player_level"}), 400

    # Identify all levels known to player
    item.setdefault("identified_levels", [e["level"] for e in item.get("effects", []) if e["level"] <= player_level])

    # Calculate sale/resale value
    sale_price = calculate_sale_value(item, player_level)
    resale_price = calculate_resale_value(item, player_level)

    # Store in shop inventory
    ref = db.reference(f"/shops/{shop_id}/inventory")
    inventory = ref.get() or []
    item["resale_price"] = resale_price
    inventory.append(item)
    ref.set(inventory)

    return jsonify({
        "message": "Item sold to shop.",
        "gold_earned": sale_price,
        "resale_price": resale_price
    })

@shop_bp.route("/get_shop_inventory/<shop_id>", methods=["GET"])
def get_shop_inventory(shop_id):
    ref = db.reference(f"/shops/{shop_id}/inventory")
    inventory = ref.get() or []
    item = generate_item_identity(item)
    return jsonify({"shop_id": shop_id, "inventory": inventory})

@shop_bp.route("/buy_item_from_shop/<shop_id>", methods=["POST"])
def buy_item_from_shop(shop_id):
    data = request.get_json(force=True)
    item_id = data.get("item_id")
    player_gold = data.get("player_gold")

    ref = db.reference(f"/shops/{shop_id}/inventory")
    inventory = ref.get() or []

    item = next((i for i in inventory if i.get("item_id") == item_id), None)
    if not item:
        return jsonify({"error": "Item not found in shop."}), 404

    price = item.get("resale_price", 9999)
    if player_gold < price:
        return jsonify({"error": "Not enough gold.", "required": price}), 403

    # Remove item from inventory
    inventory = [i for i in inventory if i.get("item_id") != item_id]
    ref.set(inventory)

    return jsonify({
        "item": item,
        "gold_spent": price,
        "remaining_gold": player_gold - price
    })

@shop_bp.route("/shops/preview_price", methods=["POST"])
def preview_price():
    data = request.get_json()
    character_id = data.get("character_id")
    npc_id = data.get("npc_id")
    item_id = data.get("item_id")

    attributes = db.reference(f"/players/{character_id}/attributes").get() or {}
    cha_mod = attributes.get("CHA", 0)

    opinion = db.reference(f"/npc_opinion_matrix/{npc_id}/{character_id}").get() or 0

    item_ref = db.reference(f"/npcs/{npc_id}/shop_inventory/{item_id}")
    item = item_ref.get()
    if not item:
        return {"error": "Item not found in shop"}, 404

    base_price = item.get("gold_value", 0)
    modifier = 1.0
    modifier *= 1.0 - (cha_mod * 0.02)
    modifier *= 1.0 - (opinion * 0.02)
    modifier = max(0.7, min(modifier, 1.3))
    final_price = int(base_price * modifier)

    return {
        "base_price": base_price,
        "final_price": final_price,
        "modifier": round(modifier, 2),
        "charisma": cha_mod,
        "goodwill": opinion
    }

@shop_bp.route("/view_shop_inventory/<npc_id>", methods=["GET"])
def view_shop_inventory(npc_id):
    query_type = request.args.get("type")
    rarity = request.args.get("rarity")
    sort_by = request.args.get("sort", "gold_value")
    inventory = db.reference(f"/npcs/{npc_id}/shop_inventory").get() or {}

    def filter_item(item):
        if query_type and item.get("category") != query_type:
            return False
        if rarity and item.get("rarity") != rarity:
            return False
        return True

    def rarity_color(item):
        if item.get("name_revealed"):
            return {
                "common": "gray",
                "uncommon": "blue",
                "rare": "green",
                "epic": "purple",
                "legendary": "orange"
            }.get(item.get("rarity", "common"), "gray")
        return None

    filtered = [
        {**item, "item_id": item_id, "rarity_color": rarity_color(item)}
        for item_id, item in inventory.items() if filter_item(item)
    ]

    if sort_by:
        filtered.sort(key=lambda x: x.get(sort_by, 0))

    return jsonify(filtered)

@shop_bp.route("/shops/view_inventory/<npc_id>", methods=["GET"])
def simple_shop_inventory(npc_id):
    inventory = db.reference(f"/npcs/{npc_id}/shop_inventory").get() or {}

    simplified = []
    for item_id, item in inventory.items():
        if item.get("name_revealed"):
            entry = {
                "item_id": item_id,
                "name": item.get("identified_name"),
                "rarity": item.get("rarity"),
                "rarity_color": {
                    "common": "gray",
                    "uncommon": "blue",
                    "rare": "green",
                    "epic": "purple",
                    "legendary": "orange"
                }.get(item.get("rarity", "common"), "gray"),
                "gold_value": item.get("gold_value")
            }
            simplified.append(entry)

    return jsonify(simplified)
