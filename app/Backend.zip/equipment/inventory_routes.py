
#This file exposes a full REST API for inventory and equipment management. It allows adding, removing, equipping, using, and reordering items, and computes DR from equipment. It works primarily with Firebase player data.
#It is connected to asset, firebase, and combat systems.

from flask import Blueprint, request, jsonify
from firebase_admin import db
from app.equipment.inventory_utils import load_equipment_rules
from app.equipment.inventory_utils import calculate_inventory_weight, get_carry_capacity
from app.equipment.inventory_utils import get_carry_capacity

inventory_bp = Blueprint("inventory", __name__)

def calculate_dr(character):
    breakdown = {"armor": 0, "feats": 0, "magic": 0}

    for item in character.get("equipped_items", []):
        if item.get("type") == "armor":
            breakdown["armor"] += item.get("dr", 0)
        if "magic_dr_bonus" in item:
            breakdown["magic"] += item["magic_dr_bonus"]

    for feat in character.get("feats", []):
        if feat.get("effect") == "dr":
            breakdown["feats"] += feat.get("value", 0)

    return {
        "total_dr": sum(breakdown.values()),
        "breakdown": breakdown
    }

@inventory_bp.route("/inventory/<character_id>", methods=["GET"])
def get_inventory(character_id):
    char = db.reference(f"/players/{character_id}").get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    return jsonify({
        "inventory": char.get("inventory", []),
        "equipment": char.get("equipment", []),
        "gold": char.get("gold", 0),
        "dr": char.get("dr", 0)
    }), 200


@inventory_bp.route("/inventory/equip", methods=["POST"])
def equip_item():
    data = request.get_json()
    character_id, item_name = data.get("character_id"), data.get("item")

    if not character_id or not item_name:
        return jsonify({"error": "Missing character_id or item."}), 400

    char_ref = db.reference(f"/players/{character_id}")
    char = char_ref.get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    inventory, equipment = char.get("inventory", []), char.get("equipment", [])

    if item_name not in inventory:
        return jsonify({"error": "Item not in inventory."}), 400

    if item_name not in equipment:
        equipment.append(item_name)
        char["equipment"] = equipment

    char["dr"] = calculate_dr(equipment)
    char_ref.set(char)

    return jsonify({"message": f"{item_name} equipped.", "dr": char["dr"]}), 200


@inventory_bp.route("/inventory/unequip", methods=["POST"])
def unequip_item():
    data = request.get_json()
    character_id, item_name = data.get("character_id"), data.get("item")

    if not character_id or not item_name:
        return jsonify({"error": "Missing character_id or item."}), 400

    char_ref = db.reference(f"/players/{character_id}")
    char = char_ref.get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    equipment = char.get("equipment", [])

    if item_name in equipment:
        equipment.remove(item_name)
        char["equipment"] = equipment
        char["dr"] = calculate_dr(equipment)
        char_ref.set(char)
        return jsonify({"message": f"{item_name} unequipped.", "dr": char["dr"]}), 200

    return jsonify({"error": "Item not equipped."}), 400


@inventory_bp.route("/inventory/use", methods=["POST"])
def use_item():
    data = request.get_json()
    character_id, item_name = data.get("character_id"), data.get("item")

    if not character_id or not item_name:
        return jsonify({"error": "Missing character_id or item."}), 400

    char_ref = db.reference(f"/players/{character_id}")
    char = char_ref.get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    inventory = char.get("inventory", [])

    if item_name in inventory:
        inventory.remove(item_name)
        char["inventory"] = inventory
        char_ref.set(char)
        return jsonify({"message": f"{item_name} used and removed from inventory."}), 200

    return jsonify({"error": "Item not found in inventory."}), 400


@inventory_bp.route("/inventory/drop", methods=["POST"])
def drop_item():
    data = request.get_json()
    character_id, item_name = data.get("character_id"), data.get("item")

    if not character_id or not item_name:
        return jsonify({"error": "Missing character_id or item."}), 400

    char_ref = db.reference(f"/players/{character_id}")
    char = char_ref.get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    inventory = char.get("inventory", [])

    if item_name in inventory:
        inventory.remove(item_name)
        char["inventory"] = inventory
        char_ref.set(char)
        return jsonify({"message": f"{item_name} dropped."}), 200

    return jsonify({"error": "Item not found in inventory."}), 400


@inventory_bp.route("/inventory/reorder", methods=["POST"])
def reorder_inventory():
    data = request.get_json()
    character_id, new_order = data.get("character_id"), data.get("new_order")

    if not character_id or not isinstance(new_order, list):
        return jsonify({"error": "Missing character_id or invalid new_order."}), 400

    char_ref = db.reference(f"/players/{character_id}")
    char = char_ref.get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    current_inventory = char.get("inventory", [])

    if set(new_order) != set(current_inventory):
        return jsonify({"error": "New order must match existing inventory items."}), 400

    char["inventory"] = new_order
    char_ref.set(char)

    return jsonify({"message": "Inventory reordered.", "inventory": new_order}), 200

@inventory_bp.route("/inventory/add", methods=["POST"])
def add_item_to_inventory():
    data = request.get_json()
    character_id = data.get("character_id")
    item_name = data.get("item")

    if not character_id or not item_name:
        return jsonify({"error": "Missing character_id or item."}), 400

    char_ref = db.reference(f"/players/{character_id}")
    char = char_ref.get()

    if not char:
        return jsonify({"error": "Character not found."}), 404

    inventory = char.get("inventory", [])
    inventory.append(item_name)
    char["inventory"] = inventory
    char_ref.set(char)

    return jsonify({"message": f"{item_name} added to inventory.", "inventory": inventory}), 200


@inventory_bp.route("/inventory/encumbrance/<character_id>", methods=["GET"])
def route_encumbrance_snapshot(character_id):
    weight = calculate_inventory_weight(character_id)
    capacity = get_carry_capacity(character_id)
    over_encumbered = weight > capacity

    return jsonify({
        "character_id": character_id,
        "total_weight_lbs": weight,
        "carry_limit_lbs": capacity,
        "over_encumbered": over_encumbered
    })


@inventory_bp.route("/buy_mount", methods=["POST"])
def route_buy_mount():
    data = request.get_json()
    character_id = data.get("character_id")
    mount_type = data.get("mount_type")

    if not character_id or mount_type not in ["mule", "cart"]:
        return {"error": "Missing or invalid character_id or mount_type"}, 400

    # Load player gold
    gold_ref = db.reference(f"/players/{character_id}/gold")
    current_gold = gold_ref.get() or 0

    prices = {
        "mule": 75,
        "cart": 150
    }

    cost = prices.get(mount_type)
    if current_gold < cost:
        return {"error": "Not enough gold", "required": cost, "current": current_gold}, 402

    # Deduct and apply
    gold_ref.set(current_gold - cost)
    encumbrance_ref = db.reference(f"/players/{character_id}/encumbrance")

    if mount_type == "mule":
        encumbrance_ref.update({"mount": "mule"})
    elif mount_type == "cart":
        encumbrance_ref.update({"cart": True})

    # Recalculate carry capacity
    new_capacity = get_carry_capacity(character_id)

    return {
        "message": f"{mount_type.title()} acquired!",
        "new_gold": current_gold - cost,
        "carry_limit_lbs": new_capacity
    }

@inventory_bp.route("/buy_mount_or_cart", methods=["POST"])
def route_buy_mount_or_cart():
    data = request.get_json()
    character_id = data.get("character_id")
    mount_type = data.get("mount_type")

    if not character_id or mount_type not in ["mule", "cart"]:
        return {"error": "Missing or invalid mount_type"}, 400

    enc_ref = db.reference(f"/players/{character_id}/encumbrance")
    enc = enc_ref.get() or {}
    if enc.get(mount_type):
        return {"error": f"You already have a {mount_type}."}, 409

    prices = {"mule": 75, "cart": 150}
    cost = prices[mount_type]

    gold_ref = db.reference(f"/players/{character_id}/gold")
    gold = gold_ref.get() or 0
    if gold < cost:
        return {"error": "Not enough gold", "required": cost, "current": gold}, 402

    # Buy it
    gold_ref.set(gold - cost)
    enc[mount_type] = True if mount_type == "cart" else mount_type
    enc_ref.set(enc)

    return {"message": f"{mount_type.title()} acquired!", "new_gold": gold - cost}

@inventory_bp.route("/sell_mount_or_cart", methods=["POST"])
def route_sell_mount_or_cart():
    data = request.get_json()
    character_id = data.get("character_id")
    mount_type = data.get("mount_type")

    if mount_type not in ["mule", "cart"]:
        return {"error": "Invalid type"}, 400

    enc_ref = db.reference(f"/players/{character_id}/encumbrance")
    enc = enc_ref.get() or {}
    if not enc.get(mount_type):
        return {"error": f"You do not own a {mount_type} to sell."}, 404

    prices = {"mule": 75, "cart": 150}
    resale = round(prices[mount_type] * 0.6)

    # Remove mount, give gold
    enc[mount_type] = None
    enc_ref.set(enc)

    gold_ref = db.reference(f"/players/{character_id}/gold")
    current_gold = gold_ref.get() or 0
    gold_ref.set(current_gold + resale)

    return {"message": f"Sold {mount_type} for {resale}g", "new_gold": current_gold + resale}

@inventory_bp.route("/character_summary/<character_id>", methods=["GET"])
def route_character_summary(character_id):
    player_ref = db.reference(f"/players/{character_id}")
    player_data = player_ref.get()

    if not player_data:
        return jsonify({"error": "Character not found"}), 404

    # Char attributes
    attributes = player_data.get("attributes", {})
    enc = player_data.get("encumbrance", {})
    inventory = player_data.get("inventory", {})
    equipment = player_data.get("equipment", {})
    gold = player_data.get("gold", 0)

    # Weight calc
    total_weight = sum(item.get("weight_lbs", 0) for item in inventory.values()) + \
                   sum(item.get("weight_lbs", 0) for item in equipment.values())
    carry_limit = enc.get("carry_limit_lbs", attributes.get("STR", 10) * 15)

    # Mount status
    has_mule = enc.get("mount") == "mule"
    has_cart = enc.get("cart") is True

    # Optional: color-tag rarities (if revealed)
    RARITY_COLORS = {
        "common": "gray",
        "uncommon": "blue",
        "rare": "green",
        "epic": "purple",
        "legendary": "orange"
    }

    def tag_rarity(item):
        if item.get("name_revealed"):
            item["rarity_color"] = RARITY_COLORS.get(item.get("rarity", "common"), "gray")
        return item

    tagged_inventory = [tag_rarity(item) for item in inventory.values()]
    tagged_equipment = [tag_rarity(item) for item in equipment.values()]

    return jsonify({
        "character_id": character_id,
        "gold": gold,
        "attributes": attributes,
        "inventory": tagged_inventory,
        "equipment": tagged_equipment,
        "encumbrance": {
            "total_weight_lbs": total_weight,
            "carry_limit_lbs": carry_limit,
            "over_encumbered": total_weight > carry_limit,
            "has_mule": has_mule,
            "has_cart": has_cart
        }
    })

@inventory_bp.route("/inventory/sell_item", methods=["POST"])
def sell_item_to_shop():
    data = request.get_json()
    character_id = data.get("character_id")
    npc_id = data.get("npc_id")
    item_id = data.get("item_id")

    if not all([character_id, npc_id, item_id]):
        return {"error": "Missing character_id, npc_id, or item_id"}, 400

    inv_ref = db.reference(f"/players/{character_id}/inventory/{item_id}")
    item = inv_ref.get()
    if not item:
        return {"error": "Item not found in inventory"}, 404

    gold = db.reference(f"/players/{character_id}/gold").get() or 0
    attributes = db.reference(f"/players/{character_id}/attributes").get() or {}
    cha_mod = attributes.get("CHA", 0)

    opinion = db.reference(f"/npc_opinion_matrix/{npc_id}/{character_id}").get() or 0

    modifier = 1.0
    modifier *= 1.0 - (cha_mod * 0.02)
    modifier *= 1.0 - (opinion * 0.02)
    modifier = max(0.7, min(modifier, 1.3))

    resale_price = int((item.get("gold_value", 1) * 0.5) * modifier)

    # Transfer item
    inv_ref.delete()
    db.reference(f"/players/{character_id}/gold").set(gold + resale_price)

    shop_ref = db.reference(f"/npcs/{npc_id}/shop_inventory")
    shop_ref.push(item)

    return {
        "message": "Item sold",
        "item": item.get("name"),
        "resale_price": resale_price,
        "new_gold": gold + resale_price
    }
