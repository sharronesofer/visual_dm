
#This module powers structured loot generation with optional GPT flair. It supports generation of gold, equipment, quest items, and magical items based on encounter difficulty. Includes item validation, merging, and progressive identification.
#It is deeply tied into the asset, combat, gpt, and narrative systems.

import random
from uuid import uuid4
from random import randint
from copy import deepcopy

# === CORE UTILITY ===

def group_equipment_by_type(equipment_list):
    pool = {"armor": [], "weapon": [], "gear": []}
    for item in equipment_list:
        category = item.get("category")
        if category in pool:
            pool[category].append(item)
        elif category in ["melee", "ranged"]:
            pool["weapon"].append(item)
    return pool

def gpt_name_and_flavor(base_type="item"):
    # Stub — replace with real GPT call
    return (
        f"The Whispering {base_type.title()}",
        f"This {base_type} hums with mysterious power linked to forgotten ruins."
    )

def generate_item_effects(rarity, max_effects, effect_pool, monster_pool):
    effects = []
    for lvl in range(1, max_effects + 1):
        if rarity == "legendary" and random.random() < 0.1:
            effect = random.choice(monster_pool)
        else:
            effect = random.choice([e for e in effect_pool if rarity in e["allowed_rarity"]])
        effects.append({"level": lvl, "effect": effect})
    return effects


def generate_loot_bundle(monster_levels, equipment_pool, item_effects, monster_feats, gpt_name_and_flavor):
    loot = {
        "gold": sum(random.randint(5 + ml, 12 + ml * 2) for ml in monster_levels),
        "equipment": [],
        "quest_item": None,
        "magical_item": None
    }

    # === GEAR DROP ===
    if random() < 0.5:
        item = deepcopy(choice(equipment_pool.get("gear", [])))
        loot["equipment"].append(item)
    else:
        choices = equipment_pool.get("weapon", []) + equipment_pool.get("armor", [])
        item = deepcopy(choice(choices))
        loot["equipment"].append(item)

    # === QUEST ITEM (5%) ===
    if random() < 0.05:
        gear_item = deepcopy(choice(equipment_pool.get("gear", [])))
        name, flavor = gpt_name_and_flavor(base_type=gear_item.get("category", "item"))
        gear_item.update({
            "quest_hook": True,
            "generated_name": name,
            "flavor_text": flavor,
            "name_revealed": False
        })
        loot["quest_item"] = gear_item

    # === MAGICAL ITEM DROP ===
    if random() < 0.5:
        rarity_roll = random()
        if rarity_roll <= 0.000025:
            rarity = "legendary"
        elif rarity_roll <= 0.0025:
            rarity = "epic"
        elif rarity_roll <= 0.05:
            rarity = "rare"
        else:
            rarity = "normal"

        base_item = deepcopy(choice(equipment_pool.get("weapon", []) + equipment_pool.get("armor", [])))
        max_effects = 20 if rarity == "legendary" else random.randint(8, 12) if rarity == "epic" else random.randint(3, 5)

        effects = generate_item_effects(rarity, max_effects, item_effects, monster_feats)

        base_item.update({
            "rarity": rarity,
            "unknown_effects": [e["effect"] for e in effects]
        })

        base_item = generate_item_identity(base_item)
        loot["magical_item"] = base_item

    return loot

# === OPTIONAL UTILITIES ===

def get_loot_for_encounter(encounter):
    monster_lvls = [m.get("level", 1) for m in encounter.get("monsters", [])]
    return generate_loot_bundle(monster_lvls)

def merge_loot_sets(loot_sets):
    combined = {"gold": 0, "equipment": [], "quest_item": [], "magical_item": []}
    for loot in loot_sets:
        combined["gold"] += loot.get("gold", 0)
        combined["equipment"].extend(loot.get("equipment", []))
        if loot.get("quest_item"):
            combined["quest_item"].append(loot["quest_item"])
        if loot.get("magical_item"):
            combined["magical_item"].append(loot["magical_item"])
    return combined

def calculate_item_power_score(item):
    return sum(1 for e in item.get("effects", []) if e["level"] <= item.get("max_effects", 0))

def validate_item(item, valid_effects):
    effect_ids = {e["id"] for e in valid_effects}
    for entry in item.get("effects", []):
        effect = entry["effect"]
        if isinstance(effect, dict) and "id" in effect and effect["id"] not in effect_ids:
            return False
    return True

def generate_item_identity(item: dict) -> dict:
    rarity = item.get("rarity", "common").lower()
    is_named = rarity in ["rare", "epic", "legendary"]

    if is_named:
        name, flavor = gpt_name_and_flavor(item)
        item["generated_name"] = name
        item["flavor_text"] = flavor
        item["name_revealed"] = False
        item["identified_name"] = None
    else:
        item["generated_name"] = item["name"]
        item["flavor_text"] = f"A well-made {item['name'].lower()}, but nothing unusual stands out."
        item["name_revealed"] = True
        item["identified_name"] = item["name"]

    return item
