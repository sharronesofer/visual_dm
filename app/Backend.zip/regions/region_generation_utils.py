# region_generation_engine.py

import random
from firebase_admin import db
from datetime import datetime
from uuid import uuid4
from collections import deque
from app.regions.worldgen_utils import generate_tile
from app.pois.poi_building_utils import enrich_poi_with_buildings
from app.pois.poi_building_utils import generate_npcs_for_poi
from app.regions.worldgen_utils import generate_social_poi

# --- Constants ---
TERRAIN_TYPES = ["forest", "plains", "mountain", "swamp", "coast", "desert", "tundra"]

POI_TYPE_WEIGHTS = {
    "social": 0.5,
    "dungeon": 0.3,
    "exploration": 0.2
}

TILE_POI_CHANCE = 0.20
TOTAL_REGION_TILES = 225
TOTAL_REGION_POPULATION_RANGE = (300, 600)
METROPOLIS_CHANCE = 0.02
METROPOLIS_POP_RANGE = (100, 200)

# --- Region Generation Main ---

def generate_region(seed_x=0, seed_y=0) -> dict:
    region_id = f"region_{seed_x}_{seed_y}_{uuid4().hex[:6]}"
    print(f"🌎 Generating region: {region_id}")

    # Init region metadata
    total_population = random.randint(*TOTAL_REGION_POPULATION_RANGE)
    region_data = {
        "region_id": region_id,
        "name": region_id.replace("_", " ").title(),
        "created_at": datetime.utcnow().isoformat(),
        "total_population": total_population,
        "tiles": {},
        "poi_list": [],
        "tension_level": random.randint(0, 20),
        "faction_count": random.randint(2, 4)
    }
    region_ref = db.reference(f"/regions/{region_id}")

    # Generate natural tilemap
    tiles = walk_region(seed_x, seed_y, TOTAL_REGION_TILES)
    social_pois = []

    for (x, y) in tiles:
        coord_key = f"{x}_{y}"
        terrain = random.choice(TERRAIN_TYPES)
        tile_entry = {
            "terrain": terrain,
            "tags": [terrain],
            "poi": None
        }

        # POI generation
        if random.random() < TILE_POI_CHANCE:
            poi_type = pick_poi_type()
            tile_entry["poi_type"] = poi_type
            region_data["poi_list"].append(coord_key)

            if poi_type == "social":
                social_pois.append(coord_key)
                if random.random() < METROPOLIS_CHANCE:
                    tile_entry["is_metropolis"] = True
            elif poi_type == "dungeon":
                tile_entry["danger_level"] = random.randint(4, 10)

        region_data["tiles"][coord_key] = tile_entry
        db.reference(f"/terrain_map/{coord_key}").set(terrain)

    # Distribute population across social POIs
    distribute_population(region_data, social_pois)

    # Write region skeleton early
    region_ref.set(region_data)

    # Enrich social POIs
    for coord_key in social_pois:
        x, y = map(int, coord_key.split("_"))
        pop = region_data["tiles"][coord_key].get("population", 5)
        poi_id = generate_social_poi(region_id, x, y, size=pick_social_size(pop))
        enrich_poi_with_buildings(region_id, poi_id, {"size": pick_social_size(pop)})
        generate_npcs_for_poi(region_id, poi_id)

    print(f"✅ Region {region_id} created with {len(region_data['tiles'])} tiles and {len(region_data['poi_list'])} POIs.")
    return {"region_id": region_id, "tiles_created": len(region_data['tiles'])}

# --- Supporting Helpers ---

def walk_region(seed_x, seed_y, target_count=225) -> set:
    """
    Natural shaped region via random walk.
    """
    visited = set()
    frontier = deque()
    frontier.append((seed_x, seed_y))

    while frontier and len(visited) < target_count:
        current = frontier.popleft()
        if current in visited:
            continue

        visited.add(current)
        x, y = current
        neighbors = [(x-1, y), (x+1, y), (x, y-1), (x, y+1)]

        random.shuffle(neighbors)
        for neighbor in neighbors:
            if neighbor not in visited and random.random() < 0.75:
                frontier.append(neighbor)

    return visited

def pick_poi_type() -> str:
    """
    Weighted POI type selection.
    """
    roll = random.random()
    if roll < POI_TYPE_WEIGHTS["social"]:
        return "social"
    elif roll < POI_TYPE_WEIGHTS["social"] + POI_TYPE_WEIGHTS["dungeon"]:
        return "dungeon"
    else:
        return "exploration"

def distribute_population(region_data, social_pois):
    """
    Allocate region population to social POIs.
    """
    pop_remaining = region_data["total_population"]
    if not social_pois:
        return

    pops = {}
    for poi in social_pois:
        pops[poi] = random.randint(5, 15)

    sum_assigned = sum(pops.values())
    factor = pop_remaining / sum_assigned

    for poi, base_pop in pops.items():
        scaled_pop = max(5, int(base_pop * factor))
        if region_data["tiles"][poi].get("is_metropolis"):
            scaled_pop += random.randint(*METROPOLIS_POP_RANGE)
        region_data["tiles"][poi]["population"] = scaled_pop

def pick_social_size(population) -> str:
    """
    Pick town size based on final population.
    """
    if population >= 100:
        return "metropolis"
    elif population >= 50:
        return "city"
    elif population >= 20:
        return "town"
    else:
        return "village"

# --- Optional Test Run ---

if __name__ == "__main__":
    generate_region(0, 0)

def generate_dungeon_poi(region_id, x, y):
    poi_id = f"dungeon_{x}_{y}_{uuid4().hex[:6]}"
    poi_data = {
        "name": f"Forgotten Dungeon {x},{y}",
        "tags": ["dungeon"],
        "size": "small",
        "danger_level": random.randint(6, 10),
        "state_tags": ["hostile"],
        "location": {"x": x, "y": y},
        "terrain": "underground",
        "treasure_quality": random.choice(["poor", "moderate", "rich"]),
        "npcs_present": []
    }

    db.reference(f"/poi_state/{region_id}/{poi_id}").set(poi_data)
    print(f"[DUNGEON CREATED] {poi_id} in {region_id}")
    return poi_id


def generate_exploration_poi(region_id, x, y):
    poi_id = f"explore_{x}_{y}_{uuid4().hex[:6]}"
    poi_data = {
        "name": f"Ancient Ruins {x},{y}",
        "tags": ["exploration"],
        "danger_level": random.randint(1, 4),
        "state_tags": ["mysterious"],
        "location": {"x": x, "y": y},
        "terrain": "mixed",
        "discovery_value": random.randint(1, 5),
        "npcs_present": []
    }

    db.reference(f"/poi_state/{region_id}/{poi_id}").set(poi_data)
    print(f"[EXPLORATION CREATED] {poi_id} in {region_id}")
    return poi_id