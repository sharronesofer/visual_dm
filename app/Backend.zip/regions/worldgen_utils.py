
#This utility powers the procedural generation, population, enrichment, and maintenance of:
#Regions
#POIs
#Factions
#NPCs
#Monsters
#Events
#It also includes encounter safety checks (attempt_rest) and a centralized logging system (log_world_event).
#It integrates directly with world, region, poi, npc, gpt, combat, and faction systems.

import random
import json
from collections import deque
from datetime import datetime
from uuid import uuid4
import openai
from firebase_admin import db
import math
from app.utils.gpt_class import GPTClient
from firebase_admin import db
from app.pois.poi_building_utils import generate_castle_variant, generate_npcs_for_poi
from app.pois.poi_building_utils import enrich_poi_with_buildings
from app.factions.faction_utils import assign_faction_to_poi
import os
from app.utils.gpt_utils import log_usage

# Constants and metadata (example placeholder)
land_type_meta = {
    "grassland": {},
    "forest": {},
    "mountain": {},
    "desert": {},
    "swamp": {},
    "coast": {},
}

# Generate starting city and region

RULES_PATH = os.path.join(os.path.dirname(__file__), "../../rules_json")

def get_random_terrain():
    with open(os.path.join(RULES_PATH, "land_types.json")) as f:
        terrain_data = json.load(f)
    return random.choice(list(terrain_data.keys()))

def choose_poi_type(tile_danger):
    """
    Biases POI type based on tile danger level.
    Returns: 'social', 'exploration', or 'dungeon'
    """
    if tile_danger <= 2:
        weights = {"social": 0.7, "exploration": 0.25, "dungeon": 0.05}
    elif tile_danger <= 6:
        weights = {"social": 0.2, "exploration": 0.6, "dungeon": 0.2}
    else:
        weights = {"social": 0.1, "exploration": 0.2, "dungeon": 0.7}

    return random.choices(list(weights.keys()), list(weights.values()))[0]

def assign_regional_capital(region_name):
    """
    Tags one POI as the regional capital and ensures it has a castle and ruling faction.
    Enriches it with shops + buildings.
    """
    region_ref = db.reference(f"/poi_state/{region_name}")
    all_pois = region_ref.get() or {}

    # Filter social POIs only
    social_pois = [k for k, v in all_pois.items() if "social" in v.get("tags", [])]
    if not social_pois:
        return None

    # Pick one POI as capital
    capital_id = random.choice(social_pois)
    capital_ref = db.reference(f"/poi_state/{region_name}/{capital_id}")
    capital_data = capital_ref.get() or {}

    # Tag as regional capital
    capital_data["tags"] = list(set(capital_data.get("tags", []) + ["regional_capital"]))
    capital_data["metadata"] = capital_data.get("metadata", {})
    capital_data["metadata"]["regional_capital"] = True

    # Assign or reuse a ruling faction
    if not capital_data["metadata"].get("ruling_faction"):
        ruling_faction_id = assign_faction_to_poi(region_name, capital_id)
        capital_data["metadata"]["ruling_faction"] = ruling_faction_id
    else:
        ruling_faction_id = capital_data["metadata"]["ruling_faction"]

    # Add castle
    castle = generate_castle_variant(region_name, capital_id, ruling_faction_id)
    capital_data.setdefault("buildings", []).append(castle)

    # Save back capital data
    capital_ref.set(capital_data)

    # Enrich with buildings + NPCs (now that it's saved)
    enrich_poi_with_buildings(region_name, capital_id, capital_data)

    # Save to region metadata
    db.reference(f"/regions/{region_name}/seat_of_power").set({
        "poi_id": capital_id,
        "castle": castle
    })

    return capital_id

def generate_starting_city_and_region():
    key = "0_0"
    poi_ref = db.reference(f"/locations/{key}")
    if not poi_ref.get():
        try:
            response = openai.ChatCompletion.create(
                model="gpt-4.1",
                messages=[
                    {"role": "system", "content": (
                        "Generate a fantasy capital city in JSON format with fields: "
                        "name, description, danger_level, buildings (list), tags (tone, focus)."
                    )},
                    {"role": "user", "content": "Create a sprawling capital city for the region 'Sunveil Dominion'."}
                ],
                temperature=0.8,
                max_tokens=500
            )
            city_data = json.loads(response.choices[0].message.content.strip())
            city_data.update({
                "POI": True,
                "terrain": "grassland",
                "region_id": "sunveil_dominion"
            })
            poi_ref.set(city_data)

            generate_npcs_for_poi(0, 0)
            log_usage("gpt-4.1", response.get("usage", {}))

        except Exception as e:
            poi_ref.set({"error": str(e)})

# Log a world event
def log_world_event(event_data):
    event_id = f"event_{int(datetime.utcnow().timestamp())}"
    event_data["event_id"] = event_id
    event_data["timestamp"] = datetime.utcnow().isoformat()
    db.reference(f"/global_state/world_log/{event_id}").set(event_data)
    return event_data

# Generate shape for a region
def generate_region_shape(seed_x, seed_y, min_tiles=20, max_tiles=40, direction_bias=0.75):
    target_size = random.randint(min_tiles, max_tiles)
    region_tiles = set()
    queue = deque()
    visited = set()
    seed = (seed_x, seed_y)
    queue.append(seed)
    region_tiles.add(seed)
    visited.add(seed)
    directions = [(0, 1), (1, 0), (0, -1), (-1, 0), (1, 1), (1, -1), (-1, -1), (-1, 1)]
    while queue and len(region_tiles) < target_size:
        current = queue.popleft()
        random.shuffle(directions)
        for dx, dy in directions:
            if random.random() < direction_bias:
                neighbor = (current[0] + dx, current[1] + dy)
                if neighbor not in visited:
                    visited.add(neighbor)
                    region_tiles.add(neighbor)
                    queue.append(neighbor)
                    if len(region_tiles) >= target_size:
                        break
    return region_tiles

# Generate a detailed region

def refresh_cleared_pois():
    """
    Scans all POIs in all regions and resets those marked as 'cleared': true.
    Returns the number of POIs refreshed.
    """
    root = db.reference("/poi_state")
    all_regions = root.get() or {}
    count = 0

    for region_name, pois in all_regions.items():
        for poi_id, poi_data in pois.items():
            if poi_data.get("cleared") is True:
                poi_ref = db.reference(f"/poi_state/{region_name}/{poi_id}")
                # Example reset logic — feel free to expand
                poi_data["cleared"] = False
                poi_data["danger_level"] = poi_data.get("original_danger_level", 5)
                poi_ref.set(poi_data)
                count += 1

    return count

def generate_monsters_for_tile(region: str, tile_id: str, party_cr: float = 5.0):
    """
    Combines tile danger, regional tension, and party CR to generate appropriate monsters.
    """
    tile_data = db.reference(f"/tilemap/{region}/{tile_id}").get() or {}
    region_data = db.reference(f"/regional_state/{region}").get() or {}
    monsters = db.reference("/rules/monsters").get() or {}

    if not monsters:
        return []

    tile_danger = tile_data.get("danger_score", 5)
    tension = region_data.get("tension_score", 25)

    # Base CR estimate from danger
    base_cr = tile_danger * 0.4
    tension_mod = (tension - 25) / 50  # +/- 0.5 at extremes
    est_cr = base_cr + tension_mod

    # Clamp to within +/- 1.5 of party CR
    min_cr = max(0, round(min(party_cr - 1.5, est_cr - 1.0), 2))
    max_cr = round(max(party_cr + 1.5, est_cr + 1.0), 2)

    valid = [
        m for m in monsters.values()
        if min_cr <= m.get("challenge_rating", 0) <= max_cr
    ]

    return random.sample(valid, min(3, len(valid)))

def attempt_rest(region_name, poi_id, character=None):
    """
    Resolves a long rest attempt at the given POI.
    Rotates motifs, clears status effects, and resets cooldowns if safe.
    """
    ref = db.reference(f"/poi_state/{region_name}/{poi_id}")
    poi = ref.get() or {}

    danger_level = poi.get("danger_level", 5)
    safe_tags = poi.get("state_tags", [])
    is_safe = danger_level < 4 or "cleared" in safe_tags or "settlement" in safe_tags

    result = {"region": region_name, "poi": poi_id, "rest_successful": is_safe}

    if not character or not is_safe:
        return result

    char_id = character.get("id")
    char_ref = db.reference(f"/players/{char_id}")
    char_data = char_ref.get()

    # 🔁 Motif rotation
    motif_pool = char_data.get("narrative_motif_pool", {})
    active = motif_pool.get("active_motifs", [])
    rotated = []
    for motif in active:
        motif["entropy_tick"] = 0
        rotated.append(motif)
    motif_pool["active_motifs"] = rotated
    motif_pool["last_rotated"] = datetime.utcnow().isoformat()
    char_data["narrative_motif_pool"] = motif_pool

    # 💥 Clear temporary status effects
    char_data["status_effects"] = []

    # 🔁 Reset cooldowns (example placeholder)
    for feat in char_data.get("feats", []):
        if "cooldown" in feat:
            feat["cooldown"] = 0

    # ✅ Restore HP and MP
    char_data["attributes"]["HP"] = char_data["attributes"].get("HP_max", char_data["attributes"].get("HP", 0))
    char_data["attributes"]["MP"] = char_data["attributes"].get("MP_max", char_data["attributes"].get("MP", 0))

    # Save
    char_ref.set(char_data)
    result["character"] = char_id
    result["rest_successful"] = True
    return result

def generate_social_poi(region_id, x, y, size="village"):
    poi_id = f"poi_{x}_{y}_{uuid4().hex[:6]}"
    poi_data = {
        "name": f"Social POI {x},{y}",
        "tags": ["social"],
        "size": size,
        "danger_level": random.randint(2, 5),
        "state_tags": ["inhabited"],
        "location": {"x": x, "y": y},
        "terrain": "grassland",  # Will be updated if needed
        "buildings": [],
        "npcs_present": [],
        "control_status": "friendly"
    }

    poi_ref = db.reference(f"/poi_state/{region_id}/{poi_id}")
    poi_ref.set(poi_data)

    # 🏗️ Step 1: Enrich with buildings
    poi_data = enrich_poi_with_buildings(region_id, poi_id, poi_data)

    # 🧑‍🤝‍🧑 Step 2: Seed NPCs
    generate_npcs_for_poi(region_id, poi_id)

    print(f"[POI CREATED] {poi_id} in {region_id} enriched with NPCs and buildings.")
    return poi_id

def generate_tile(x: int, y: int, region_id: str) -> dict:
    """
    Generates a new tile at (x, y) based on neighboring tiles.
    Picks from neighbor terrain types if available, otherwise random.
    """
    neighbors = [(x-1, y), (x+1, y), (x, y-1), (x, y+1)]
    neighbor_terrains = []

    for nx, ny in neighbors:
        neighbor_terrain = db.reference(f"/terrain_map/{nx}_{ny}").get()
        if neighbor_terrain:
            neighbor_terrains.append(neighbor_terrain)

    if neighbor_terrains:
        terrain = random.choice(neighbor_terrains)
    else:
        terrain_list = ["forest", "plains", "mountain", "desert", "swamp", "coast"]
        terrain = random.choice(terrain_list)

    coord_str = f"{x}_{y}"

    db.reference(f"/locations/{coord_str}").set({
        "region": region_id,
        "tags": [terrain],
        "terrain_type": terrain
    })
    db.reference(f"/terrain_map/{coord_str}").set(terrain)

    return {"message": f"Tile {coord_str} generated.", "terrain": terrain}