
#This route module manages:
#Region state (GET/POST/DELETE)
#Global event logging (with rumor propagation)
#Player questlog access
#It serves as the gateway for regional updates, world memory, and region-linked quest tracking.
#It connects with region, world_log, npc, questlog, and rumor systems.

from app.regions.region_generation_utils import generate_region
from flask import Blueprint, request, jsonify
from firebase_admin import db
from datetime import datetime
from app.regions.worldgen_utils import log_world_event
from app.npc.npc_rumor_utils import sync_event_beliefs
import json
import random

# Preload terrain tags from JSON
with open("rules_json/land_types.json") as f:
    LAND_TYPES = json.load(f)

ALL_TERRAINS = list(LAND_TYPES.keys())

region_bp = Blueprint('region_management', __name__)

@region_bp.route('/region/<region_id>', methods=['GET'])
def get_region(region_id):
    region_ref = db.reference(f'/regions/{region_id}')
    region_data = region_ref.get()
    if not region_data:
        return jsonify({"error": "Region not found."}), 404
    return jsonify(region_data)

@region_bp.route('/region/<region_id>', methods=['POST'])
def update_region(region_id):
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided."}), 400
    data["last_updated"] = datetime.utcnow().isoformat()
    region_ref = db.reference(f'/regions/{region_id}')
    region_ref.update(data)
    return jsonify({"message": "Region updated.", "region": data})

@region_bp.route('/region/<region_id>', methods=['DELETE'])
def delete_region(region_id):
    region_ref = db.reference(f'/regions/{region_id}')
    if not region_ref.get():
        return jsonify({"error": "Region not found."}), 404
    region_ref.delete()
    return jsonify({"message": "Region deleted."})

@region_bp.route('/log_event_and_notify_npcs', methods=['POST'])
def route_log_event_and_notify_npcs():
    data = request.json
    if not data:
        return jsonify({"error": "Missing event data"}), 400

    region = data.get("region")
    if not region:
        return jsonify({"error": "Missing region name"}), 400

    try:
        event = log_world_event(data)
        count = sync_event_beliefs(region, event)
        return jsonify({
            "message": f"Event logged and shared with {count} NPCs.",
            "event_id": event["event_id"],
            "region": region
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@region_bp.route('/questlog/<character_id>', methods=['GET'])
def get_questlog(character_id):
    questlog = db.reference(f'/questlogs/{character_id}').get() or []
    return jsonify({"character_id": character_id, "questlog": questlog})

@region_bp.route('/questlog/<character_id>', methods=['POST'])
def add_quest(character_id):
    data = request.get_json()
    quest = data.get("quest")
    if not quest:
        return jsonify({"error": "Quest data required."}), 400

    quest_entry = {
        "quest": quest,
        "timestamp": datetime.utcnow().isoformat()
    }

    questlog_ref = db.reference(f'/questlogs/{character_id}')
    questlog = questlog_ref.get() or []
    questlog.append(quest_entry)
    questlog_ref.set(questlog)

    return jsonify({"message": "Quest added.", "quest_entry": quest_entry})

@region_bp.route("/region_map/<region_id>", methods=["GET"])
def get_region_map(region_id):
    """
    Fetch the full tile map for a region.
    This expects terrain tiles under /region_maps/<region_id>/tiles/
    and returns them in { "tiles": { coord: {tags, poi} } } format.
    """
    try:
        # 🔥 Correct path: pull from /region_maps/<region_id>/tiles
        tiles = db.reference(f"/region_maps/{region_id}/tiles").get() or {}

        # Send back exactly what frontend expects
        return jsonify({"tiles": tiles})
    
    except Exception as e:
        print(f"❌ Error fetching region map: {str(e)}")
        return jsonify({"error": str(e)}), 500

@region_bp.route('/region_seed/<region_id>', methods=['POST'])
def seed_region(region_id):
    """
    Seeds a basic 10x10 region with clustered terrain tags.
    """
    try:
        import random

        terrain_types = [
            "forest", "plains", "mountain", "swamp", "coast", "desert"
        ]

        width = 10
        height = 10
        new_tiles = {}

        # Start with empty map
        terrain_map = [[None for _ in range(height)] for _ in range(width)]

        # Scatter initial seeds
        for _ in range(8):  # number of seeds
            tx = random.randint(0, width - 1)
            ty = random.randint(0, height - 1)
            terrain = random.choice(terrain_types)
            terrain_map[tx][ty] = terrain

        # Spread seeds outward
        for x in range(width):
            for y in range(height):
                if not terrain_map[x][y]:
                    neighbors = []

                    # Check neighboring tiles
                    for dx in [-1, 0, 1]:
                        for dy in [-1, 0, 1]:
                            nx, ny = x + dx, y + dy
                            if 0 <= nx < width and 0 <= ny < height:
                                if terrain_map[nx][ny]:
                                    neighbors.append(terrain_map[nx][ny])

                    if neighbors:
                        terrain_map[x][y] = random.choice(neighbors)
                    else:
                        terrain_map[x][y] = random.choice(terrain_types)

        # Save final terrain map into tiles
        for x in range(width):
            for y in range(height):
                new_tiles[f"{x}_{y}"] = {
                    "tags": [terrain_map[x][y]],
                    "poi": None
                }

        db.reference(f'/region_maps/{region_id}').set({"tiles": new_tiles})

        return jsonify({"message": f"Region '{region_id}' seeded successfully."})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@region_bp.route('/generate_region', methods=['POST'])
def generate_region_route():
    """
    POST /generate_region
    JSON body: { "seed_x": 0, "seed_y": 0 }
    Creates a new region with starting coordinates.
    """
    try:
        data = request.get_json(force=True) if request.data else {}
        seed_x = int(data.get("seed_x", 0))
        seed_y = int(data.get("seed_y", 0))

        result = generate_region(seed_x, seed_y)

        return jsonify({
            "message": f"Region '{result['region_id']}' generated successfully.",
            "region_id": result["region_id"],
            "tiles_created": result["tiles_created"]
        }), 200

    except Exception as e:
        import traceback
        print("❌ Error in /generate_region:", traceback.format_exc())
        return jsonify({"error": str(e)}), 500

@region_bp.route('/generate_new_region', methods=['POST'])
def generate_new_region_route():
    """
    Shortcut to generate a new region at 0,0.
    """
    try:
        result = generate_region(seed_x=0, seed_y=0)
        return jsonify({
            "message": f"Region '{result['region_id']}' generated successfully.",
            "region_id": result["region_id"],
            "tiles_created": result["tiles_created"]
        }), 200
    except Exception as e:
        import traceback
        print("❌ Error in /generate_new_region:", traceback.format_exc())
        return jsonify({"error": str(e)}), 500