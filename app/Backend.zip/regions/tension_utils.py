
#This module handles region-level narrative pressure via the tension system, including:
#Retrieval and decay of tension
#Modifiers by source
#Arc escalation based on thresholds
#GPT-based arc creation if none exists
#It connects deeply with region, tension, arc, gpt, and world state systems.

from datetime import datetime
from firebase_admin import db
from app.utils.gpt_class import GPTClient

import json

# Constants
tension_levels = [
    (0, 10, "peaceful"),
    (11, 30, "watchful"),
    (31, 60, "anxious"),
    (61, 80, "violent"),
    (81, 100, "collapsing")
]

# Helper function to get the descriptor based on tension level
def get_tension_descriptor(level):
    for low, high, label in tension_levels:
        if low <= level <= high:
            return label
    return "unknown"

# Retrieve current tension data for a region
def get_tension(region_id):
    ref = db.reference(f"/regions/{region_id}/tension")
    data = ref.get() or {"level": 0, "modifiers": {}}
    level = data.get("level", 0)
    label = get_tension_descriptor(level)
    return {
        "region": region_id,
        "level": level,
        "label": label,
        "modifiers": data.get("modifiers", {})
    }

# Modify the tension level for a region based on a specific source

def modify_tension(region_id, source, amount):
    ref = db.reference(f"/regions/{region_id}/tension")
    data = ref.get() or {"level": 0, "modifiers": {}}

    modifiers = data.get("modifiers", {})
    modifiers[source] = modifiers.get(source, 0) + amount

    level_sum = max(0, min(sum(modifiers.values()), 100))
    label = get_tension_descriptor(level_sum)

    data.update({
        "level": level_sum,
        "modifiers": modifiers,
        "last_modified": datetime.utcnow().isoformat()
    })
    ref.set(data)

    # 🔥 Arc evolution trigger
    if label in ["violent", "collapsing"]:
        update_region_arc_with_tension(region_id, source)

    return get_tension(region_id)

# Reset tension to default state
def reset_tension(region_id):
    ref = db.reference(f"/regions/{region_id}/tension")
    ref.set({
        "level": 0,
        "modifiers": {},
        "last_modified": datetime.utcnow().isoformat()
    })
    return get_tension(region_id)

# Gradually decay the tension level over time
def decay_tension(region_id, decay_rate=1):
    ref = db.reference(f"/regions/{region_id}/tension")
    data = ref.get() or {}
    if not data:
        return {"error": "No tension data for this region"}

    modifiers = data.get("modifiers", {})
    updated_modifiers = {}
    for k, v in modifiers.items():
        if abs(v) > decay_rate:
            updated_modifiers[k] = v - decay_rate if v > 0 else v + decay_rate

    level_sum = max(0, min(sum(updated_modifiers.values()), 100))

    data.update({
        "level": level_sum,
        "modifiers": updated_modifiers,
        "last_modified": datetime.utcnow().isoformat()
    })
    ref.set(data)

    return get_tension(region_id)

def update_region_arc_with_tension(region_id: str, source: str):
    """
    Evolves a regional arc stored at /regions/<region_id>/arc
    based on tension events (e.g. from modify_tension).
    """
    arc_ref = db.reference(f"/regions/{region_id}/arc")
    arc_data = arc_ref.get()
    milestone = f"Tension spike from {source}"

    if not arc_data:
        # Create a new arc if missing
        system_prompt = "You are a fantasy campaign designer. Create arc titles and themes based on unrest."
        user_prompt = f"Write a JSON {{ title, theme }} for a region experiencing instability due to: {source}"

        try:
            gpt = GPTClient()
            response = gpt.call(system_prompt, user_prompt, temperature=0.7, max_tokens=100)
            parsed = json.loads(response)
        except Exception:
            parsed = {"title": "Unrest Brews", "theme": "instability"}

        arc_data = {
            "title": parsed.get("title", "Unrest Brews"),
            "theme": parsed.get("theme", "instability"),
            "milestones": [milestone],
            "current_stage": 1,
            "geo_tags": [],
            "last_updated": datetime.utcnow().isoformat(),
            "completed": False
        }
    else:
        arc_data["milestones"].append(milestone)
        arc_data["current_stage"] += 1
        arc_data["last_updated"] = datetime.utcnow().isoformat()

    arc_ref.set(arc_data)
    return arc_data


def check_for_region_conflict(tension_threshold=50, friction_threshold=0.4):
    """
    Check for conflict between regions based on ruling faction tension and attunement.
    Logs either 'war' or 'civil_war' to each region's conflict_log.
    """
    regional_data = db.reference("/regional_state").get() or {}
    conflict_pairs = []

    # Build a lookup of ruling faction origins
    faction_meta = db.reference("/factions").get() or {}
    faction_home = {fid: meta.get("home_region", "unknown") for fid, meta in faction_meta.items()}

    for region_name, data in regional_data.items():
        ruling = data.get("ruling_faction")
        tension = data.get("tension_score", 0)
        friction = data.get("friction_score", 0)

        if not ruling or tension < tension_threshold or friction < friction_threshold:
            continue

        for other_region, other_data in regional_data.items():
            if region_name == other_region:
                continue

            other_ruler = other_data.get("ruling_faction")
            if not other_ruler:
                continue

            if other_ruler == ruling:
                # Check for Civil War
                if faction_home.get(ruling) == region_name:
                    conflict_type = "civil_war"
                else:
                    continue
            else:
                # Inter-regional war
                conflict_type = "war"

            log_entry = {
                "type": conflict_type,
                "with_region": other_region,
                "against": other_ruler,
                "timestamp": datetime.utcnow().isoformat()
            }

            db.reference(f"/regional_state/{region_name}/conflict_log").push(log_entry)
            conflict_pairs.append((region_name, other_region, conflict_type))

    return conflict_pairs

def decay_region_tension():
    region_root = db.reference("/regional_state").get() or {}

    for region_name, region_data in region_root.items():
        score_ref = db.reference(f"/regional_state/{region_name}/tension_score")
        score = score_ref.get() or 0
        modifier = -1  # base decay

        # Check for war status
        if region_data.get("war_state", "") == "active":
            modifier = 0  # no decay

        # Check motif pressure
        motifs = region_data.get("motif_pool", {}).get("active_motifs", [])
        dangerous_themes = [m.get("theme") for m in motifs if m.get("theme") in [14, 2, 32, 5]]  # e.g., madness, vengeance, chaos, betrayal

        if dangerous_themes:
            modifier += len(dangerous_themes) // 2  # each 2 chaos motifs = +1 tension

        # Optional blessing state
        if "blessed" in region_data.get("state_tags", []):
            modifier -= 1  # further reduce tension

        if score + modifier < 0:
            modifier = -score  # don’t go below 0

        if modifier != 0:
            new_score = score + modifier
            score_ref.set(new_score)

            # Log decay or rise
            log_ref = db.reference(f"/regional_state/{region_name}/tension_log")
            log = log_ref.get() or []
            log.append({
                "source": "natural_decay" if modifier < 0 else "motif_pressure",
                "delta": modifier,
                "timestamp": datetime.utcnow().isoformat()
            })
            log_ref.set(log)

def check_faction_war_triggers():
    region_root = db.reference("/regional_state").get() or {}

    for region_name, region in region_root.items():
        tension = region.get("tension_score", 0)
        factions = region.get("factions_present", [])
        war_state = region.get("war_state", "peace")

        if war_state == "active" or tension < 15:
            continue

        # Check each faction pair for hostility
        for i in range(len(factions)):
            for j in range(i + 1, len(factions)):
                a = factions[i]
                b = factions[j]

                rel_score = db.reference(f"/factions/{a}/relationships/{b}").get() or 0
                if rel_score <= -10:
                    # Trigger war
                    db.reference(f"/regional_state/{region_name}/war_state").set("active")

                    db.reference(f"/regional_state/{region_name}/war_log").push({
                        "factions": [a, b],
                        "triggered_by": "high_tension + hostility",
                        "tension_score": tension,
                        "timestamp": datetime.utcnow().isoformat()
                    })

                    db.reference("/dm_events").push({
                        "type": "war_outbreak",
                        "region": region_name,
                        "factions": [a, b],
                        "timestamp": datetime.utcnow().isoformat()
                    })

                    break