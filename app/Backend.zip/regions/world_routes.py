from app.regions.region_generation_utils import generate_region
from firebase_admin import db
from flask import Blueprint, jsonify, request

world_bp = Blueprint("world_bootstrap", __name__)

@world_bp.route('/generate_initial_world', methods=['POST'])
def generate_initial_world():
    """
    Creates a world, stores it as the default /global_state/home_region.
    """
    try:
        region_id, region_data = generate_region()

        # Save as default starting region
        db.reference("/global_state/home_region").set(region_id)

        return jsonify({
            "message": f"World generated with starting region {region_id}.",
            "region_id": region_id,
            "tiles_created": len(region_data.get("tiles", {})),
            "poi_count": len(region_data.get("poi_list", []))
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route("/world_summary", methods=["GET"])
def get_world_summary():
    try:
        global_state = db.reference("/global_state").get() or {}
        regional_state = db.reference("/regional_state").get() or {}
        poi_state = db.reference("/poi_state").get() or {}

        summary = {
            "global_state": global_state,
            "regional_state": regional_state,
            "poi_state": poi_state
        }
        return jsonify(summary)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route("/tick_world", methods=["POST"])
def tick_world():
    try:
        # Just a placeholder tick
        return jsonify({"message": "World tick processed."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/global_state', methods=['GET'])
def get_global_state():
    """
    Fetches the current global state document.
    """
    try:
        global_state = db.reference("/global_state").get() or {}
        return jsonify(global_state)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@world_bp.route('/global_state/update', methods=['POST'])
def update_global_state():
    """
    Updates the global state document with provided fields.
    """
    try:
        data = request.get_json(force=True)
        db.reference("/global_state").update(data)
        return jsonify({"message": "Global state updated successfully."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

