
#This module compiles a comprehensive narrative context bundle for GPT-powered Dungeon Master interactions. It pulls motifs, region arcs, tension levels, memory logs, and faction affiliations from Firebase and internal engines.
#It fully integrates with narrative, motif, firebase, memory, npc, faction, and chaos systems.

from firebase_admin import db
from app.memory.memory_utils import get_recent_interactions
from app.motifs.motif_engine_class import MotifEngine
from app.regions.tension_utils import get_tension
from app.utils.gpt_class import GPTClient
from functools import lru_cache
from datetime import datetime, timedelta
from app.dm_engine.dm_utils import MOTIF_THEME_NAMES

_context_cache = {}
_CONTEXT_TTL = timedelta(seconds=30)  # Cache for 30 seconds

def fetch_faction_name(fid):
    faction = db.reference(f"/factions/{fid}").get()
    if not faction:
        return {"id": fid, "name": fid, "description": ""}
    return {
        "id": fid,
        "name": faction.get("name", fid),
        "description": faction.get("description", "")
    }


def gather_dm_context(character_id: str, npc_id: str = None) -> dict:
    """
    Returns a context bundle for GPT-powered DM interaction.
    Uses memoization to avoid redundant Firebase queries within a short TTL window.
    """
    now = datetime.utcnow()
    cache_key = f"{character_id}:{npc_id}"
    
    # === Check for valid cache hit ===
    if cache_key in _context_cache:
        cached = _context_cache[cache_key]
        if now - cached["timestamp"] < _CONTEXT_TTL:
            return cached["data"]

    context = {}

    # === Player motifs ===
    player_motifs = []
    player_data = db.reference(f"/players/{character_id}").get()
    if not player_data:
        player_data = {"region_id": "capital_hub"}  # fallback for new characters

    region_id = player_data.get("region_id", "unknown_region")

    try:
        engine = MotifEngine(character_id)
        for m in engine.get_active_motifs():
            player_motifs.append(f"{m['theme']} (weight {m['weight']})")
    except Exception:
        pass

    # === Region tension ===
    try:
        tension = get_tension(region_id)
    except Exception:
        tension = {"level": 0, "label": "unknown"}

    # === Region arc (optional, last milestone only) ===
    arc = db.reference(f"/regions/{region_id}/arc").get()
    arc_info = {
        "title": arc.get("title") if arc else None,
        "theme": arc.get("theme") if arc else None,
        "latest_milestone": arc.get("milestones", [])[-1] if arc and arc.get("milestones") else None
    }

    # === Chaos check (optional narrative flag) ===
    chaos_log = db.reference("/global_state/world_log").get() or {}
    recent_chaos = [
        e for e in chaos_log.values()
        if e.get("type") == "narrative_chaos" and
           (now.timestamp() - datetime.fromisoformat(e["timestamp"]).timestamp()) < 3600
    ]
    context["recent_chaos_event"] = recent_chaos[-1] if recent_chaos else None

    # === NPC motifs (if applicable) ===
    npc_motifs = []
    if npc_id:
        try:
            engine = MotifEngine(npc_id)
            for m in engine.get_active_motifs():
                npc_motifs.append(f"{m['theme']} (weight {m['weight']})")
        except Exception:
            pass

    # === NPC rumors ===
    rumors = []
    if npc_id:
        rumor_log = db.reference(f"/npc_memory/{npc_id}/rag_log").get() or []
        rumors = [entry.get("interaction") for entry in rumor_log[-3:]]

    # === NPC faction loyalty (summary) ===
    faction_loyalties = []
    if npc_id:
        affiliations = db.reference(f"/npcs/{npc_id}/faction_affiliations").get() or []
        for entry in affiliations:
            if abs(entry.get("loyalty", 0)) >= 2:
                faction = fetch_faction_name(entry["id"])
                faction_loyalties.append({
                    "name": faction["name"],
                    "loyalty": entry["loyalty"]
                })

    # === Memory context between player and NPC ===
    memory = []
    if npc_id:
        memory = get_recent_interactions(npc_id, character_id, limit=3)

    # === Return final context bundle ===
    context.update({
        "player_motifs": player_motifs,
        "npc_motifs": npc_motifs,
        "region_tension": tension,
        "region_arc": arc_info,
        "npc_faction_loyalties": faction_loyalties,
        "recent_memory": memory,
        "npc_rumors": rumors
    })

    # 💾 Cache it
    _context_cache[cache_key] = {"timestamp": now, "data": context}

    return context

def generate_npc_quest_dialogue(npc_name, quest_summary, player_known_status="neutral", show_warning=False):
    """
    Returns GPT-generated dialogue for an NPC who previously posted a quest.
    """

    prompt = f"""You're roleplaying {npc_name}, a fantasy world NPC who recently posted a quest to a town bulletin board.
The player has come to speak to you about the following quest:

'{quest_summary}'

"""

    if show_warning:
        prompt += """You believe the player might not be strong enough for this. You're worried, and your tone should reflect that. 
Speak cautiously, but let them accept the quest if they insist. 
Do NOT mention 'level' or game mechanics. Just narratively imply danger.\n"""
    else:
        prompt += """You're neutral about the player's ability. Just re-explain the quest in your own words and offer it normally.\n"""

    return call(prompt, system_prompt="You are a fantasy NPC talking to a player about a quest you posted.")

def get_tension_flavor_text(region_name):
    score = db.reference(f"/regional_state/{region_name}/tension_score").get() or 0

    if score >= 15:
        return "The region is steeped in fear and chaos. Even simple requests might lead to dangerous consequences."
    elif score >= 10:
        return "Tension runs high in this area. Locals are on edge. Factions are preparing for something."
    elif score >= 5:
        return "There's unease in the air. People speak in whispers and rumors flow freely."
    else:
        return "The region is relatively calm — for now."

def generate_region_narration_context(region_name):
    ref = db.reference(f"/regional_state/{region_name}")
    region = ref.get() or {}
    context_lines = []

    # Tension
    tension = region.get("tension_score", 0)
    if tension >= 15:
        context_lines.append("Tension in the region is critically high. Chaos is imminent.")
    elif tension >= 10:
        context_lines.append("Tension runs high. People are uneasy and rumors spread quickly.")
    elif tension >= 5:
        context_lines.append("The region is restless. Whispers and suspicion are common.")
    else:
        context_lines.append("The region is relatively calm and orderly.")

    # Motifs
    motif_data = region.get("motif_pool", {}).get("active_motifs", [])
    motif_ids = [m.get("theme") for m in motif_data]
    names = [MOTIF_THEME_NAMES.get(mid, f"Unknown({mid})") for mid in motif_ids]
    if names:
        context_lines.append(f"Active regional motifs: {names}")

    return "\n".join(context_lines)


def generate_npc_quest_reminder(npc_id, player_id=None):
    """
    Builds a GPT call where an NPC reminds or re-pitches their posted quest.
    """
    posted = db.reference(f"/npcs/{npc_id}/posted_quests").get() or []
    if not posted:
        return ""

    # Get most recent posted quest
    latest_quest_id = posted[-1]
    quest = None

    # Look in player's questlog to see if it's active
    if player_id:
        log = db.reference(f"/players/{player_id}/questlog").get() or []
        for q in log:
            if q.get("id") == latest_quest_id:
                quest = q
                break

    if not quest:
        # Look up globally
        all_quests = db.reference("/quests/generated").get() or {}
        quest = all_quests.get(latest_quest_id)

    if not quest:
        return ""

    summary = quest.get("summary", "I need help with something...")

    prompt = f"""You are roleplaying {npc_id}, a fantasy NPC who recently posted a quest.
The quest summary is: '{summary}'.

You are talking to the player now. Remind them about the quest and ask if they’re still interested.
If they’ve already taken it, express appreciation or give a brief update or warning.
Keep it in-world. Do not reference game mechanics or levels."""
    
    return call(prompt, system_prompt="You are a fantasy NPC giving quest reminders.")
