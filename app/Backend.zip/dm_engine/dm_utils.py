
# This is a compact DM utility module that helps classify prompts and narrate combat outcomes using GPT. It’s a support file used by dm_engine.py and related GPT routes.
#It integrates with gpt, narrative, and combat layers.

from app.npc.npc_relationships_utils import get_relationship_tier
from app.utils.gpt_class import GPTClient
from firebase_admin import db
from datetime import datetime
import openai
import logging

MOTIF_THEME_NAMES = {
    1: "paranoia",
    2: "vengeance",
    3: "greed",
    4: "honor",
    5: "betrayal",
    6: "forgiveness",
    7: "redemption",
    8: "despair",
    9: "loyalty",
    10: "loss",
    11: "ambition",
    12: "fear",
    13: "doubt",
    14: "madness",
    15: "grief",
    16: "curiosity",
    17: "justice",
    18: "hope",
    19: "peace",
    20: "conflict",
    21: "obsession",
    22: "shame",
    23: "revenge",
    24: "sacrifice",
    25: "duty",
    26: "resilience",
    27: "nostalgia",
    28: "melancholy",
    29: "conspiracy",
    30: "transcendence",
    31: "divine will",
    32: "chaos",
    33: "restoration",
    34: "temptation",
    35: "survival",
    36: "decay",
    37: "awakening",
    38: "regret",
    39: "discipline",
    40: "freedom",
    41: "tradition",
    42: "innovation",
    43: "identity",
    44: "reckoning",
    45: "fate",
    46: "entropy",
    47: "repression",
    48: "miracles",
    49: "isolation",
    50: "secrets"
}

def classify_request(prompt: str, character_id: str = None) -> str:
    """
    Classifies user prompt into 'mechanical', 'npc', or 'narrative'.
    Logs result for future refinement or RLHF-style correction.
    """
    prompt_lower = prompt.lower()

    if any(word in prompt_lower for word in ["roll", "hit", "attack", "damage", "ac", "initiative"]):
        classification = "mechanical"
    elif any(word in prompt_lower for word in ["say", "ask", "tell", "respond", "talk"]):
        classification = "npc"
    else:
        classification = "narrative"

    # 🔁 Log to Firebase
    if character_id:
        log_ref = db.reference(f"/classification_log/{character_id}")
        log_ref.push({
            "timestamp": datetime.utcnow().isoformat(),
            "prompt": prompt,
            "classification": classification,
            "override": None  # Placeholder for feedback later
        })

    return classification

def narrate_combat_action(actor_name, action_data, outcome):
    """
    Converts a tactical combat action into flavorful prose.
    """
    prompt = (
        f"{actor_name} used {action_data.get('ability', 'an action')} on {action_data.get('target')}.\n"
        f"The attack {'hit' if outcome.get('hit') else 'missed'} and dealt {outcome.get('damage', 0)} "
        f"{outcome.get('damage_type', 'damage')}.\n"
        f"Target HP after the attack: {outcome.get('target_hp')}.\n\n"
        "Write a vivid, 2–4 sentence cinematic description of this moment."
    )

    return call(
        system_prompt="You are a fantasy combat narrator describing vivid battle scenes.",
        user_prompt=prompt,
        temperature=0.9,
        max_tokens=150
    )

def gather_motifs_for_context(npc_id=None, region=None, poi_id=None):
    context_lines = []

def resolve_names(input_text, npc_list, alias_map=None, relationship_map=None):
    import difflib
    input_text = input_text.strip().lower()

    if alias_map and input_text in alias_map:
        npc_id = alias_map[input_text]
        match = next((n for n in npc_list if n['id'] == npc_id), None)
        if match:
            return {'resolved_name': match['name'], 'npc_id': npc_id, 'match_type': 'alias'}

    if relationship_map and input_text in relationship_map:
        npc_id = relationship_map[input_text]
        match = next((n for n in npc_list if n['id'] == npc_id), None)
        if match:
            return {'resolved_name': match['name'], 'npc_id': npc_id, 'match_type': 'relationship'}

    names = [n['name'].lower() for n in npc_list]
    match = difflib.get_close_matches(input_text, names, n=1, cutoff=0.6)
    if match:
        resolved = next(n for n in npc_list if n['name'].lower() == match[0])
        return {'resolved_name': resolved['name'], 'npc_id': resolved['id'], 'match_type': 'fuzzy'}

    return {'resolved_name': input_text, 'npc_id': None, 'match_type': 'unknown'}

def gather_relationship_context(npc_id, pc_id):
    try:
        tier = get_relationship_tier(npc_id, pc_id)
        return f"{npc_id} considers the player a {tier}."
    except:
        return ""
    
def gather_faction_context(npc_id, pc_id):
    npc_factions = db.reference(f"/npcs/{npc_id}/faction_opinions").get() or {}
    pc_factions = db.reference(f"/pcs/{pc_id}/faction_affiliations").get() or []

    hostile_factions = [
        f for f in pc_factions if npc_factions.get(f, 0) <= -10
    ]

    if hostile_factions:
        return f"{npc_id} harbors hostility toward factions: {hostile_factions}."
    return ""
