
#This module simulates faction influence propagation through Points of Interest (POIs) using a BFS-style algorithm. It decays influence across connections and records results per POI in Firebase.
#It’s directly tied to faction, world, region, and poi systems.

import random
from firebase_admin import db
from collections import deque
from datetime import datetime

def log_poi_event(region, poi_id, event_type, data=None):
    """
    Append a new event to a POI's /event_log
    """
    ref = db.reference(f"/poi_state/{region}/{poi_id}/evolution_state/event_log")
    event_log = ref.get() or []

    entry = {
        "type": event_type,
        "day": get_current_game_day(),
        "timestamp": datetime.utcnow().isoformat()
    }
    if data:
        entry.update(data)

    event_log.append(entry)
    ref.set(event_log)

def get_all_poi_states():
    """
    Fetch and flatten all POI state data.
    Returns a dict of { poi_id: {state...} }
    """
    poi_root = db.reference("/poi_state").get() or {}
    flat = {}
    for region, pois in poi_root.items():
        for poi_id, poi_data in pois.items():
            poi_data["region"] = region  # preserve region info
            flat[poi_id] = poi_data
    return flat

def propagate_faction_influence():
    """
    Scans all factions and spreads their influence outward from origin POIs.
    Also attempts to spread faction affiliation to NPCs.
    """
    all_factions = db.reference("/factions").get() or {}
    poi_root = db.reference("/poi_state").get() or {}

    for fid, faction in all_factions.items():
        seeds = faction.get("poi_outposts", [])
        visited = set()

        for seed in seeds:
            for region_name, region_pois in poi_root.items():
                if seed not in region_pois:
                    continue

                queue = deque([(region_name, seed, 10)])  # (region, poi_id, influence)
                while queue:
                    region, poi_id, influence = queue.popleft()
                    if (region, poi_id) in visited or influence <= 0:
                        continue
                    visited.add((region, poi_id))

                    poi_ref = db.reference(f"/poi_state/{region}/{poi_id}/faction_influence/{fid}")
                    current = poi_ref.get() or 0
                    poi_ref.set(max(current, influence))

                    # Find connected POIs (neighbors)
                    region_map = db.reference(f"/poi_state/{region}").get() or {}
                    neighbors = region_map.get(poi_id, {}).get("connected_pois", [])
                    random.shuffle(neighbors)

                    for neighbor in neighbors:
                        if (region, neighbor) not in visited:
                            # Optional mutation chance
                            mutation_chance = 0.1 if influence < 6 else 0.02
                            decay = random.randint(1, 2)
                            next_influence = influence - decay

                            if random.random() < mutation_chance:
                                next_influence = max(0, next_influence - random.randint(1, 3))

                            queue.append((region, neighbor, next_influence))

        # 👇 After BFS ends for this faction, try spreading to NPCs
        poi_data_map = get_all_poi_states()
        propagate_faction_to_npcs(fid, {}, poi_data_map)

def propagate_faction_to_npcs(faction_id, region_data, poi_data_map):
    """
    Influence NPC faction affiliations in POIs where the faction is active.
    """
    influence_log = []
    for poi_id, poi_data in poi_data_map.items():
        npcs = poi_data.get("npcs_present", [])
        if faction_id not in poi_data.get("faction_influence", []):
            continue

        for npc_id in npcs:
            npc_ref = db.reference(f'/npc_core/{npc_id}')
            npc_data = npc_ref.get() or {}
            affiliations = npc_data.get("faction_affiliations", [])
            
            # Already affiliated? Skip or deepen loyalty
            if faction_id in affiliations:
                continue

            # Influence chance can be tied to loyalty, fear, rumors, etc.
            chance = 0.15 + 0.05 * poi_data.get("danger_level", 5)
            if random.random() < chance:
                affiliations.append(faction_id)
                npc_data["faction_affiliations"] = affiliations
                npc_ref.set(npc_data)
                influence_log.append({"npc": npc_id, "poi": poi_id, "method": "proximity"})

    return influence_log

