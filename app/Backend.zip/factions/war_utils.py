from firebase_admin import db
from datetime import datetime, timedelta
import random
from app.npc.npc_character_routes import create_npc
from app.utils.gpt_class import GPTClient

WAR_TIMER_DURATION = 30

def initialize_war(region_a, region_b, faction_a, faction_b):
    """
    Initializes war state between two regions.
    """
    now = datetime.utcnow().isoformat()
    base = {
        "opposing_region": region_b,
        "war_timer": WAR_TIMER_DURATION,
        "days_in_conflict": 0,
        "last_conquest_day": 0,
        "cities_lost": 0,
        "active_faction": faction_a,
        "defending_faction": faction_b,
        "start_date": now
    }
    db.reference(f"/regional_state/{region_a}/conflict_status").set("war")
    db.reference(f"/regional_state/{region_a}/war_state").set(base)

    reverse = base.copy()
    reverse["opposing_region"] = region_a
    reverse["active_faction"] = faction_b
    reverse["defending_faction"] = faction_a
    db.reference(f"/regional_state/{region_b}/conflict_status").set("war")
    db.reference(f"/regional_state/{region_b}/war_state").set(reverse)

    return {"message": f"War initialized between {region_a} and {region_b}"}


def advance_war_day(region):
    """
    Advances the war state by one day and checks for win/loss conditions.
    """
    war_ref = db.reference(f"/regional_state/{region}/war_state")
    war_data = war_ref.get()
    if not war_data:
        return {"error": f"No war data for region {region}"}

    war_data["war_timer"] -= 1
    war_data["days_in_conflict"] += 1

    # End war if timer reaches 0
    if war_data["war_timer"] <= 0:
        result = evaluate_war_outcome(region, war_data)
        db.reference(f"/regional_state/{region}/conflict_status").set("peace")
        db.reference(f"/regional_state/{region}/war_state").delete()
        return result

    war_ref.set(war_data)
    return {"message": f"Day advanced. War timer is now {war_data['war_timer']}"}


def record_poi_conquest(region, poi_id, conquering_faction):
    """
    Marks a POI as conquered and resets the war timer.
    """
    poi_ref = db.reference(f"/poi_state/{region}/{poi_id}")
    poi_ref.child("control_status").set(conquering_faction)

    war_ref = db.reference(f"/regional_state/{region}/war_state")
    war_data = war_ref.get()
    if not war_data:
        return

    war_data["war_timer"] = WAR_TIMER_DURATION
    war_data["last_conquest_day"] = war_data["days_in_conflict"]
    war_data["cities_lost"] += 1
    war_ref.set(war_data)


def evaluate_war_outcome(region, war_data):
    """
    Determines the outcome of war based on city losses.
    """
    cities_lost = war_data.get("cities_lost", 0)
    opposing_region = war_data.get("opposing_region")

    # Placeholder logic — refine as needed
    if cities_lost >= 3:
        # Conquest
        db.reference(f"/regional_state/{region}/ruling_faction").set(war_data["active_faction"])
        return {
            "message": f"{region} has been conquered by {war_data['active_faction']}."
        }
    else:
        return {
            "message": f"War ended without full conquest. {region} retains independence."
        }


def generate_daily_raids(region_name):
    """
    Simulates daily raid attempts on every POI in a region.
    If a Social POI is weak, it may be overrun by monsters.
    If a Dungeon POI is weak, NPCs may reclaim it.
    """
    poi_ref = db.reference(f"/poi_state/{region_name}")
    pois = poi_ref.get() or {}

    results = []

    for poi_id, poi in pois.items():
        poi_type = poi.get("poi_type", "social")
        danger = poi.get("danger_level", 5)
        npcs = poi.get("npcs_present", [])
        npc_count = len(npcs)

        # Generate a raid strength (approx monster CR level * 5 = hp budget)
        raid_strength = danger * 5 + random.randint(0, danger * 3)

        if poi_type == "social":
            defense_score = npc_count * 5 + random.randint(0, 15)
            if raid_strength > defense_score:
                # Flip to dungeon
                poi_ref.child(poi_id).child("poi_type").set("dungeon")
                db.reference(f"/poi_state/{region_name}/{poi_id}/event_log").push({
                    "type": "overrun_by_monsters",
                    "danger": danger,
                    "day": get_current_game_day()
                })
                results.append(f"{poi_id} was overrun by monsters (danger {danger}).")
        elif poi_type == "dungeon":
            # Nearby NPCs attack (simulate a small force based on danger)
            reclaim_score = danger * 6 + random.randint(0, 20)
            if reclaim_score > raid_strength:
                # Flip to social
                poi_ref.child(poi_id).child("poi_type").set("social")
                db.reference(f"/poi_state/{region_name}/{poi_id}/event_log").push({
                    "type": "reclaimed_by_npcs",
                    "day": get_current_game_day()
                })
                results.append(f"{poi_id} was reclaimed by NPCs (vs danger {danger}).")
    return results


def get_current_game_day():
    ref = db.reference("/global_state")
    return ref.get().get("current_day", 0)

def generate_daily_raids(region_name):
    """
    Simulates daily raids in a region. Logs outcomes to both POI and global world log.
    """
    poi_ref = db.reference(f"/poi_state/{region_name}")
    pois = poi_ref.get() or {}

    day = get_current_game_day()
    world_log_ref = db.reference(f"/world_log/{day}/raid_events")
    global_events = []

    for poi_id, poi in pois.items():
        poi_type = poi.get("poi_type", "social")
        danger = poi.get("danger_level", 5)
        npcs = poi.get("npcs_present", [])
        npc_count = len(npcs)

        raid_strength = danger * 5 + random.randint(0, danger * 3)

        if poi_type == "social":
            defense_score = npc_count * 5 + random.randint(0, 15)
            if raid_strength > defense_score:
                # Flip to dungeon
                poi_ref.child(poi_id).child("poi_type").set("dungeon")
                event = {
                    "type": "overrun_by_monsters",
                    "poi_id": poi_id,
                    "region": region_name,
                    "danger": danger,
                    "day": day
                }
                db.reference(f"/poi_state/{region_name}/{poi_id}/event_log").push(event)
                global_events.append(event)
        elif poi_type == "dungeon":
            reclaim_score = danger * 6 + random.randint(0, 20)
            if reclaim_score > raid_strength:
                # Flip to social
                poi_ref.child(poi_id).child("poi_type").set("social")
                event = {
                    "type": "reclaimed_by_npcs",
                    "poi_id": poi_id,
                    "region": region_name,
                    "danger": danger,
                    "day": day
                }
                db.reference(f"/poi_state/{region_name}/{poi_id}/event_log").push(event)
                global_events.append(event)

    if global_events:
        world_log_ref.set(global_events)

    return [e["type"] + ": " + e["poi_id"] for e in global_events]

def recover_damaged_pois(region_name):
    """
    Each day, attempt to repair POIs that have been damaged or overrun.
    - Slowly reduce danger level
    - Restore population if under a target
    - Flip dungeon POIs back to social after stabilization
    """
    poi_ref = db.reference(f"/poi_state/{region_name}")
    pois = poi_ref.get() or {}

    for poi_id, poi_data in pois.items():
        poi_type = poi_data.get("poi_type", "social")
        danger = poi_data.get("danger_level", 5)
        current_npcs = poi_data.get("npcs_present", [])
        max_npcs = poi_data.get("target_npc_count", 12)  # Optional field or fallback

        # Reduce danger level if above 3
        if danger > 3:
            new_danger = danger - 1
            poi_ref.child(poi_id).child("danger_level").set(new_danger)

        # Add NPCs if underpopulated
        if len(current_npcs) < max_npcs:
            new_npc = create_npc(home_poi=f"{region_name}.{poi_id}")
            current_npcs.append(new_npc["id"])
            poi_ref.child(poi_id).child("npcs_present").set(current_npcs)

        # Flip dungeon back to social if now stable
        if poi_type == "dungeon" and danger <= 2 and len(current_npcs) > 5:
            poi_ref.child(poi_id).child("poi_type").set("social")
            db.reference(f"/poi_state/{region_name}/{poi_id}/event_log").push({
                "type": "recovered_to_social",
                "day": get_current_game_day()
            })

def generate_gpt_quest_text(prompt):
    gpt = GPTClient()
    return gpt.call(
        system_prompt="You are a fantasy RPG quest designer. Generate a short summary for a quest given this context.",
        user_prompt=prompt,
        max_tokens=100
    )
