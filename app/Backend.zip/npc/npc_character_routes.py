
#This route module handles NPC creation, retrieval, updates, and deletion, acting as the API surface for persistent NPC management. It integrates with the NPCBuilder logic and Firebase persistence.
#It supports the npc, firebase, motif, memory, and faction systems.

from flask import Blueprint, request, jsonify
from firebase_admin import db
from app.npc.npc_rumor_routes import rumor_bp
from app.npc.npc_loyalty_utils import (
    build_npc_from_input,
    save_npc_to_firebase,
    load_npc_from_firebase
)

npc_bp = Blueprint("npc", __name__)

@npc_bp.route("/npc/create", methods=["POST"])
def create_npc():
    try:
        data = request.get_json(force=True)
        npc = build_npc_from_input(data)

        npc_id = npc.get("npc_id")
        if not npc_id:
            return jsonify({"error": "NPC ID missing after creation."}), 500

        save_npc_to_firebase(npc_id, npc)
        return jsonify(npc), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400


@npc_bp.route("/npc/<npc_id>", methods=["GET"])
def get_npc(npc_id):
    try:
        npc = load_npc_from_firebase(npc_id)
        if not npc:
            return jsonify({"error": f"NPC '{npc_id}' not found."}), 404
        return jsonify(npc), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 400

@npc_bp.route("/npc/<npc_id>", methods=["POST"])
def update_npc(npc_id):
    data = request.json
    if not data:
        return jsonify({"error": "No data provided"}), 400

    npc_ref = db.reference(f"/npcs/{npc_id}")
    current = npc_ref.get() or {}

    allowed_keys = {
        "name", "alignment", "inventory", "features", "location",
        "motif_entropy", "core_motifs", "party_affiliation",
        "faction_affiliations", "reputation", "hidden_traits",
        "relationships", "opinion_of_party", "backstory"
    }

    # Filter only valid keys
    sanitized = {k: v for k, v in data.items() if k in allowed_keys}
    current.update(sanitized)
    npc_ref.set(current)

    return jsonify({"npc_id": npc_id, "updated": sanitized})

@npc_bp.route("/npc/<npc_id>", methods=["DELETE"])
def delete_npc(npc_id):
    # Remove NPC base
    db.reference(f"/npcs/{npc_id}").delete()

    # Optional: remove from rumor system
    db.reference(f"/npc_rumors/{npc_id}").delete()

    # Remove memory
    db.reference(f"/npc_memory/{npc_id}").delete()

    # Remove knowledge
    db.reference(f"/npc_knowledge/{npc_id}").delete()

    # Remove from any opinion matrices
    db.reference(f"/npc_opinion_matrix/{npc_id}").delete()

    # Remove from region/POI if tracked
    region_ref = db.reference("/poi_state")
    regions = region_ref.get() or {}
    for region_name, pois in regions.items():
        for poi_id, poi_data in pois.items():
            if "npcs_present" in poi_data and npc_id in poi_data["npcs_present"]:
                poi_data["npcs_present"].remove(npc_id)
                db.reference(f"/poi_state/{region_name}/{poi_id}").update(poi_data)

    return jsonify({"message": f"NPC {npc_id} fully removed from game state."})

@npc_bp.route("/npc/<npc_id>", methods=["GET"])
def get_npc_info(npc_id):
    try:
        npc = db.reference(f"/npcs/{npc_id}").get()
        if not npc:
            return jsonify({"error": f"NPC '{npc_id}' not found."}), 404
        # Hide loyalty, show goodwill
        display_npc = {
            "name": npc.get("name", "Unknown"),
            "goodwill": npc.get("goodwill", 0),
            "faction": npc.get("faction", "None"),
            "motifs": npc.get("narrative_motif_pool", {})
        }
        return jsonify(display_npc)
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    
@npc_bp.route('/npc/<npc_id>/refresh_goals', methods=['POST'])
def refresh_npc_goals(npc_id):
    """
    Refresh an NPC's personal goals via GPT-4.1-nano.
    """
    try:
        npc_ref = db.reference(f"/npcs/{npc_id}")
        npc = npc_ref.get()

        if not npc:
            return jsonify({"error": f"NPC {npc_id} not found."}), 404

        name = npc.get("character_name", "Unnamed")
        race = npc.get("race", "Human")
        char_class = npc.get("class", "Commoner")
        background = npc.get("background", "A simple wanderer.")

        goals_response = openai.ChatCompletion.create(
            model="gpt-4.1-nano",
            messages=[
                {"role": "system", "content": "Generate 3 short personal goals for a fantasy RPG NPC."},
                {"role": "user", "content": f"Name: {name}, Race: {race}, Class: {char_class}, Background: {background}."}
            ],
            temperature=0.7,
            max_tokens=150
        )

        goals = [g.strip("-• ") for g in goals_response.choices[0].message.content.strip().split("\n") if g.strip()]
        goals = goals[:3]

        npc["personal_goals"] = goals
        npc_ref.set(npc)

        return jsonify({"message": f"NPC {npc_id} goals refreshed.", "new_goals": goals})

    except Exception as e:
        return jsonify({"error": str(e)}), 500