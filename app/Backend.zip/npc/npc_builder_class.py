
#This class handles procedural creation of NPCs, including race assignment, skill/tag additions, hidden trait generation, and motif initialization. It produces a JSON-serializable character dictionary suitable for Firebase insertion.
#It supports the npc, motif, region, faction, and memory systems.

import random
from datetime import datetime
from app.rules.rules_utils import calculate_dr
from uuid import uuid4
import uuid

class NPCBuilder:
    def __init__(self, base_data=None):
        self.data = base_data or {}
        self.data.setdefault("id", f"npc_{random.randint(100000, 999999)}")
        self.data.setdefault("name", "Unnamed")
        self.data.setdefault("location", "unknown")
        self.data.setdefault("motif_entropy", {})
        self.data.setdefault("alignment", "Neutral")
        self.data.setdefault("emotional_flags", [])
        self.data.setdefault("relationships", {})
        self.data.setdefault("inventory", [])
        self.data.setdefault("features", [])
        self.data.setdefault("core_motifs", [])
        self.data.setdefault("party_affiliation", None)
        self.data.setdefault("faction_affiliations", [])
        self.data.setdefault("reputation", 0)
        self.data.setdefault("hidden_traits", [])
        self.data.setdefault("loyalty_matrix", {})
        self.data.setdefault("opinion_of_party", {})
        self.data.setdefault("backstory", None)

        # If no backstory, generate one using GPT
        if not self.data["backstory"]:
            prompt = f"Create a short backstory for a fantasy NPC named {self.data['name']} who has the alignment {self.data['alignment']}."
            self.data["backstory"] = call(prompt, system_prompt="You are generating a background for a fantasy role-playing game character.")

        self.data["created_at"] = datetime.utcnow().isoformat()
        
    def generate_hidden_traits(self):
        return {
            "hidden_ambition": random.randint(0, 6),
            "hidden_integrity": random.randint(0, 6),
            "hidden_discipline": random.randint(0, 6),
            "hidden_impulsivity": random.randint(0, 6),
            "hidden_pragmatism": random.randint(0, 6),
            "hidden_resilience": random.randint(0, 6)
        }


    def init_loyalty_from_pc(npc_id, pc_id):
        npc_ref = db.reference(f"/npcs/{npc_id}")
        pc_ref = db.reference(f"/pcs/{pc_id}")
        npc = npc_ref.get()
        pc = pc_ref.get()

        if not npc or not pc:
            return {"error": "Missing NPC or PC"}

        loyalty_score = 0
        faction_bonus = {}

        npc_traits = npc.get("features", []) + npc.get("hidden_traits", [])
        pc_traits = pc.get("features", [])

        # Goodwill boost for shared traits
        for trait in pc_traits:
            if trait in npc_traits:
                loyalty_score += 5

        # Bias by alignment match
        if npc.get("alignment") == pc.get("alignment"):
            loyalty_score += 10

        # Extend: bias based on shared factions
        npc_factions = npc.get("faction_affiliations", [])
        pc_factions = pc.get("faction_affiliations", [])
        for faction in pc_factions:
            if faction in npc_factions:
                faction_bonus[faction] = faction_bonus.get(faction, 0) + 10

        # Store result
        db.reference(f"/npcs/{npc_id}/relationships/{pc_id}").set({
            "goodwill": loyalty_score,
            "faction_bias": faction_bonus
        })

        return {"npc": npc_id, "pc": pc_id, "goodwill": loyalty_score, "faction_bias": faction_bonus}
    def set_id(self, npc_id=None):
        if npc_id:
            self.npc_id = npc_id
        else:
            self.npc_id = f"npc_{uuid.uuid4().hex[:8]}"
            
    def set_name(self, name): self.name = name

    def set_race(self, race_name):
        if race_name not in self.race_data:
            raise ValueError(f"Unknown race: {race_name}")
        self.race = race_name
        self.apply_racial_modifiers()

    def apply_racial_modifiers(self):
        mods = self.race_data[self.race].get("ability_modifiers", {})
        for stat, bonus in mods.items():
            self.attributes[stat] += bonus

    def assign_stat(self, stat, value):
        if stat not in self.attributes:
            raise ValueError(f"Unknown stat: {stat}")
        self.attributes[stat] = value

    def add_skill(self, skill_name):
        print("🧪 skill_name received:", skill_name)
        print("📜 skill_list available:", self.skill_list)

        if skill_name not in self.skill_list:
            raise ValueError(f"Unknown skill: {skill_name}")

        self.skills.append(skill_name)

    def add_tag(self, tag): self.tags.append(tag)

    def set_location(self, region_id, loc_str):
        self.region = region_id
        self.location = loc_str

    def generate_motifs(self, count=3):
        self.motifs = [{
            "theme": random.randint(1, 50),
            "lifespan": (life := random.randint(2, 4)),
            "entropy_tick": 0,
            "weight": 6 - life
        } for _ in range(count)]

    def finalize(self):
        return {
            "npc_id": self.npc_id,
            "name": self.name,
            "race": self.race,
            "attributes": self.attributes,
            "skills": self.skills,
            "tags": self.tags,
            "region_id": self.region,
            "location": self.location,
            "XP": 0,
            "level": 1,
            "inventory": [],
            "equipment": [],
            "gold": 0,
            "dr": 0,
            "loyalty": self.loyalty,
            "faction_affiliations": [],
            "reputation": 0,
            "cooldowns": {},
            "status_effects": [],
            "motif_history": [],
            "narrative_motif_pool": {
                "active_motifs": self.motifs,
                "motif_history": [],
                "last_rotated": datetime.utcnow().isoformat()
            },
            "rumor_index": [],
            "memory_summary": "",
            "known_languages": ["Common"],
            "created_at": datetime.utcnow().isoformat(),
            **self.hidden_personality
        }
