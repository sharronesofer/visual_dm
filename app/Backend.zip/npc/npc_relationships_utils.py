
#This file integrates daily NPC relationship drift, loyalty simulation, mobility, betrayal mechanics, emotional flags, and motif entropy. It functions as a high-level world simulation tick layer.
#It integrates directly with npc, relationship, motif, party, memory, region, and firebase systems.

import random
import math
from datetime import datetime, timedelta
from flask import Blueprint, jsonify, request  # Only needed if this is a Flask route file
from firebase_admin import db
from app.memory.memory_utils import store_interaction
from app.motifs.chaos_utils import trigger_chaos_if_needed

REQUIRED_FIELDS = [
    "character_name", "characterType", "level", "class", "race", "gender", "alignment",
    "region_of_origin", "background", "HP", "AC", "STR", "DEX", "CON", "INT", "WIS", "CHA", 
    "XP", "feats", "skills", "proficiencies", "features", "spells", "equipment", "inventory", 
    "notable_possessions", "known_languages", "faction_affiliations", "reputation", 
    "personality_traits", "notable_relationships", "hidden_ambition", "hidden_compassion",
    "hidden_discipline", "hidden_impulsivity", "hidden_integrity", "hidden_pragmatism",
    "hidden_resilience", "private_goal_short_term", "private_goal_mid_term",
    "private_goal_long_term", "opinion_of_pc", "opinion_of_party", "narrative_motif_pool",
    "status_effects", "cooldowns", "gold"
]

EMOTION_POOL = [
    "rage", "melancholy", "anxiety", "hope", "grief", "love",
    "jealousy", "serenity", "defiance", "regret", "ambition",
    "happiness", "pride", "shame", "guilt", "fear", "envy",
    "sorrow", "frustration", "despair", "elation", "embarrassment",
    "contentment", "insecurity", "compassion", "resentment", "boredom",
    "nervousness", "gratitude", "excitement", "disgust", "loneliness",
    "affection", "sympathy", "passion", "righteousness", "hopelessness",
    "curiosity", "surprise", "anticipation", "exhaustion", "wonder",
    "doubt", "confusion", "relief", "inspiration", "pragmatism",
    "melancholy", "nostalgia", "rage", "compromise", "clarity",
    "rebellion", "stubbornness", "defeat", "bitterness", "fearlessness",
    "submission", "optimism", "pessimism", "indifference", "disappointment",
    "tenderness", "vulnerability", "understanding", "admiration",
    "revulsion", "alienation", "humility", "acquiescence", "peace"
]

def run_daily_relationship_tick():
    matrix_root = db.reference("/npc_opinion_matrix")
    all_matrices = matrix_root.get() or {}

    for npc_id, partners in all_matrices.items():
        for target_id, data in partners.items():
            old_tier = get_relationship_tier(npc_id, target_id)
            updated = data.copy()

            # Drift trust toward 0
            if updated.get("trust_score", 0) > 0:
                updated["trust_score"] -= 1
            elif updated.get("trust_score", 0) < 0:
                updated["trust_score"] += 1

            # Random modifier
            updated["trust_score"] += random.choice([-1, 0, 1])
            updated["trust_score"] = max(-10, min(10, updated["trust_score"]))

            db.reference(f"/npc_opinion_matrix/{npc_id}/{target_id}").set(updated)

            new_tier = get_relationship_tier(npc_id, target_id)
            if new_tier != old_tier:
                db.reference(f"/npc_memory/{npc_id}/rag_log").push({
                    "interaction": f"Relationship with {target_id} shifted from {old_tier} to {new_tier}",
                    "timestamp": datetime.utcnow().isoformat()
                })

def validate_npc(npc):
    """
    Ensures the NPC dictionary has all REQUIRED_FIELDS.
    Any missing field is set to None to maintain consistency.
    """
    for field in REQUIRED_FIELDS:
        npc.setdefault(field, None)
    return npc




def update_npc_location(npc_id):
    """
    Updates an NPC's location based on 'mobility' dict and logs motive-based quest hook triggers.
    """
    npc_ref = db.reference(f"/npcs/{npc_id}")
    npc = npc_ref.get()
    if not npc:
        return {"error": f"NPC {npc_id} not found."}

    mobility = npc.get("mobility", {})
    home = mobility.get("home_poi")
    current = mobility.get("current_poi", home)
    radius = mobility.get("radius", 1)
    travel_chance = mobility.get("travel_chance", 0.15)

    if not current or "_" not in current:
        return {"error": f"Invalid POI format for NPC {npc_id}: {current}"}

    if random.random() > travel_chance:
        return {"npc_id": npc_id, "stayed": True}

    all_pois = db.reference("/locations").get() or {}
    valid_pois = []

    try:
        cx, cy = map(int, current.split("_"))
    except:
        return {"error": f"Could not parse coordinates from current_poi: {current}"}

    for key, poi_data in all_pois.items():
        if not poi_data.get("POI"):
            continue
        try:
            x, y = map(int, key.split("_"))
            dist = math.sqrt((x - cx)**2 + (y - cy)**2)
            if 0 < dist <= radius:
                valid_pois.append(key)
        except:
            continue

    if not valid_pois:
        return {"npc_id": npc_id, "stayed": True, "reason": "No POIs in radius"}

    new_location = random.choice(valid_pois)
    npc["mobility"]["current_poi"] = new_location
    npc["mobility"]["last_moved"] = datetime.utcnow().isoformat()
    npc_ref.set(npc)

    motive = npc.get("travel_motive", "wander")
    memory_ref = db.reference(f"/npc_memory/{npc_id}/rag_log")
    memory_ref.push({
        "interaction": f"Moved to {new_location} due to motive: {motive}",
        "timestamp": datetime.utcnow().isoformat()
    })

    # Trigger quest hook for special motives
    if motive in ["seek_revenge", "hunt_monster", "find_relic"]:
        db.reference("/potential_quest_hooks").push({
            "npc": npc_id,
            "motive": motive,
            "poi": new_location,
            "timestamp": datetime.utcnow().isoformat()
        })

    return {"npc_id": npc_id, "moved_to": new_location, "motive": motive}

def loyalty_tick(npc_id, character_id, context_tags=None, cha_score=10):
    ref = db.reference(f"/npcs/{npc_id}/relationships/{character_id}")
    rel = ref.get() or {}

    loyalty = rel.get("loyalty", 0)
    goodwill = rel.get("goodwill", 18)
    tags = rel.get("tags", [])
    auto_abandon = rel.get("auto_abandon", False)

    # Regenerate goodwill if loyal
    regen = 3 if loyalty >= 10 else 1 if loyalty > 0 else 0
    goodwill = min(36, goodwill + regen)

    # Loyalty adjusts based on goodwill
    if loyalty < 10 and goodwill >= 30:
        loyalty += 1
    elif loyalty > -10 and goodwill <= 6:
        loyalty -= 1

    # Auto-abandonment logic
    if goodwill <= 0 and loyalty <= -5:
        auto_abandon = True
    elif loyalty >= 10:
        auto_abandon = False

    rel.update({
        "loyalty": max(-10, min(10, loyalty)),
        "goodwill": max(0, min(36, goodwill)),
        "tags": tags,
        "auto_abandon": auto_abandon,
        "last_tick": datetime.utcnow().isoformat()
    })

    ref.set(rel)
    return {
        "npc_id": npc_id,
        "character_id": character_id,
        "loyalty": rel["loyalty"],
        "goodwill": rel["goodwill"],
        "tags": tags,
        "regen_applied": regen,
        "auto_abandon": auto_abandon
    }


def betrayal_check(npc_id, character_id, cha_score):
    """
    If loyalty <= 0 and goodwill == 0, chance of betrayal.
    Rolls 1d20 + CHA mod vs DC = 10 + abs(loyalty).
    """
    rel_ref = db.reference(f"/npcs/{npc_id}/relationships/{character_id}")
    rel_data = rel_ref.get() or {}

    loyalty = rel_data.get("loyalty", 0)
    goodwill = rel_data.get("goodwill", 0)

    if goodwill > 0 or loyalty > 0:
        return {"status": "stable", "message": "No betrayal risk."}

    dc = 10 + abs(loyalty)
    roll = random.randint(1, 20) + ((cha_score - 10) // 2)

    if roll < dc:
        # Betrayal occurs
        rel_data["betrayed"] = True
        rel_data["trust_score"] = -10
        rel_ref.set(rel_data)

        # Memory log
        store_interaction(npc_id, character_id, "Betrayed the party.", tags={"betrayal": True})

        # Chaos injection
        trigger_chaos_if_needed({"id": npc_id})

        return {
            "npc_id": npc_id,
            "character_id": character_id,
            "dc": dc,
            "roll": roll,
            "cha_score": cha_score,
            "outcome": "betrays"
        }

    else:
        return {
            "npc_id": npc_id,
            "character_id": character_id,
            "dc": dc,
            "roll": roll,
            "cha_score": cha_score,
            "outcome": "stays"
        }

################################################################################
# World Updating Functions
################################################################################

def update_world_state():
    """
    Called periodically to update NPCs' movement or behaviors.
    """
    all_npcs = db.reference("/npcs").get() or {}
    for npc_id in all_npcs.keys():
        update_npc_location(npc_id)
    # Add more global updates if desired

from app.memory.memory_utils import summarize_and_clean_memory

def daily_world_():
    update_world_state()
    
    all_npcs = db.reference("/npcs").get() or {}
    for npc_id in all_npcs:
        summarize_and_clean_memory(npc_id)


################################################################################
# NPC Emotional State & Motifs
################################################################################

def tick_npc_motifs(npc_id):
    """
    Ticks an NPC's emotional flags and motif entropy.
    Possibly adds new emotions at random.
    """
    npc_ref = db.reference(f"/npcs/{npc_id}")
    npc_data = npc_ref.get()
    if not npc_data:
        return {"error": f"NPC {npc_id} not found"}

    updated = False

    # Motif entropy
    entropy = npc_data.get("motif_entropy", {})
    for motif in npc_data.get("core_motifs", []):
        entropy[motif] = min(entropy.get(motif, 0) + 1, 5)
    npc_data["motif_entropy"] = entropy
    updated = True

    # Emotional flags countdown
    emotional_flags = npc_data.get("emotional_flags", [])
    new_flags = []
    for flag in emotional_flags:
        flag["duration"] -= 1
        if flag["duration"] > 0:
            new_flags.append(flag)
    npc_data["emotional_flags"] = new_flags

    # Chance to add a new emotion if under 3 flags
    if len(new_flags) < 3 and random.random() < 0.2:
        emotion = random.choice(EMOTION_POOL)
        intensity = random.randint(1, 5)
        duration = max(1, 6 - intensity)
        new_flags.append({
            "emotion": emotion,
            "intensity": intensity,
            "duration": duration
        })
        npc_data["emotional_flags"] = new_flags

    updated = True
    if updated:
        npc_data["last_motif_tick"] = datetime.utcnow().isoformat()
        npc_ref.set(npc_data)

    return {
        "npc_id": npc_id,
        "motif_entropy": npc_data["motif_entropy"],
        "emotional_flags": npc_data["emotional_flags"]
    }

def get_relationship_tier(npc_id, target_id):
    ref = db.reference(f"/npc_opinion_matrix/{npc_id}/{target_id}")
    rel = ref.get() or {}
    trust = rel.get("trust_score", 0)

    if trust >= 9:
        return "ally"
    elif trust >= 5:
        return "friend"
    elif trust >= 0:
        return "neutral"
    elif trust >= -5:
        return "rival"
    else:
        return "enemy"
