
#This module defines routes for managing NPC relationships, recruitment, loyalty shifts, and motif pressure ticks. It integrates party logic, emotional simulation, and motif evolution into daily world progression.
#It connects tightly with npc, party, motif, relationship, and firebase systems.



from flask import Blueprint, request, jsonify
import random
from app.utils.firebase_utils import db
from firebase_admin import db

# External functions - ensure these are defined and imported properly
from app.npc.npc_relationships_utils import loyalty_tick, run_daily_relationship_tick
from app.motifs.motif_engine_class import MotifEngine
from app.characters.party_utils import add_to_party, create_party
from app.utils.gpt_utils import get_goodwill_label
from app.npc.npc_loyalty_utils import drift_npc_faction_biases
from app.utils.gpt_class import call

npc_relationship_bp = Blueprint('npc_relationship', __name__)

@npc_relationship_bp.route('/relationships/update', methods=['POST'])
def update_relationships():
    data = request.get_json(force=True)
    npc_id = data["npc_id"]
    target_id = data["target_id"]

    relationship_ref = db.reference(f'/npc_opinion_matrix/{npc_id}/{target_id}')
    current_score = relationship_ref.get() or 0
    delta = random.choice([-2, -1, 0, 1, 2])
    new_score = current_score + delta
    relationship_ref.set(new_score)

    return jsonify({"message": "Relationship updated", "new_score": new_score}), 200


@npc_relationship_bp.route("/npc/<npc_id>/recruit", methods=["POST"])
def recruit_npc(npc_id):
    data = request.json
    pc_id = data.get("pc_id")
    if not pc_id:
        return jsonify({"error": "pc_id required"}), 400

    npc_ref = db.reference(f"/npcs/{npc_id}")
    npc = npc_ref.get()
    if not npc:
        return jsonify({"error": "NPC not found"}), 404

    # Assign to party
    party_ref = db.reference(f"/pcs/{pc_id}/party_id")
    party_id = party_ref.get()
    if not party_id:
        party_id = f"party_{random.randint(100000, 999999)}"
        db.reference(f"/parties/{party_id}/members").set([pc_id])

    db.reference(f"/parties/{party_id}/members").push(npc_id)
    npc["party_affiliation"] = party_id
    npc_ref.set(npc)

    # Permanent memory log
    db.reference(f"/npc_memory/{npc_id}/rag_log").push({
        "interaction": f"Joined party {party_id} led by PC {pc_id}",
        "timestamp": datetime.utcnow().isoformat()
    })

    return jsonify({"npc_id": npc_id, "party_id": party_id})



@npc_relationship_bp.route('/npc_loyalty_tick', methods=['POST'])
def npc_loyalty_tick():
    data = request.get_json(force=True)
    npc_id = data.get("npc_id")
    character_id = data.get("character_id")
    cha_score = data.get("cha", 10)

    if not npc_id or not character_id:
        return jsonify({"error": "Missing npc_id or character_id"}), 400

    result = loyalty_tick(npc_id, character_id, cha_score=cha_score)
    return jsonify(result), 200


@npc_relationship_bp.route('/npc_relationship_tick', methods=['POST'])
def npc_relationship_tick_route():
    run_daily_relationship_tick()
    return jsonify({"status": "NPC relationships updated"}), 200


@npc_relationship_bp.route('/npc_motif_tick', methods=['POST'])
def npc_motif_tick():
    all_npcs = db.reference('/npcs').get() or {}
    updated = {}
    for npc_id, npc in all_npcs.items():
        pool = npc.get("narrative_motif_pool", {})
        engine = MotifEngine(npc_id)
        engine.tick_all().rotate().save()
        updated_pool = engine.get_pool()        
        db.reference(f'/npcs/{npc_id}/narrative_motif_pool').set(updated_pool)
        updated[npc_id] = updated_pool.get("active_motifs", [])

    return jsonify({"message": "NPC motifs rotated", "updated": updated}), 200


@npc_relationship_bp.route("/npc_interact", methods=["POST"])
def npc_interact():
    data = request.get_json()
    character_id = data.get("character_id")
    npc_id = data.get("npc_id")
    prompt = data.get("prompt")

    if not all([character_id, npc_id, prompt]):
        return {"error": "Missing character_id, npc_id, or prompt"}, 400

    # Charisma
    attributes = db.reference(f"/players/{character_id}/attributes").get() or {}
    cha_mod = attributes.get("CHA", 0)

    # Goodwill
    opinion = db.reference(f"/npc_opinion_matrix/{npc_id}/{character_id}").get() or 0
    relationship = get_goodwill_label(opinion)

    # NPC context
    npc_data = db.reference(f"/npcs/{npc_id}").get() or {}
    npc_name = npc_data.get("character_name", "Unknown NPC")
    role = npc_data.get("role", "neutral party")

    # Prompt Construction
    system = f"You are {npc_name}, a {role}. Respond based on your current opinion of the player: {relationship} ({opinion})."
    full_prompt = f"Player's Charisma modifier is {cha_mod}. They say: {prompt}"

    # GPT Response
    reply = call(system_prompt=system, user_prompt=full_prompt)

    return jsonify({
        "npc_id": npc_id,
        "reply": reply,
        "relationship": relationship,
        "charisma": cha_mod
    })


@npc_relationship_bp.route('/admin/drift_npc_faction_biases', methods=['POST'])
def trigger_npc_faction_drift():
    """
    Manually trigger NPC belief updates from local faction presence.
    """
    try:
        drift_npc_faction_biases()
        return jsonify({"message": "NPC faction bias drift completed."}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500