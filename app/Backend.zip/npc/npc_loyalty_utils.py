
#This module manages NPC construction, party abandonment, loyalty dynamics, faction opinion drift, and relational responses. It’s a core layer for emotional simulation and NPC reactivity across the world.
#It connects with npc, faction, party, relationship, motif, and memory systems.

from datetime import datetime
import os
import json
import math
from firebase_admin import db
from app.npc.npc_builder_class import NPCBuilder
from app.rules.character_gen_rules_utils import (
    load_feat_data, load_starter_kits, load_race_data, load_skill_list
)

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
RULES_PATH = os.path.join(PROJECT_ROOT, "rules_json")

def build_npc_from_input(data):
    race_data = load_race_data()
    skills = load_skill_list()

    builder = NPCBuilder(race_data, skills)

    builder.set_id(data.get("npc_id"))
    builder.set_name(data.get("name", "Unnamed NPC"))
    builder.set_race(data.get("race", "Human"))

    for stat, value in data.get("attributes", {}).items():
        builder.assign_stat(stat, value)

    for skill in data.get("skills", []):
        builder.add_skill(skill)

    for tag in data.get("tags", []):
        builder.add_tag(tag)

    loc = data.get("location", "0_0")
    region = data.get("region_id", "unknown_region")
    builder.set_location(region, loc)

    builder.generate_motifs()

    # NEW: Set loyalty based on player character personality vector (optional)
    pc_personality = data.get("pc_personality")  # Expecting [int, int, ..., int] of length 6
    if pc_personality:
        builder.init_loyalty_from_pc(pc_personality)

    return builder.finalize()

def save_npc_to_firebase(npc_id: str, npc_data: dict):
    db.reference(f"/npcs/{npc_id}").set(npc_data)

def load_npc_from_firebase(npc_id: str):
    return db.reference(f"/npcs/{npc_id}").get()

def should_abandon(npc_id: str, character_id: str) -> bool:
    ref = db.reference(f"/npcs/{npc_id}/relationships/{character_id}")
    data = ref.get() or {}

    loyalty = data.get("loyalty", 0)
    goodwill = data.get("goodwill", 0)
    return goodwill <= 0 and loyalty <= -5

def abandon_party(npc_id: str) -> dict:
    npc_ref = db.reference(f"/npcs/{npc_id}")
    npc = npc_ref.get()

    if not npc or "party_id" not in npc:
        return {"error": "NPC not in a party."}

    party_id = npc["party_id"]
    party_ref = db.reference(f"/parties/{party_id}/members")
    members = party_ref.get() or []

    updated_members = [m for m in members if m != npc_id]
    party_ref.set(updated_members)

    # Clear NPC's party association
    npc_ref.update({"party_id": None})

    return {"message": f"{npc_id} has left party {party_id}.", "remaining_members": updated_members}

def drift_npc_faction_opinions():
    """
    Updates all NPCs' opinions of nearby factions based on POI influence,
    relationship context, and a controlled random mutation factor.
    """
    all_npcs = db.reference("/npcs").get() or {}
    all_factions = db.reference("/factions").get() or {}
    poi_map = db.reference("/poi_state").get() or {}

    for npc_id, npc in all_npcs.items():
        npc_location = npc.get("location", "0_0")
        region = npc.get("region_id")
        npc_traits = {
            k: npc.get(k, 3) for k in [
                "hidden_ambition", "hidden_integrity", "hidden_discipline",
                "hidden_impulsivity", "hidden_pragmatism", "hidden_resilience"
            ]
        }

        opinions_ref = db.reference(f"/npcs/{npc_id}/faction_opinions")

        for fid, faction in all_factions.items():
            influence = poi_map.get(region, {}).get(npc_location, {}).get("faction_influence", {}).get(fid, 0)

            if influence == 0:
                continue  # No presence, skip

            # Base affinity drift
            faction_traits = faction.get("hidden_attributes", {})
            affinity = 36 - sum(abs(npc_traits.get(k, 3) - faction_traits.get(k, 3)) for k in npc_traits)

            current_opinion = opinions_ref.child(fid).get() or 0
            drift = 0

            if affinity >= 30 and influence >= 8:
                drift = 1
            elif affinity <= 20 and influence >= 8:
                drift = -1
            elif influence >= 5:
                drift = random.choice([-1, 0, 1])
            elif influence >= 2:
                drift = random.choice([-1, 0])
            else:
                drift = 0

            # Mutation (low chance of unexpected opinion flip)
            if random.random() < 0.01:
                drift += random.choice([-2, 2])

            new_opinion = max(-4, min(4, current_opinion + drift))
            opinions_ref.child(fid).set(new_opinion)



def apply_loyalty_event(npc_id, character_id, alignment_score):
    ref = db.reference(f"/npcs/{npc_id}/relationships/{character_id}")
    rel = ref.get() or {}

    loyalty = rel.get("loyalty", 0)
    goodwill = rel.get("goodwill", 18)
    tags = rel.get("tags", [])

    gain_mod = 1.0
    loss_mod = 1.0

    if "loyalist" in tags:
        gain_mod, loss_mod = 1.5, 0.5
    elif "coward" in tags:
        gain_mod, loss_mod = 0.5, 1.5
    elif "bestie" in tags:
        loyalty = 10
    elif "nemesis" in tags:
        loyalty = -10

    if alignment_score > 0:
        loyalty += int(alignment_score * gain_mod)
        goodwill += 1
    elif alignment_score < 0:
        loyalty += int(alignment_score * loss_mod)
        goodwill -= abs(alignment_score)

    rel.update({
        "loyalty": max(-10, min(10, loyalty)),
        "goodwill": max(0, min(36, goodwill)),
        "tags": tags,
        "last_tick": datetime.utcnow().isoformat()
    })

    ref.set(rel)

    # Ripple faction opinion from PC to NPC
    pc_factions = db.reference(f"/pcs/{character_id}/faction_affiliations").get() or []
    for faction in pc_factions:
        ripple_ref = db.reference(f"/npcs/{npc_id}/faction_opinions/{faction}")
        prev = ripple_ref.get() or 0
        ripple_ref.set(prev + alignment_score)

    return rel

def drift_npc_faction_biases():
    """
    Adjust NPC faction biases based on current faction presence in their POI.
    """
    all_npcs = db.reference("/npc_core").get() or {}
    for npc_id, npc_data in all_npcs.items():
        poi = npc_data.get("current_location", "")
        if not poi:
            continue

        # Assume this is the short format: "region.poi_id"
        if "." not in poi:
            continue
        region, poi_id = poi.split(".")
        influence_path = f"/poi_state/{region}/{poi_id}/faction_influence"
        faction_influence = db.reference(influence_path).get() or {}

        if not faction_influence:
            continue

        matrix_ref = db.reference(f"/npc_opinion_matrix/{npc_id}/{npc_id}")
        current_bias = matrix_ref.get() or {"faction_bias": {}}
        current_bias["faction_bias"] = current_bias.get("faction_bias", {})

        for faction_id, score in faction_influence.items():
            # Bias adjusts proportionally to local influence
            adjustment = int(score / 4)  # Tweak formula as needed
            current_bias["faction_bias"][faction_id] = current_bias["faction_bias"].get(faction_id, 0) + adjustment

        matrix_ref.set(current_bias)

def initialize_faction_opinions(npc_id, npc_data=None):
    """
    Initializes or refreshes an NPC's opinions about each faction.
    These values will evolve based on alignment and relationships.
    """
    if not npc_data:
        npc_data = db.reference(f"/npc_core/{npc_id}").get() or {}

    all_factions = db.reference("/factions").get() or {}
    relationships = db.reference(f"/npc_opinion_matrix/{npc_id}").get() or {}

    faction_opinions = {}

    for faction_id, faction_data in all_factions.items():
        # Step 1: Base affinity
        base_score = calculate_affinity(npc_data, faction_data)

        # Step 2: Modify based on opinions of faction members
        related_npcs = []
        for other_npc, data in relationships.items():
            if not isinstance(data, dict):
                continue
            trust = data.get("trust_score", 0)
            other_core = db.reference(f"/npc_core/{other_npc}").get() or {}
            affiliations = other_core.get("faction_affiliations", [])

            if faction_id in affiliations:
                related_npcs.append((other_npc, trust))

        trust_modifier = sum(t for _, t in related_npcs)
        final_score = min(100, base_score + trust_modifier)

        faction_opinions[faction_id] = {
            "base_affinity": base_score,
            "trust_modifier": trust_modifier,
            "opinion_score": final_score
        }

    db.reference(f"/npcs/{npc_id}/faction_opinions").set(faction_opinions)

def assign_faction_affiliations_to_npc(npc_id):
    """
    Checks faction opinions and recruits NPC if criteria met:
    - Opinion of one faction ≥ 3
    - No other faction has opinion ≥ 2
    """
    opinion_data = db.reference(f"/npcs/{npc_id}/faction_opinions").get() or {}
    existing = db.reference(f"/npc_core/{npc_id}/faction_affiliations").get() or []

    # Skip if already recruited
    if existing:
        return

    top_faction = None
    top_score = 0
    conflict = False

    for fid, details in opinion_data.items():
        score = details.get("opinion_score", 0)
        if score >= 3 and score > top_score:
            top_faction = fid
            top_score = score
        if score >= 2 and fid != top_faction:
            conflict = True

    if top_faction and not conflict:
        recruit_npc_to_faction(npc_id, top_faction)

def recruit_npc_to_faction(npc_id, faction_id):
    """
    Adds faction affiliation to NPC and updates regional/POI power scores.
    Logs memory and possibly updates conflict pressure.
    """
    npc_ref = db.reference(f"/npc_core/{npc_id}")
    npc_data = npc_ref.get() or {}

    affiliations = npc_data.get("faction_affiliations", [])
    if faction_id in affiliations:
        return

    affiliations.append(faction_id)
    npc_ref.child("faction_affiliations").set(affiliations)

    # Boost power score (simplified: +1 to faction_influence at current POI)
    poi_path = npc_data.get("current_location")
    if poi_path and "." in poi_path:
        region, poi_id = poi_path.split(".")
        influence_ref = db.reference(f"/poi_state/{region}/{poi_id}/faction_influence/{faction_id}")
        current_power = influence_ref.get() or 0
        influence_ref.set(current_power + 1)

    # Optional: log to NPC memory
    memory_entry = {
        "interaction": f"Joined faction '{faction_id}'",
        "timestamp": get_current_game_day()
    }
    db.reference(f"/npc_memory/{npc_id}/rag_log").push(memory_entry)
