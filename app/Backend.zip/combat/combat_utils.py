"""
This module orchestrates AI combat behavior, initiative mechanics, and combat narration.
It integrates GPT for action decisions and prose, handles loyalty-driven abandonment, and
bridges live tactical logic with persistent game state (Firebase or RAM).
"""

import random
import json
from datetime import datetime
from firebase_admin import db

from app.combat.combat_handler_class import CombatAction
from app.combat.combat_class import Combatant
from app.combat.status_effects_utils import tick_status_effects
from app.characters.party_utils import abandon_party
from app.npc.npc_loyalty_utils import should_abandon
from app.utils.gpt_class import GPTClient
from app.combat.combat_state_class import CombatState
from app.combat.combat_ram import ACTIVE_BATTLES


class CombatEngine:
    def __init__(self, party, enemies, battlefield=None):
        self.party = party
        self.enemies = enemies
        self.battlefield = battlefield or {}

    def resolve_turn(self, combatant: Combatant, action_data=None):
        if should_abandon(combatant.npc_id, combatant.character_id):
            abandon_party(combatant.npc_id)
            return {
                "character_id": combatant.character_id,
                "action": "abandon_party",
                "result": f"{combatant.npc_id} fled due to loyalty loss."
            }

        tick_status_effects(combatant)

        targets = self.enemies if combatant in self.party else self.party
        if not targets:
            return {
                "character_id": combatant.character_id,
                "action": "idle",
                "result": "No valid targets"
            }

        action = action_data or {"name": "basic_attack", "base_damage": 10, "mp_cost": 0}
        combat_action = CombatAction(combatant, targets[0], action, self.battlefield)
        return combat_action.resolve()

    def run_combat_loop(self, rounds=5):
        log = []
        all_units = self.party + self.enemies

        for _ in range(rounds):
            for unit in all_units:
                result = self.resolve_turn(unit)
                log.append(result)

        return log

    def narrate_action(self, actor_name, action_details, outcome):
        prompt = (
            f"{actor_name} used {action_details.get('ability', 'an action')} on {action_details.get('target')}.\n"
            f"The attack {'hit' if outcome.get('hit') else 'missed'} and dealt {outcome.get('damage', 0)} "
            f"{outcome.get('damage_type', 'damage')}.\n"
            f"Target HP after the attack: {outcome.get('target_hp', '?')}.\n\n"
            "Write a vivid, 2–4 sentence description of this combat moment."
        )

        return call(
            system_prompt="You are a fantasy combat narrator. Describe actions vividly with immersive prose.",
            user_prompt=prompt,
            temperature=0.9,
            max_tokens=150
        )


# === AI & Tactical Utilities ===

def choose_action_gpt(npc, battlefield_context):
    prompt = (
        f"Choose from the following actions for NPC {npc['name']} (STR {npc['attributes']['STR']}, "
        f"HP {npc['HP']}/{npc['max_HP']}, MP {npc['MP']}):\n"
        "- Attack\n- Cast Spell\n- Use Ability\n- Run Away\n- Defend\n- Say Something\n\n"
        f"Current Battlefield:\n{json.dumps(battlefield_context, indent=2)}\n\n"
        "Respond in JSON:\n"
        '{ "intent": "ATTACK", "target": "player_123", "ability": "cleave", "notes": "..." }'
    )

    raw_output = call(
        system_prompt="You are a tactical AI for a fantasy RPG. Respond with a single valid JSON action.",
        user_prompt=prompt,
        temperature=0.2,
        max_tokens=150
    )

    try:
        return json.loads(raw_output)
    except Exception:
        return {"intent": "WAIT", "notes": "Failed to parse GPT response"}


# === Combat Initializers & Utilities ===

def initiate_combat(player_party, enemy_party, battle_name="Combat", use_ram=True):
    combat_state = CombatState(player_party, enemy_party, name=battle_name)
    if use_ram:
        ACTIVE_BATTLES[combat_state.battle_id] = combat_state
    else:
        from app.combat.combat_state_firebase_utils import start_firebase_combat
        start_firebase_combat(battle_name, player_party, enemy_party)

    return {
        "battle_id": combat_state.battle_id,
        "combat_state": combat_state
    }


def log_combat_start(region_name, poi_id, participant_ids):
    timestamp = datetime.utcnow().isoformat()
    combat_event = {
        "type": "combat_started",
        "day": timestamp,
        "participants": participant_ids
    }

    poi_ref = db.reference(f"/poi_state/{region_name}/{poi_id}/event_log")
    poi_log = poi_ref.get() or []
    poi_log.append(combat_event)
    poi_ref.set(poi_log)

    for pid in participant_ids:
        if pid.startswith("npc_"):
            mem_ref = db.reference(f"/npc_memory/{pid}")
            memory = mem_ref.get() or {"rag_log": [], "summary": ""}
            memory["rag_log"].append({
                "interaction": f"Was present during combat at {poi_id} on {timestamp}",
                "timestamp": timestamp
            })
            mem_ref.set(memory)


# === Core Dice Mechanics ===

def roll_d20():
    return random.randint(1, 20)


def roll_initiative(dexterity):
    return random.randint(1, 20) + ((dexterity - 10) // 2)


def resolve_saving_throw(stat_mod, dc):
    roll = random.randint(1, 20) + stat_mod
    return {"roll": roll, "modifier": stat_mod, "dc": dc, "success": roll >= dc}


# === Special Effects & Status Utilities ===

def apply_combat_status_effects(target_id, status_dict, source=None):
    ref = db.reference("/combat_state")
    combat_states = ref.get()

    for battle_id, battle in (combat_states or {}).items():
        participants = battle.get("participants", {})
        if target_id in participants:
            target = participants[target_id]
            for name, value in status_dict.items():
                effect = {
                    "name": name,
                    "value": value,
                    "duration": 3,
                    "applied_by": source,
                    "timestamp": datetime.utcnow().isoformat()
                }
                target.setdefault("status_effects", []).append(effect)

            participants[target_id] = target
            db.reference(f"/combat_state/{battle_id}/participants").set(participants)
            return effect


def roll_fumble_effect():
    effects = {
        "disarm": {"status": {"disarmed": True}},
        "prone": {"status": {"prone": True}},
        "dazed": {"status": {"dazed_rounds": 1}},
        "exposed": {"status": {"exposed": True}}
    }
    label = random.choice(list(effects.keys()))
    return {"type": label, **effects[label]}


def resolve_combat_action(attacker, action_data, battlefield_context):
    target_id = action_data.get("target")
    ability = action_data.get("ability", "basic_attack")
    target = next((e for e in battlefield_context.get("enemies", []) if e["id"] == target_id), None)
    if not target:
        return {"hit": False, "error": f"Target {target_id} not found"}

    attributes = attacker.get("attributes", {})
    attributes_used = "STR" if attributes.get("STR", 10) >= attributes.get("DEX", 10) else "DEX"
    attributes_mod = (attributes.get(attributes_used, 10) - 10) // 2
    roll = random.randint(1, 20)
    attack_total = roll + attributes_mod
    ac = target.get("AC", 10)
    dr = target.get("DR", 0)

    result = {
        "attacker": attacker.get("name"),
        "target": target.get("name"),
        "attacker_id": attacker.get("id"),
        "target_id": target.get("id"),
        "ability": ability,
        "roll": roll,
        "attack_total": attack_total,
        "target_ac": ac,
        "hit": False,
        "crit": False,
        "fumble": False,
        "status_effects": {},
        "raw_damage": 0,
        "final_damage": 0,
        "damage_type": "slashing" if "cleave" in ability.lower() else "bludgeoning"
    }

    if roll == 1:
        fumble = roll_fumble_effect()
        result.update({
            "fumble": True,
            "fumble_effect": fumble["type"],
            "status_effects": fumble["status"],
            "outcome": f"{attacker['name']} fumbled and is now {fumble['type']}."
        })
        apply_combat_status_effects(attacker["id"], fumble["status"])
        return result

    if roll == 20 or attack_total >= ac:
        result.update({"hit": True})
        base_damage = random.randint(1, 8) * (2 if roll == 20 else 1)
    else:
        result["outcome"] = "Miss"
        return result

    final_damage = max(0, base_damage + attributes_mod - dr)
    result.update({
        "crit": roll == 20,
        "raw_damage": base_damage + attributes_mod,
        "final_damage": final_damage,
        "outcome": "Critical Hit!" if roll == 20 else "Hit",
        "target_hp": max(0, target.get("HP", 10) - final_damage)
    })

    db.reference(f"/combat_state/{target['id']}/HP").set(result["target_hp"])
    return result


def generate_scaled_encounter(character_id, location, danger_level):
    """
    Generates a combat encounter scaled by player level, location danger, and distance from (0,0).
    """
    try:
        # Pull player data
        char_ref = db.reference(f"/players/{character_id}")
        player = char_ref.get()
        if not player:
            return {"error": "Character not found."}

        # Distance from center
        x, y = map(int, location.split("_"))
        dist = math.sqrt(x**2 + y**2)
        distance_factor = max(1.0, min(dist / 20.0, 2.5))  # 1.0–2.5x scaling

        # Base CR from player level
        level = player.get("level", 1)
        base_cr = max(0.25, level * 0.25)

        # Danger adjustment
        cr_adjustment = (danger_level / 10.0) * 0.5  # adds up to +0.5 CR at danger 10
        effective_cr = base_cr + cr_adjustment

        # Distance adjustment
        effective_cr *= distance_factor

        # Load all monsters
        all_monsters = db.reference("/rules/monsters").get() or {}
        valid_monsters = [m for m in all_monsters.values()
                          if abs(m.get("challenge_rating", 0) - effective_cr) <= 1.0]

        if not valid_monsters:
            return {"error": "No suitable monsters found."}

        # Randomize small group
        enemy_group = random.sample(valid_monsters, min(2, len(valid_monsters)))

        # Final enemy party
        enemy_party = []
        for m in enemy_group:
            enemy_party.append({
                "id": f"enemy_{random.randint(1000, 9999)}",
                "name": m.get("name", "Unknown"),
                "HP": m.get("hp", 20),
                "AC": m.get("ac", 12),
                "DEX": m.get("dex", 10),
                "team": "hostile"
            })

        # (Optional) Start Firebase battle record here if desired
        return {
            "enemies": enemy_party,
            "effective_cr": effective_cr,
            "danger_level": danger_level,
            "distance_factor": distance_factor,
            "location": location
        }

    except Exception as e:
        return {"error": str(e)}