
#This module manages status effect application and resolution in both RAM-based combatants and Firebase-based participants. It handles turn-based effect decay, source tracking, and persistence syncing.
#It supports the combat, firebase, and npc systems.

from datetime import datetime
from firebase_admin import db

def apply_status_effect(combatant, effect_name, duration=3, source=None):
    effect = {
        "name": effect_name,
        "duration": duration,
        "applied_by": source,
        "timestamp": datetime.utcnow().isoformat()
    }

    combatant.status_effects.append(effect)
    combatant.attributes["status_effects"] = combatant.status_effects

    if duration > 20:
        db.reference(f"/npcs/{combatant.character_id}/status_effects").push(effect)


def tick_status_effects(combatant):
    updated = []
    for effect in combatant.status_effects:
        effect["duration"] -= 1
        if effect["duration"] > 0:
            updated.append(effect)
    combatant.status_effects = updated
    combatant.attributes["status_effects"] = updated


def resolve_status_effects(target_id):
    """
    Ticks down duration of active status effects on a combat participant.
    Removes expired effects.
    Updates Firebase.
    """
    ref = db.reference("/combat_state")
    combat_states = ref.get()

    for battle_id, battle in (combat_states or {}).items():
        participants = battle.get("participants", {})
        if target_id in participants:
            participant = participants[target_id]
            effects = participant.get("status_effects", [])
            updated = []
            expired = []

            for e in effects:
                e["duration"] -= 1
                if e["duration"] > 0:
                    updated.append(e)
                else:
                    expired.append(e["name"])

            participant["status_effects"] = updated
            participants[target_id] = participant

            db.reference(f"/combat_state/{battle_id}/participants").set(participants)

            return {
                "target_id": target_id,
                "expired": expired,
                "active": [e["name"] for e in updated]
            }

    return {"target_id": target_id, "error": "Not found in any active combat."}

def resolve_status_effects(target_id):
    ref = db.reference(f"/combat_state")
    combat_states = ref.get()

    for battle_id, battle in (combat_states or {}).items():
        participants = battle.get("participants", {})
        if target_id in participants:
            effects = participants[target_id].get("status_effects", [])
            updated = []
            for e in effects:
                e["duration"] -= 1
                if e["duration"] > 0:
                    updated.append(e)
            participants[target_id]["status_effects"] = updated
            db.reference(f"/combat_state/{battle_id}/participants").set(participants)
