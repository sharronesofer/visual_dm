
# This file defines a global in-memory cache for tracking active battles. It is minimal but foundational for tracking battle state during live combat sessions.

ACTIVE_BATTLES = {}
