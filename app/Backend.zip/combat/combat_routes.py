
#This is the central route handler for combat logic, including AI-driven turns, long rests, battle state syncing, and turn-based logic. It interacts with nearly every major combat-related module, and is the primary gateway for in-battle logic via Flask endpoints.
#It touches combat, gpt, firebase, npc, world, and narrative subsystems.

from flask import Blueprint, request, jsonify
from firebase_admin import db
from app.combat.ai_combat_utils import choose_action_gpt
from app.combat.combat_handler_class import CombatAction
from app.combat.combat_class import Combatant
from app.regions.worldgen_utils import attempt_rest
from app.combat.combat_utils import resolve_combat_action
from app.combat.combat_ram import ACTIVE_BATTLES
from app.combat.combat_state_firebase_utils import sync_post_combat_state_to_firebase
from app.combat.combat_state_class import CombatState

combat_bp = Blueprint("combat", __name__)

@combat_bp.route('/combat_round', methods=['POST'])
def combat_round():
    data = request.get_json(force=True)
    combatants = data.get("combatants")
    battlefield_context = data.get("battlefield_context", {})

    if not isinstance(combatants, list) or not combatants:
        return jsonify({"error": "A non-empty 'combatants' list is required."}), 400

    actions = []

    for combatant in combatants:
        if combatant.get("type") == "npc":
            action_data = choose_action_gpt(combatant, battlefield_context)

            target_id = action_data.get("target")
            if not target_id:
                actions.append({
                    "character_id": combatant.get("npc_id"),
                    "result": "No target specified"
                })
                continue

            # TEMPORARY: Mock target data (should be loaded from DB in real case)
            target_data = {
                "id": target_id,
                "character_id": target_id,
                "attributes": {"HP": 30, "AC": 12, "DEX": 10},
                "feats": [],
                "equipment": []
            }

            attacker_obj = Combatant(combatant["npc_id"], combatant)
            target_obj = Combatant(target_id, target_data)

            combat_action = CombatAction(attacker_obj, target_obj, action_data, battlefield_context)
            result = combat_action.resolve()
            actions.append(result)

        else:
            actions.append({
                "character_id": combatant.get("character_id"),
                "result": "awaiting_player_action"
            })

    return jsonify({"results": actions}), 200


@combat_bp.route('/long_rest/<character_id>', methods=['POST'])
def long_rest(character_id):
    char_ref = db.reference(f"/players/{character_id}")
    character = char_ref.get()

    if not character:
        return jsonify({"error": "Character not found."}), 404

    location = character.get("location", "0_0")
    region, poi = "default_region", location  # Temporary fallback if needed
    if isinstance(location, dict):
        region = location.get("region", "default_region")
        poi = location.get("poi", "0_0")
    elif isinstance(location, str) and "_" in location:
        region, poi = "default_region", location

    result = attempt_rest(region, poi)    
    return jsonify(result), 200

@combat_bp.route('/combat/action/<battle_id>', methods=['POST'])
def combat_action_handler(battle_id):
    data = request.get_json(force=True)
    character_id = data.get("character_id")
    action = data.get("action")

    if not character_id or not action:
        return jsonify({"error": "Missing character_id or action data"}), 400

    combat_state = ACTIVE_BATTLES.get(battle_id)
    if not combat_state:
        return jsonify({"error": "Combat state not found for battle_id"}), 404

    actor = combat_state.get_current_actor()
    if actor.character_id != character_id:
        return jsonify({"error": f"It is not {character_id}'s turn"}), 403

    # Find target
    target_id = action.get("target")
    opponents = combat_state.get_opponents(actor)
    target = next((o for o in opponents if o.character_id == target_id), None)

    if not target:
        return jsonify({"error": f"Target {target_id} not found in opponents"}), 400

    # Apply action
    combat_action = CombatAction(actor, target, action)
    result = combat_action.resolve()
    combat_state.add_log(result)

    # Advance turn
    combat_state.advance_turn()

    # Check if combat is over
    if combat_state.is_over():
        sync_post_combat_state_to_firebase(combat_state.party, combat_state.enemies)
        del ACTIVE_BATTLES[battle_id]
        result["combat_ended"] = True
    else:
        result["next_actor"] = combat_state.get_current_actor().character_id

    return jsonify(result), 200

@combat_bp.route("/combat/start", methods=["POST"])
def start_combat():
    try:
        data = request.json
        region = data.get("region_id")
        poi = data.get("poi_id")
        if not region or not poi:
            return jsonify({"error": "region_id and poi_id are required"}), 400

        encounter_id = f"encounter_{random.randint(1000,9999)}"
        db.reference(f"/combat_encounters/{encounter_id}").set({
            "region": region,
            "poi": poi,
            "status": "active",
            "participants": data.get("participants", [])
        })
        return jsonify({"encounter_id": encounter_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@combat_bp.route("/combat/turn", methods=["POST"])
def process_turn():
    try:
        data = request.json
        encounter_id = data.get("encounter_id")
        action = data.get("action")
        if not encounter_id or not action:
            return jsonify({"error": "encounter_id and action required"}), 400

        # Simple simulation
        return jsonify({"message": f"Action '{action}' processed for encounter '{encounter_id}'."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@combat_bp.route("/combat/end", methods=["POST"])
def end_combat():
    try:
        data = request.json
        encounter_id = data.get("encounter_id")
        if not encounter_id:
            return jsonify({"error": "encounter_id required"}), 400

        db.reference(f"/combat_encounters/{encounter_id}").update({"status": "ended"})
        return jsonify({"message": f"Encounter '{encounter_id}' ended."})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@combat_bp.route('/combat/resolve_action', methods=['POST'])
def resolve_action():
    data = request.get_json(force=True)
    combat_id = data.get("combat_id")
    action_data = data.get("action_data")

    if combat_id not in ACTIVE_BATTLES:
        return jsonify({"error": "Combat session not found"}), 404
    
    combat_state = ACTIVE_BATTLES[combat_id]
    result = resolve_combat_action(combat_state, action_data)
    
    return jsonify(result), 200

@combat_bp.route('/combat/state', methods=['GET'])
def get_combat_state():
    combat_id = request.args.get("combat_id")
    if combat_id not in ACTIVE_BATTLES:
        return jsonify({"error": "Combat state not found"}), 404
    
    combat_state = ACTIVE_BATTLES[combat_id]
    return jsonify(combat_state.to_dict()), 200

@combat_bp.route("/combat/initiate", methods=["POST"])
def initiate_combat():
    """
    Starts a new combat encounter.
    Expects JSON: { "attacker_id": "...", "defender_ids": ["...","..."] }
    Returns: { "encounter_id": "enc_12345" }
    """
    try:
        data = request.json or {}
        attacker_id  = data.get("attacker_id")
        defender_ids = data.get("defender_ids", [])

        if not attacker_id or not defender_ids:
            return jsonify({"error": "attacker_id and defender_ids required"}), 400

        # --- create encounter stub in Firebase --------------------------
        from uuid import uuid4
        enc_id = f"enc_{uuid4().hex[:8]}"
        db.reference(f"/combat_encounters/{enc_id}").set({
            "attacker":  attacker_id,
            "defenders": defender_ids,
            "status":    "active"
        })

        return jsonify({"encounter_id": enc_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500
