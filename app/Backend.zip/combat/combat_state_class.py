
#This file defines CombatState, which represents the live structure and logic of an ongoing combat session. It tracks round progression, actor turns, and victory conditions. It is the authoritative structure for turn-based combat managed in RAM.
import uuid
from uuid import uuid4
from datetime import datetime
from app.combat.combat_class import Combatant

class CombatState:
    def __init__(self, party, enemies, name="Combat"):
        self.battle_id = f"battle_{uuid.uuid4().hex[:6]}"
        self.name = name
        self.start_time = datetime.utcnow().isoformat()
        self.round = 1
        self.log = []

        self.party = [Combatant(p["id"], p) for p in party]
        self.enemies = [Combatant(e["id"], e) for e in enemies]
        self.turn_order = sorted(
            self.party + self.enemies,
            key=lambda c: c.attributes.get("DEX", 10),
            reverse=True
        )
        self.current_turn_index = 0

    def get_current_actor(self):
        return self.turn_order[self.current_turn_index]

    def get_opponents(self, actor):
        return self.enemies if actor in self.party else self.party

    def advance_turn(self):
        self.current_turn_index = (self.current_turn_index + 1) % len(self.turn_order)
        if self.current_turn_index == 0:
            self.round += 1

    def add_log(self, message):
        self.log.append(f"[Round {self.round}] {message}")

    def is_over(self):
        party_alive = any(p.current_hp > 0 for p in self.party)
        enemies_alive = any(e.current_hp > 0 for e in self.enemies)

        if not party_alive or not enemies_alive:
            return True  # Traditional end

        # 🎯 Retreat logic: enemies flee if outnumbered 2:1 and morale traits match
        if len(self.enemies) > 0 and len(self.party) > 0:
            if len(self.party) >= 2 * len(self.enemies):
                for enemy in self.enemies:
                    if hasattr(enemy, "traits") and "cowardly" in enemy.traits:
                        self.log.append("[Retreat] Enemies retreat due to overwhelming odds.")
                        self.status = "retreated"
                        return True

        # 🏳 Surrender logic: surrender flag
        surrender_possible = all(
            hasattr(e, "traits") and "loyal" not in e.traits
            for e in self.enemies if e.current_hp > 0
        )
        if surrender_possible:
            self.status = "surrender_pending"
            self.log.append("[Surrender] Enemies offer to surrender.")
            return False  # Combat pauses for player input

    def accept_surrender(self):
        """
        Handles surrender acceptance by the player.
        Flags enemies as 'defeated' without killing them.
        Ends combat.
        """
        for enemy in self.enemies:
            enemy.status_effects.append("surrendered")
            enemy.current_hp = max(1, enemy.current_hp)  # Ensure they're alive
        self.log.append("[Surrender Accepted] Combat ends peacefully.")
        self.status = "surrender_resolved"
        return True

    def handle_retreat(self):
        """
        Finalizes a retreat: ends combat and logs consequences.
        Could trigger world events later (e.g., chase or rumor).
        """
        self.log.append("[Retreat Confirmed] Enemies have fled the battlefield.")
        self.status = "retreated_resolved"
        return True
