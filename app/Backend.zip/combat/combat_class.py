
#This file implements core combat logic for individual actors—players or NPCs. It handles damage application, action slot consumption, and MP usage. It defines battle state manipulation through Combatant and CombatAction.

import random
from app.combat.status_effects_utils import apply_status_effect

class Combatant:
    def apply_damage(self, dmg):
        if self.temp_hp > 0:
            absorbed = min(self.temp_hp, dmg)
            self.temp_hp -= absorbed
            dmg -= absorbed

        self.current_hp = max(0, self.current_hp - dmg)
        self.attributes["HP"] = self.current_hp
        return dmg

    def heal(self, amount):
        self.current_hp = min(self.max_hp, self.current_hp + amount)
        self.attributes["HP"] = self.current_hp
        return self.current_hp

    def add_temp_hp(self, amount):
        self.temp_hp = max(self.temp_hp, amount)

    def use_mp(self, amount):
        if self.temp_mp > 0:
            absorbed = min(self.temp_mp, amount)
            self.temp_mp -= absorbed
            amount -= absorbed

        if self.current_mp < amount:
            return False  # Not enough MP

        self.current_mp -= amount
        self.attributes["MP"] = self.current_mp
        return True

    def restore_mp(self, amount):
        self.current_mp = min(self.max_mp, self.current_mp + amount)
        self.attributes["MP"] = self.current_mp
        return self.current_mp

    def add_temp_mp(self, amount):
        self.temp_mp = max(self.temp_mp, amount)

    def __init__(self, character_id, full_attributes):
        self.character_id = character_id
        self.attributes = full_attributes  # Includes HP, MP, DEX, attributes, etc.

        # Health tracking
        self.max_hp = full_attributes.get("HP", 0)
        self.current_hp = full_attributes.get("HP", 0)
        self.temp_hp = 0

        # Mana tracking
        self.max_mp = full_attributes.get("MP", 0)
        self.current_mp = full_attributes.get("MP", 0)
        self.temp_mp = 0

        # Action economy slots (standard D&D style)
        self.action_slots = {
            "action": False,
            "bonus": False,
            "movement": False,
            "free": 0,
            "trigger": {
                "action": False,
                "bonus": False,
                "free": False
            }
        }

        # Store initial turn-state or conditions here if needed
        self.status_effects = []


    def reset_action_slots(self):
        self.action_slots = {
            "action": False,
            "bonus": False,
            "movement": False,
            "free": 0,
            "trigger": {"action": False, "bonus": False, "free": False}
        }

    def consume_slot(self, slot_type):
        if slot_type == "action":
            if self.action_slots["action"]: return False
            self.action_slots["action"] = True
        elif slot_type == "bonus":
            if self.action_slots["bonus"]: return False
            self.action_slots["bonus"] = True
        elif slot_type == "movement":
            if self.action_slots["movement"]: return False
            self.action_slots["movement"] = True
        elif slot_type == "free":
            if self.action_slots["free"] >= 2: return False
            self.action_slots["free"] += 1
        elif slot_type.startswith("trigger"):
            _, subtype = slot_type.split("_")
            if self.action_slots["trigger"].get(subtype): return False
            self.action_slots["trigger"][subtype] = True
        else:
            return False
        return True

    def resolve(self):
        # Check and consume action economy slot (default: "action")
        action_type = self.action.get("action_type", "action")
        if not self.attacker.consume_slot(action_type):
            return {
                "result": "slot_used",
                "slot": action_type,
                "character_id": self.attacker.character_id
            }

        # Check MP cost
        mp_cost = self.action.get("mp_cost", 0)
        if mp_cost > 0:
            if not self.attacker.use_mp(mp_cost):
                return {
                    "result": "insufficient_mp",
                    "action": self.action.get("name"),
                    "character_id": self.attacker.character_id
                }

        # Damage resolution
        base_damage = self.action.get("base_damage", 10)
        damage_dealt = self.target.apply_damage(base_damage)

        # Status effect
        status = self.action.get("status_condition")
        if status:
            duration = self.action.get("effect_duration", 3)
            apply_status_effect(self.target, status, duration, source=self.attacker.character_id)

        # Result payload
        return {
            "attacker": self.attacker.character_id,
            "target": self.target.character_id,
            "action": self.action.get("name", "basic_attack"),
            "action_type": action_type,
            "damage": damage_dealt,
            "mp_used": mp_cost,
            "status_applied": status,
            "target_remaining_hp": self.target.attributes.get("HP", "?")
        }
    from app.combat.status_effects_utils import apply_status_effect
