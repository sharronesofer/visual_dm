
#This module manages persistent tracking and evolution of player-driven story arcs. It connects PlayerArc objects to Firebase and allows auto-generation of arc titles and themes using GPT.
#It is a key component of the narrative, quest, and player identity systems.

from app.quests.arcs_class import PlayerArc
from app.utils.gpt_class import GPTClient
from app.pois.poi_distance_utils import bucket_pois_by_proximity
from firebase_admin import db
import json
import requests

from app.memory.memory_utils import process_gpt_memory_entry
from app.factions.war_utils import generate_gpt_quest_text

def load_player_arc(character_id):
    ref = db.reference(f"/arcs/{character_id}")
    data = ref.get()
    if not data:
        return None
    return PlayerArc(character_id, data.get("arc_data"), data.get("progress_state"))

def save_player_arc(arc: PlayerArc):
    payload = arc.finalize()
    ref = db.reference(f"/arcs/{arc.character_id}")
    ref.set(payload)

def update_arc_with_event(character_id, event):
    arc = load_player_arc(character_id)

    # === Memory logging: happens for both new and ongoing arcs ===
    process_gpt_memory_entry(character_id, {
        "event": event,
        "tags": ["arc_progress"]
    })

    if not arc:
        # === Auto-generate title and theme via GPT ===
        system_prompt = "You are a fantasy RPG campaign manager. Title and tag narrative arcs."
        user_prompt = f"Summarize and title an emerging RPG story arc based on this first event:\n\n{event}"

        try:
            gpt = GPTClient()
            response = gpt.call(system_prompt, user_prompt, temperature=0.7, max_tokens=150)
            parsed = json.loads(response)
        except Exception:
            parsed = {"title": "Untitled Arc", "theme": "unknown"}

        arc_data = {
            "title": parsed.get("title", "Untitled Arc"),
            "theme": parsed.get("theme", "mystery"),
            "geo_tags": []
        }

        arc = PlayerArc(
            character_id=character_id,
            current_arc=arc_data,
            progress_state={
                "milestones": [event],
                "current_stage": 1,
                "completed": False
            }
        )
    else:
        arc.update_progress(event)

    return arc

def trigger_war_arc(region, poi_id=None, arc_type="defend", urgency=1):
    """
    Triggers a new arc or quest from war-related events.
    Types:
    - defend, evacuate, assassinate, reclaim
    """
    arc_prompt = f"Generate a {arc_type} quest for the war in region {region}."
    if poi_id:
        arc_prompt += f" The quest should be focused on POI '{poi_id}'."
    
    summary = generate_gpt_quest_text(arc_prompt)
    arc = {
        "region": region,
        "poi": poi_id,
        "type": arc_type,
        "summary": summary,
        "created": datetime.utcnow().isoformat(),
        "urgency": urgency,
        "tags": ["war", arc_type]
    }

    db.reference(f"/player_arcs").push(arc)
    return arc


def generate_character_arc(character_data):
    """
    Generates and saves a starting narrative arc for a new character.
    Only happens once during character creation.
    """
    character_id = character_data.get("character_id")
    if not character_id:
        raise ValueError("Character ID is missing!")

    arc_ref = db.reference(f"/player_arcs/{character_id}")
    existing_arc = arc_ref.get()

    if existing_arc:
        print(f"✅ Character {character_id} already has an arc — skipping generation.")
        return

    # Build basic prompt if no arc exists
    character_name = character_data.get("character_name", "Unnamed Adventurer")
    race = character_data.get("race", "Unknown Race")
    region = character_data.get("region_id", "Unknown Region")
    background = character_data.get("background", "")

    prompt = (
        f"This character: {character_name} ({race}) has arrived in {region}.\n"
        f"Background: {background}\n"
        "Create a compelling starting narrative arc or quest motivation."
    )

    try:
        response = requests.post("http://localhost:5050/dm_response", json={
            "mode": "arc_prompt",
            "character_id": character_id,
            "prompt": prompt
        })
        if response.status_code == 200:
            arc_text = response.json().get("reply", "Embark on your journey.")
            arc_data = {
                "arc_text": arc_text,
                "created_at": character_data.get("created_at")
            }
            arc_ref.set(arc_data)
            print(f"✅ Arc generated and saved for {character_name}")
        else:
            print(f"❌ Failed to generate arc for {character_name}: {response.status_code}")
    except Exception as e:
        print(f"❌ Error during arc generation for {character_id}: {e}")