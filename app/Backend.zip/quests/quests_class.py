
#This file defines the structure of a single quest entry in the quest log. It ensures each entry is:
#Regionally contextualized
#Timestamped
#Tagged for search/filtering
#Source-attributed (e.g., generated, player-reported)
#It supports the quest, arc, narrative, and firebase systems.

from dataclasses import dataclass
from typing import List
from firebase_admin import db
from uuid import uuid4
from datetime import datetime, timedelta
from app.utils.gpt_class import GPTClient
from app.memory.memory_utils import store_interaction
from app.npc.npc_loyalty_utils import apply_loyalty_event
from app.pois.poi_distance_utils import bucket_pois_by_proximity
from app.equipment.loot_utils import group_equipment_by_type
from app.factions.faction_utils import adjust_faction_opinion
import json
import random

@dataclass
class QuestLogEntry:
    region: str
    poi: str
    timestamp: str
    summary: str
    tags: List[str]
    source: str
    player_id: str

    def to_dict(self):
        return self.__dict__

class QuestManager:
    def __init__(self, character_id):
        self.character_id = character_id

    def create_log_entry(self, region, poi, summary, tags, source):
        entry = QuestLogEntry(
            region=region,
            poi=poi,
            timestamp=datetime.utcnow().isoformat(),
            summary=summary,
            tags=tags,
            source=source,
            player_id=self.character_id
        )
        ref = db.reference(f"/quests/{self.character_id}").push()
        ref.set(entry.to_dict())
        return ref.key

    def list_quests(self):
        return db.reference(f"/quests/{self.character_id}").get() or {}

    def get_entry(self, entry_id):
        return db.reference(f"/quests/{self.character_id}/{entry_id}").get()

    def create_from_gpt(self, arc, close_pois, far_pois, npc_list=None):
        system_prompt = "You are a quest generator for a persistent fantasy world."
        user_prompt = (
            f"Current Arc Title: {arc.get('title', 'Unknown')}\n"
            f"Theme: {arc.get('theme', 'mystery')}\n\n"
            f"Nearby POIs (close): {', '.join(close_pois)}\n"
            f"Farther POIs (far): {', '.join(far_pois)}\n"
        )
        if npc_list:
            user_prompt += f"\nNPCs available: {', '.join(npc_list)}\n"

        user_prompt += (
            "\nGenerate a JSON object with:\n"
            "- title, description, step_type, target, poi_name, region (opt), arc_id, tags\n"
            f"- arc_id: use this: {arc.get('id', 'arc_unknown')}\nRespond only in JSON."
        )

        gpt = GPTClient()
        response = gpt.call(system_prompt, user_prompt, temperature=0.7, max_tokens=400)
        try:
            quest_data = json.loads(response)
        except Exception:
            return {"error": "Failed to parse GPT response.", "raw": response}

        poi_root = db.reference("/poi_state").get() or {}
        found = False
        for region_name, pois in poi_root.items():
            for poi_id, data in pois.items():
                if data.get("name", "").lower() == quest_data.get("poi_name", "").lower():
                    quest_data["region"] = region_name
                    quest_data["poi"] = poi_id
                    found = True
                    break
            if found:
                break
        if not found:
            return {"error": "Invalid or hallucinated POI.", "quest": quest_data}

        quest_data["player_id"] = self.character_id
        quest_data["timestamp"] = db.SERVER_TIMESTAMP
        quest_id = str(uuid4())

        db.reference(f"/quests/{self.character_id}/{quest_id}").set(quest_data)
        db.reference(f"/questlogs/{self.character_id}").push({
            "quest_id": quest_id,
            "title": quest_data["title"],
            "poi": quest_data["poi"],
            "timestamp": db.SERVER_TIMESTAMP
        })

        return {"quest_id": quest_id, "quest": quest_data}

    def complete_quest(self, quest_id):
        # [No changes here — copy your final version]
        pass  # just omit for brevity in this message

    def create_quest_log_entry(self, quest_id, text, timestamp, stage=None):
        return {
            "quest_id": quest_id,
            "text": text,
            "timestamp": timestamp,
            "stage": stage or "active"
        }

    def generate_quest_stub(self, prompt, theme_tags, danger_level, npc_name):
        return {
            "title": "Quest Title from GPT",
            "description": "Generated quest about ...",
            "tags": theme_tags,
            "giver": npc_name,
            "danger": danger_level
        }

    def get_quest_log_entry(character_id, quest_id):
        return db.reference(f"/quests/{character_id}/{quest_id}").get()
