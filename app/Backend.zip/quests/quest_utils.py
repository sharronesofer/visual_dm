"""
This module manages the quest lifecycle, including creation (manual & GPT), logging, and completion.
It integrates with quest, narrative, GPT, memory, faction, equipment, POI, and arc systems.
"""

from firebase_admin import db
from uuid import uuid4
from datetime import datetime, timedelta
import json
import random

from app.quests.quests_class import QuestLogEntry
from app.utils.gpt_class import GPTClient
from app.memory.memory_utils import store_interaction
from app.npc.npc_loyalty_utils import apply_loyalty_event
from app.pois.poi_distance_utils import bucket_pois_by_proximity
from app.equipment.loot_utils import group_equipment_by_type
from app.factions.faction_utils import adjust_faction_opinion

# === Miscellaneous Quest Generators / World Hooks ===

def process_quest_hooks():
    hooks_ref = db.reference("/potential_quest_hooks")
    hooks = hooks_ref.get() or {}
    if not hooks:
        return {"message": "No quest hooks found."}

    created = []
    for hook_id, hook in hooks.items():
        npc, motive, poi = hook.get("npc"), hook.get("motive"), hook.get("poi")
        if not npc or not motive or not poi:
            continue

        prompt = f"NPC '{npc}' is in '{poi}' with motive '{motive}'. Generate a 1-line quest hook."
        summary = call(prompt, system_prompt="You are a fantasy quest writer.") or "Someone has a problem."

        quest_id = f"quest_{random.randint(100000, 999999)}"
        db.reference(f"/quests/generated/{quest_id}").set({
            "npc": npc,
            "motive": motive,
            "poi": poi,
            "summary": summary,
            "generated_at": datetime.utcnow().isoformat()
        })
        db.reference(f"/potential_quest_hooks/{hook_id}").delete()
        created.append(quest_id)

    return {"created_quests": created}


def quest_board_tick():
    poi_root = db.reference("/poi_state").get() or {}

    eligible_buildings = {
        "general_store": 0.3, "pawn_shop": 0.4, "knick_knack_shop": 0.5, "apothecary": 0.2,
        "alchemist": 0.25, "castle": 0.15, "spirit_post_office": 0.5,
        "temple_of_one_eye": 0.2, "goat_opera": 0.5
    }

    for region, pois in poi_root.items():
        for poi_id, poi_data in pois.items():
            buildings = poi_data.get("buildings", {})
            for building in buildings:
                if building not in eligible_buildings or random.random() > eligible_buildings[building]:
                    continue

                board_ref = db.reference(f"/quest_boards/{region}/{poi_id}/quests")
                board = [q for q in board_ref.get() or [] if q.get("expires_at", "") > datetime.utcnow().isoformat()]

                for _ in range(random.randint(1, 2)):
                    quest_id = f"quest_{random.randint(100000, 999999)}"
                    npcs = poi_data.get("npcs_present", [])
                    if not npcs:
                        continue

                    npc = random.choice(npcs)
                    if building == "spirit_post_office":
                        qtype, prompt = "spiritual", "Write a cryptic quest by a ghost/spirit."
                    elif building == "goat_opera":
                        qtype, prompt = "joke", "Write a bizarre quest for a goat-themed opera."
                    else:
                        qtype, prompt = "default", "Generate a 1-sentence quest for a public board."

                    summary = call(prompt, system_prompt="You are a fantasy quest board writer.") or "Help someone."

                    board.append({
                        "id": quest_id,
                        "npc": npc,
                        "summary": summary,
                        "reward": f"{random.randint(15, 60)} gold",
                        "title": summary.split(".")[0],
                        "expires_at": (datetime.utcnow() + timedelta(days=1)).isoformat(),
                        "type": qtype,
                        "source_building": building
                    })

                board_ref.set(board)


def npc_personal_quest_tick():
    all_npcs = db.reference("/npcs").get() or {}
    new_posts = []

    for npc_id, npc in all_npcs.items():
        if random.random() > 0.01:
            continue

        tags = npc.get("hidden_traits", [])
        if not tags:
            continue

        memory = db.reference(f"/npc_memory/{npc_id}/rag_log").get() or []
        if "ambitious" in tags:
            qtype, summary = "gain favor", "Wants help impressing a local noble."
        elif "vengeful" in tags:
            qtype, summary = "revenge", "Seeks revenge for a slight from another NPC."
        elif "curious" in tags:
            qtype, summary = "discovery", "Hopes to uncover a forgotten ruin nearby."
        else:
            continue

        quest_id = f"npcq_{random.randint(100000,999999)}"
        region = npc.get("region", "unknown")
        poi = npc.get("location", "unknown")

        db.reference(f"/quest_boards/{region}/{poi}/quests").push({
            "id": quest_id,
            "npc": npc_id,
            "summary": summary,
            "title": summary.split(".")[0],
            "reward": f"{random.randint(20, 75)} gold",
            "expires_at": (datetime.utcnow() + timedelta(days=1)).isoformat(),
            "type": "npc_personal",
            "tags": [qtype]
        })

        new_posts.append({"npc": npc_id, "quest_id": quest_id, "summary": summary})

    return new_posts
