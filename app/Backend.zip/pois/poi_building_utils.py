
import json
import random
from firebase_admin import db
from uuid import uuid4
from datetime import datetime
from app.utils.gpt_class import GPTClient
from math import ceil
from openai import ChatCompletion  # Make sure you have this if using GPT API

# Load building profile data
with open("rules_json/building_profiles.json") as f:
    BUILDING_PROFILES = json.load(f)

CASTLE_VARIANTS = [
    "obsidian spire", "floating citadel", "iron bastion",
    "twilight keep", "sunken fortress", "fungal throne",
    "skyhook monastery", "crumbling warspire", "tent city of blades",
    "crystal tower", "molten watchpost", "bone crown hall"
]

def generate_buildings_for_social_poi(poi_size):
    building_templates = {
        "village": ["blacksmith", "tavern", "farm", "market", "chapel"],
        "town": ["blacksmith", "tavern", "market", "inn", "guild hall", "chapel", "watchtower"],
        "city": ["castle", "barracks", "temple", "university", "market", "inn", "guild hall", "arena"],
        "metropolis": ["grand cathedral", "royal palace", "arcane academy", "coliseum", "merchant district"]
    }

    options = building_templates.get(poi_size.lower(), [])
    num_buildings = {
        "village": random.randint(5, 9),
        "town": random.randint(10, 15),
        "city": random.randint(20, 30),
        "metropolis": random.randint(30, 50)
    }.get(poi_size.lower(), 5)

    return random.sample(options, min(len(options), num_buildings))

def generate_castle_variant(region_name, poi_id, faction_id):
    """
    Builds a named castle structure based on ruling faction and region motifs.
    """
    motif_data = db.reference(f"/regions/{region_name}/motif_pool/active_motifs").get() or []
    motif_tags = [m.get("theme") for m in motif_data]

    variant = random.choice(CASTLE_VARIANTS)
    castle_name = generate_castle_name(motif_tags, variant)

    return {
        "type": "castle",
        "variant": variant,
        "name": castle_name,
        "owner": faction_id,
        "tags": ["faction_hq", "ruling_seat"],
        "tile_size": 4
    }

CITY_SIZE_ORDER = ["hamlet", "village", "town", "city", "capital"]

def size_allows(min_size, poi_size):
    try:
        return CITY_SIZE_ORDER.index(poi_size) >= CITY_SIZE_ORDER.index(min_size)
    except ValueError:
        return False

def enrich_poi_with_buildings(region_name, poi_id, poi_data):
    if "social" not in poi_data.get("tags", []):
        print(f"[ENRICH] POI {poi_id} skipped (not social)")
        return poi_data

    poi_size = poi_data.get("size", "village")
    chosen_buildings = []

    for key, profile in BUILDING_PROFILES.items():
        if not size_allows(profile.get("min_city_size", "hamlet"), poi_size):
            continue
        if random.random() < (profile.get("weight", 1) / 10):
            chosen_buildings.append(key)

    existing = poi_data.get("buildings", [])
    final_buildings = []

    for b_key in chosen_buildings:
        profile = BUILDING_PROFILES[b_key]
        try:
            owner = generate_npcs_for_poi(region=region_name, poi_id=poi_id)["npcs_generated"][0]
        except Exception as e:
            print(f"[ENRICH ERROR] Failed to create NPC for {b_key}: {e}")
            continue

        building_name = f"{random.choice(['Old', 'Grand', 'Mystic'])} {b_key.replace('_', ' ').title()}"
        building_id = f"building_{uuid4().hex[:8]}"

        building_data = {
            "id": building_id,
            "type": b_key,
            "category": profile.get("type", "commercial"),
            "name": building_name,
            "tile_size": profile.get("tile_size", 1),
            "services": profile.get("services", []),
            "inventory_tags": profile.get("inventory_tags", []),
            "owner_npc_id": owner,
            "faction_tag": profile.get("faction_tag", None)
        }

        # If shopkeeper, seed merchant inventory
        if profile.get("type") == "commercial":
            inventory = generate_inventory_from_tags(profile.get("inventory_tags", []))
            db.reference(f"/npcs/{owner}/inventory").set(inventory)

        final_buildings.append(building_data)

    poi_data["buildings"] = existing + final_buildings
    db.reference(f"/poi_state/{region_name}/{poi_id}").update({"buildings": poi_data["buildings"]})

    print(f"[POI ENRICH] Added {len(final_buildings)} buildings to {poi_id} in {region_name}")
    return poi_data

def npc_reclaim_pois():
    poi_root = db.reference("/poi_state").get() or {}
    npc_data = db.reference("/npcs").get() or {}
    reclaimed = []

    for region, pois in poi_root.items():
        for poi_id, poi in pois.items():
            if poi.get("control_status") != "hostile":
                continue

            if poi.get("npcs_present"):
                continue

            if random.random() > 0.1:  # 10% daily chance
                continue

            # Find a non-party NPC to send
            candidates = [npc_id for npc_id, npc in npc_data.items()
                          if npc.get("party_affiliation") is None and npc.get("location") != poi_id]

            if not candidates:
                continue

            npc_id = random.choice(candidates)

            # Move NPC to POI
            db.reference(f"/npcs/{npc_id}/location").set(poi_id)
            db.reference(f"/poi_state/{region}/{poi_id}/npcs_present").set([npc_id])
            db.reference(f"/poi_state/{region}/{poi_id}/control_status").set("cleared")
            db.reference(f"/poi_state/{region}/{poi_id}/event_log").push({
                "type": "reclaimed_by_npc",
                "npc": npc_id,
                "day": datetime.utcnow().isoformat()
            })

            # Optional motif shift (less chaos)
            db.reference(f"/poi_state/{region}/{poi_id}/motif_pool/active_motifs").set([
                {"theme": 19, "lifespan": 3, "entropy_tick": 0, "weight": 4}  # motif: peace
            ])

            reclaimed.append({"region": region, "poi": poi_id, "npc": npc_id})

    return reclaimed

from uuid import uuid4
import random
from datetime import datetime
from firebase_admin import db
from app.utils.gpt_class import GPTClient
from math import ceil

gpt_client = GPTClient()

def generate_npcs_for_poi(region_name: str, poi_id: str):
    """
    Generates fully detailed NPCs for a given POI:
    - Name, Race, Class
    - Background (via GPT-4.1-nano)
    - 3 Personal Goals (via GPT-4.1-nano)
    - Hidden Traits (mathematically generated)
    - Narrative Motifs seeded
    - Social Relationships seeded
    """
    poi_ref = db.reference(f"/poi_state/{region_name}/{poi_id}")
    poi = poi_ref.get()
    if not poi:
        return {"error": f"POI {poi_id} in region {region_name} not found."}

    templates = db.reference("/npc_templates").get() or {}
    if not templates:
        return {"error": "No NPC templates available."}

    num_buildings = len(poi.get("buildings", []))
    expected_population = max(2, int(2.5 * num_buildings))
    generated_npcs = []

    # --- Step 1: Create NPCs ---
    for _ in range(expected_population):
        template = random.choice(list(templates.values()))
        npc_id = f"npc_{uuid4().hex[:8]}"

        name = template.get("name", "Unnamed NPC")
        race = template.get("race", "Human")
        char_class = template.get("class", "Commoner")

        # Background via GPT
        try:
            background_prompt = (
                f"Name: {name}, Race: {race}, Class: {char_class}. "
                "Write a short fantasy RPG background (under 75 words)."
            )
            background = gpt_client.call(
                system_prompt="You are a fantasy NPC generator.",
                user_prompt=background_prompt,
                temperature=0.6,
                max_tokens=100
            )
        except Exception:
            background = "A traveler with a mysterious past."

        # Personal Goals via GPT
        try:
            goals_prompt = (
                f"Name: {name}, Race: {race}, Class: {char_class}, Background: {background}. "
                "Generate 3 short personal goals for this character."
            )
            goals_response = gpt_client.call(
                system_prompt="You create 3 personal goals for fantasy NPCs.",
                user_prompt=goals_prompt,
                temperature=0.7,
                max_tokens=150
            )
            goals = [g.strip("-• ") for g in goals_response.split("\n") if g.strip()]
            goals = goals[:3]
        except Exception:
            goals = ["Find meaning.", "Protect loved ones.", "Seek adventure."]

        hidden_traits = {
            "hidden_ambition": random.choice(["low", "medium", "high"]),
            "hidden_integrity": random.choice(["low", "medium", "high"]),
            "hidden_compassion": random.choice(["low", "medium", "high"]),
            "hidden_discipline": random.choice(["low", "medium", "high"]),
            "hidden_impulsivity": random.choice(["low", "medium", "high"]),
            "hidden_pragmatism": random.choice(["low", "medium", "high"]),
            "hidden_resilience": random.choice(["low", "medium", "high"]),
        }

        npc_data = {
            "id": npc_id,
            "character_name": name,
            "race": race,
            "class": char_class,
            "level": template.get("level", 1),
            "location": {"region": region_name, "poi": poi_id},
            "attributes": template.get("attributes", {}),
            "background": background,
            "personal_goals": goals,
            "motifs": {"active_motifs": [], "motif_history": [], "entropy_tick": 0},
            "origin_template": template.get("id", "unknown"),
            "hidden_traits": hidden_traits,
            "relationships": {},  # Filled next
            "rumors_heard": [],
            "loyalty_score": random.randint(-5, 5),
            "inventory": []  # Merchant hook placeholder
        }

        db.reference(f"/npcs/{npc_id}").set(npc_data)
        generated_npcs.append(npc_id)

    # --- Step 2: Seed Relationships ---
    for npc_id in generated_npcs:
        npc_ref = db.reference(f"/npcs/{npc_id}")
        npc_data = npc_ref.get() or {}

        relationships = {}
        for other_id in generated_npcs:
            if other_id != npc_id:
                relationships[other_id] = random.randint(-5, 5)  # Trust score

        npc_data["relationships"] = relationships
        npc_ref.update({"relationships": relationships})

    # --- Step 3: Link to POI ---
    poi["npcs_present"] = generated_npcs
    poi_ref.update({"npcs_present": generated_npcs})

    return {"npcs_generated": generated_npcs, "region": region_name, "poi": poi_id}
