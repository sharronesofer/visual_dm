
#This module generates narrative, object, NPC, and monster detail for rooms in a Point of Interest (POI) using GPT. It converts structured map data into prompts and parses the resulting JSON.
#It is deeply tied into gpt, narrative, poi, and world generation systems.

import json
from typing import List, Dict
from firebase_admin import db
from app.utils.gpt_class import GPTClient

def compress_room_structure_for_gpt(region, poi_id, floor_data):
    """
    Compresses POI + room tilemap into a GPT-friendly format.
    Optionally tags with faction presence or motifs if present in POI metadata.
    """
    from firebase_admin import db
    poi_meta = db.reference(f"/poi_state/{region}/{poi_id}").get() or {}

    compressed = {
        "region": region,
        "poi_id": poi_id,
        "poi_type": poi_meta.get("poi_type"),
        "danger_level": poi_meta.get("danger_level", 5),
        "factions_present": list((poi_meta.get("faction_influence") or {}).keys()),
        "rooms": []
    }

    for room_id, room in floor_data.items():
        entry = {
            "room_id": room_id,
            "tilemap": room.get("tiles", []),
            "connections": room.get("connections", [])
        }
        compressed["rooms"].append(entry)

    return compressed

def generate_enrichment_prompt(gpt_input: dict) -> str:
    """
    Formats the prompt that will be sent to GPT for enrichment.
    """
    base = (
        f"You are enriching a procedurally generated POI map.\n"
        f"POI Type: {gpt_input['poi_type']}\n"
        f"Style: {gpt_input['style']}\n"
        f"Floor: {gpt_input['floor']}\n"
        f"Danger Level: {gpt_input.get('danger_level', '?')}\n"
        f"Factions Present: {', '.join(gpt_input.get('factions_present', [])) or 'none'}\n\n"
        f"Rooms:\n"
    )
    for r in gpt_input["room_structure"]:
        base += f"- Room {r['id']}: {r['size'][0]}x{r['size'][1]}, connects to {', '.join(r['connections'])}\n"

    base += (
        "\nChoose objects (e.g., altar, lever, brazier, statue), monsters (e.g., ghost, cultist), or NPCs (named or not).\n"
        "Respond in JSON only:\n"
        "{ 'theme': ..., 'room_enrichment': { 'R1': { 'objects': [...], 'monsters': [...], 'note': '...' }, ... } }"
    )
    return base


def enrich_poi_structure(poi_meta: dict, rooms: List[Dict]) -> dict:
    """
    Compresses a POI's structure and calls GPT to enrich it with story/objects/NPCs.
    Also writes parsed data to Firebase if successful.
    """
    gpt_input = compress_room_structure_for_gpt(poi_meta, rooms)
    prompt = generate_enrichment_prompt(gpt_input)

    gpt = GPTClient()
    response = gpt.call(
        system_prompt="You are a dungeon narrative enrichment engine. Respond in JSON only.",
        user_prompt=prompt,
        temperature=0.85,
        max_tokens=600
    )

    try:
        parsed = json.loads(response)

        # Optionally persist to Firebase
        region = poi_meta.get("region")
        poi_id = poi_meta.get("id") or poi_meta.get("poi_id")
        if region and poi_id:
            db.reference(f"/poi_state/{region}/{poi_id}/rooms").set(parsed)

        return parsed
    except Exception as e:
        return {
            "error": f"Failed to parse GPT enrichment response: {str(e)}",
            "raw_response": response
        }
    
def enrich_poi_tilemap(region, poi_id, floor_id="floor_1"):
    """
    Applies GPT-generated room enrichment to each room and writes to enrichment structure.
    """
    room_data = db.reference(f"/poi_state/{region}/{poi_id}/rooms").get() or {}
    enrichment_ref = db.reference(f"/poi_state/{region}/{poi_id}/enrichment/{floor_id}")

    for room_id, enrich in room_data.items():
        enrichment_ref.child(room_id).set({
            "objects": enrich.get("objects", []),
            "npcs": enrich.get("npcs", []),
            "monsters": enrich.get("monsters", [])
        })

def filter_approved_items(items, tag_context=None):
    """
    Filters a list of GPT-generated items based on an approved whitelist.
    Optionally uses a biome or tile context (e.g., swamp → spores).
    """
    approved = db.reference("/rules/approved_items").get() or {}
    context_tags = tag_context or []

    valid_items = []
    for item in items:
        name = item.lower()
        if name in approved:
            if not context_tags or any(tag in approved[name].get("tags", []) for tag in context_tags):
                valid_items.append(item)

    return valid_items
