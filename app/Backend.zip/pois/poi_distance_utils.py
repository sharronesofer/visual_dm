
#This utility module determines player location and POI proximity, enabling proximity-aware logic for quests, encounters, and region-based systems. It supports fast spatial bucketing and region relevance checks.
#It integrates directly with region, poi, quest, and player systems.

from firebase_admin import db
from typing import Tuple, Dict

def get_character_location(character_id: str) -> Tuple[str, str]:
    char_data = db.reference(f"/players/{character_id}").get()
    if not char_data:
        return "unknown_region", "0_0"
    return char_data.get("region_id", "unknown_region"), char_data.get("location", "0_0")

def calculate_distance(poi1: str, poi2: str) -> int:
    try:
        x1, y1 = map(int, poi1.split("_"))
        x2, y2 = map(int, poi2.split("_"))
        return abs(x1 - x2) + abs(y1 - y2)
    except:
        return 999

def bucket_pois_by_proximity(character_id: str, close_range: int = 4) -> Dict[str, list]:
    region, location = get_character_location(character_id)
    region_data = db.reference(f"/poi_state/{region}").get() or {}

    close, far = [], []
    for poi_id, data in region_data.items():
        if not data.get("POI"):
            continue
        dist = calculate_distance(location, poi_id)
        if dist <= close_range:
            close.append(data.get("name", poi_id))
        else:
            far.append(data.get("name", poi_id))

    return {"region": region, "close": close, "far": far}
