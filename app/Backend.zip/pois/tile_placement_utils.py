
#This utility module places GPT-generated enrichment elements (objects, monsters) into tile-level POI room data. It filters unsafe/unapproved content and populates room tiles procedurally.
#It serves the poi, map, combat, and asset systems.

import random
from typing import List, Dict
from app.memory.memory_utils import update_poi_memory
from firebase_admin import db
from app.pois.dungeon_enrichment_utils import filter_approved_items

# Approved object and monster pools
APPROVED_OBJECTS = {
    "altar", "brazier", "cracked statue", "bone pile", "lever", "sealed door",
    "blood smear", "old scroll", "broken weapon", "corpse", "trap plate", "sarcophagus"
}

APPROVED_MONSTERS = {
    "ghost", "cultist", "rat swarm", "echo priest", "revenant", "mimic"
}

def filter_approved_items(items: List[str], approved_set: set) -> List[str]:
    return [i for i in items if i.lower() in approved_set]

def place_enrichment_objects(region: str, poi_id: str, room_list: List[Dict], enrichment_data: Dict) -> List[Dict]:
    """
    Takes a room list and enrichment data from GPT and assigns approved objects/NPCs/monsters to tiles.
    Updates POI memory with significant items based on room type.
    Returns updated room list.
    """
    room_map = {r["id"]: r for r in room_list}

    for room in room_list:
        width, height = room["size"]
        room["tiles"] = [[{"terrain": "floor", "object": None, "monster": None} for _ in range(width)] for _ in range(height)]

    for room_id, enrich in enrichment_data.get("room_enrichment", {}).items():
        room = room_map.get(room_id)
        if not room:
            continue

        width, height = room["size"]
        room_type = room.get("type", None)

        objects = filter_approved_items(enrich.get("objects", []), APPROVED_OBJECTS)
        monsters = filter_approved_items(enrich.get("monsters", []), APPROVED_MONSTERS)

        for obj in objects:
            x, y = random.randint(0, width - 1), random.randint(0, height - 1)
            room["tiles"][y][x]["object"] = obj

            # Tag based on special room type
            obj_tag = None
            if room_type == "boss":
                obj_tag = "boss_item"
            elif room_type == "shrine":
                obj_tag = "ritual_object"
            elif room_type == "safe":
                obj_tag = "rest_site"

            if obj_tag:
                update_poi_memory(region, poi_id, f"Placed special object '{obj}' in room {room_id}", tags=[obj_tag])

        for mon in monsters:
            x, y = random.randint(0, width - 1), random.randint(0, height - 1)
            room["tiles"][y][x]["monster"] = mon

    return room_list