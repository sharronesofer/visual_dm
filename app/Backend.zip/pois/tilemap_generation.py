
#This module handles procedural tilemap generation for Points of Interest (POIs), determining room sizes, counts, and connection graphs. It uses POI metadata (seed and size class) to build deterministic layouts.
#It serves the poi, map, world, and procedural generation systems.

import random
from typing import List, Dict

SIZE_CLASS_RANGES = {
    "tiny": (4, 6),
    "small": (8, 12),
    "medium": (15, 25),
    "large": (30, 50)
}

def get_random_battlefield_size(size_class: str) -> tuple[int, int]:
    min_size, max_size = SIZE_CLASS_RANGES.get(size_class, (10, 15))
    return random.randint(min_size, max_size), random.randint(min_size, max_size)

def generate_tilemap_from_seed(poi_meta: dict) -> List[Dict]:
    """
    Generates a list of room dicts representing the structure of a POI.
    """
    random.seed(poi_meta["map_seed"])
    size_class = poi_meta.get("size_class", "small")
    num_rooms = {
        "tiny": random.randint(3, 5),
        "small": random.randint(6, 10),
        "medium": random.randint(10, 15),
        "large": random.randint(16, 25)
    }.get(size_class, 8)

    rooms = []
    for i in range(num_rooms):
        room_id = f"R{i+1}"
        width = random.randint(4, 10)
        height = random.randint(4, 10)
        room = {
            "id": room_id,
            "size": [width, height],
            "connections": []
        }
        rooms.append(room)

    # connect rooms (simple chain + some branches)
    for i in range(1, len(rooms)):
        prev = rooms[i - 1]
        curr = rooms[i]
        prev["connections"].append(curr["id"])
        curr["connections"].append(prev["id"])
        # random extra connection
        if i > 1 and random.random() < 0.4:
            j = random.randint(0, i - 2)
            curr["connections"].append(rooms[j]["id"])
            rooms[j]["connections"].append(curr["id"])

    return rooms
