
#This Flask route module manages procedural tilemap generation, GPT-driven enrichment, and rendering of POIs (Points of Interest). It handles everything from room generation to object/monster population and final visualization payloads.
#It integrates with poi, gpt, map, world, and narrative systems.

from flask import Blueprint, request, jsonify
from firebase_admin import db
from app.pois.tilemap_generation import generate_tilemap_from_seed
from app.pois.dungeon_enrichment_utils import enrich_poi_structure
from app.pois.tile_placement_utils import place_enrichment_objects

poi_tilemap_bp = Blueprint("poi_tilemap", __name__)

@poi_tilemap_bp.route('/generate_poi_tilemap/<region_name>/<poi_id>', methods=['POST'])
def generate_poi_tilemap(region_name, poi_id):
    ref = db.reference(f"/poi_state/{region_name}/{poi_id}")
    poi_meta = ref.get()

    if not poi_meta:
        return jsonify({"error": "POI not found."}), 404

    tilemap = generate_tilemap_from_seed(poi_meta)

    ref.child("tilemap").child("floor_1").set({"rooms": tilemap})
    return jsonify({"message": "Tilemap generated", "floor": 1, "rooms": tilemap})


@poi_tilemap_bp.route('/enrich_poi_tilemap/<region_name>/<poi_id>', methods=['POST'])
def enrich_poi_tilemap(region_name, poi_id):
    ref = db.reference(f"/poi_state/{region_name}/{poi_id}")
    poi_meta = ref.get()

    if not poi_meta:
        return jsonify({"error": "POI not found."}), 404

    floor_ref = ref.child("tilemap").child("floor_1").child("rooms")
    room_list = floor_ref.get()
    if not room_list:
        return jsonify({"error": "No tilemap to enrich."}), 400

    enrichment = enrich_poi_structure(poi_meta, room_list)
    ref.child("enrichment").child("floor_1").set(enrichment)
    return jsonify({"message": "Enrichment completed", "enrichment": enrichment})


@poi_tilemap_bp.route('/render_poi_tilemap/<region_name>/<poi_id>/<floor>', methods=['GET'])
def render_poi_tilemap(region_name, poi_id, floor):
    ref = db.reference(f"/poi_state/{region_name}/{poi_id}")
    tilemap_data = ref.child("tilemap").child(f"floor_{floor}").child("rooms").get()
    enrichment_data = ref.child("enrichment").child(f"floor_{floor}").get()

    if not tilemap_data:
        return jsonify({"error": "Tilemap not found."}), 404
    if not enrichment_data:
        return jsonify({"error": "Enrichment not found."}), 404

    final_rooms = place_enrichment_objects(tilemap_data, enrichment_data)
    return jsonify({"map": final_rooms})

