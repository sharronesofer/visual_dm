
#This file defines a manual or scheduled daily tick routine that updates multiple systems:
#Shop inventory decay
#NPC motif pressure
#Loyalty drift
#Relationship decay
#Emotional flag cycling
#It integrates directly with npc, shop, motif, relationship, and emotion systems.


from firebase_admin import db
from datetime import datetime
from app.equipment.shop_utils import tick_shop_inventory
from app.npc.npc_loyalty_class import LoyaltyManager
from app.npc.npc_relationships_utils import run_daily_relationship_tick
from app.motifs.motif_engine_class import MotifEngine
from app.npc.npc_relationships_utils import EMOTION_POOL  # Assuming defined
import random
from app.equipment.shop_utils import restock_shop_inventory
from app.factions.war_utils import recover_damaged_pois
from app.npc.npc_travel_utils import simulate_npc_travel, apply_war_pressure_modifiers
from app.npc.npc_loyalty_utils import initialize_faction_opinions
from app.factions.war_utils import generate_daily_raids
from app.visuals.tile_utils import tick_tile_danger
from app.npc.npc_rumor_utils import distort_rumors_if_needed
from app.npc.npc_rumor_utils import fabricate_false_rumors
from app.regions.tension_utils import decay_region_tension
from app.quests.quest_utils import npc_personal_quest_tick
from app.regions.tension_utils import check_faction_war_triggers
from app.pois.poi_building_utils import npc_reclaim_pois

def tick_all_shops():
    all_npcs = db.reference("/npcs").get() or {}
    count = 0

    for npc_id, npc in all_npcs.items():
        if npc.get("shop_profile"):
            restock_shop_inventory(npc_id)
            count += 1

    print(f"[SHOP TICK] Refreshed {count} shops")

def tick_all_shops():
    shop_root = db.reference("/shops")
    all_shops = shop_root.get() or {}
    for shop_id, shop_data in all_shops.items():
        updated = tick_shop_inventory(shop_data)
        db.reference(f"/shops/{shop_id}/inventory").set(updated["inventory"])

def tick_all_motifs():
    def on_motif_expire(npc_id, motif):
        print(f"[MOTIF EXPIRE] NPC {npc_id} rotated motif {motif['theme']}")
        # Example: You could add memory, flag chaos, etc.

    npcs = db.reference("/npcs").get() or {}
    for npc_id in npcs:
        engine = MotifEngine(npc_id)
        engine.tick_all(on_expire=on_motif_expire).save()

def tick_all_loyalty():
    npcs = db.reference("/npcs").get() or {}
    for npc_id, npc_data in npcs.items():
        relationships = npc_data.get("relationships", {})
        for player_id in relationships.keys():
            manager = LoyaltyManager(npc_id, player_id)
            updated = manager.tick()
            db.reference(f"/npcs/{npc_id}/relationships/{player_id}").update(updated)

def tick_npc_emotions():
    npcs = db.reference("/npcs").get() or {}
    for npc_id, npc_data in npcs.items():
        entropy = npc_data.get("motif_entropy", {})
        for motif in npc_data.get("core_motifs", []):
            entropy[motif] = min(entropy.get(motif, 0) + 1, 5)
        npc_data["motif_entropy"] = entropy

        flags = npc_data.get("emotional_flags", [])
        new_flags = []
        for flag in flags:
            flag["duration"] -= 1
            if flag["duration"] > 0:
                new_flags.append(flag)

        if len(new_flags) < 3 and random.random() < 0.2:
            emotion = random.choice(EMOTION_POOL)
            intensity = random.randint(1, 5)
            duration = max(1, 6 - intensity)
            new_flags.append({
                "emotion": emotion,
                "intensity": intensity,
                "duration": duration
            })

        npc_data["emotional_flags"] = new_flags
        npc_data["last_motif_tick"] = datetime.utcnow().isoformat()
        db.reference(f"/npcs/{npc_id}").set(npc_data)

def tick_world_day():
    tick_all_shops()
    tick_all_motifs()
    tick_all_loyalty()
    run_daily_relationship_tick()
    tick_npc_emotions()

    poi_root = db.reference("/poi_state").get() or {}

    for region_name in poi_root:
        tick_tile_danger(region_name)
        raid_log = generate_daily_raids(region_name)
        recover_damaged_pois(region_name)
        simulate_npc_travel(region_name)
        apply_war_pressure_modifiers()

    npc_core = db.reference("/npc_core").get() or {}
    for npc_id in npc_core:
        initialize_faction_opinions(npc_id)

    # Add rumor mutation roll
    mutated = distort_rumors_if_needed()
    fakes = fabricate_false_rumors()
    decay_region_tension()
    print(f"[RUMOR MUTATIONS] {len(mutated)} distorted, {len(fakes)} invented. Tension decayed.")

    fakes = fabricate_false_rumors()
    decay_region_tension()
    check_faction_war_triggers()
    npc_personal_quest_tick()

    fakes = fabricate_false_rumors()
    decay_region_tension()
    check_faction_war_triggers()
    npc_personal_quest_tick()
    npc_reclaim_pois()