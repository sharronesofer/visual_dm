"""
This module manages GPT calls, usage tracking, rest adjudication, belief mutation, motif summarization,
intent parsing, and dynamic AI interaction across the simulation.
"""

import openai
import json
import logging
import requests
import re
from firebase_admin import db
from app.utils.gpt_class import GPTClient

def gpt_flavor_identify_effect(item_name, effect):
    """
    Uses GPT to generate immersive text for the reveal of a single magical item effect.
    """
    prompt = (
        f"The magical item '{item_name}' has revealed a new effect: {effect}.\n"
        "Describe what the character experiences or perceives as this effect becomes known. "
        "Use rich, mystical fantasy prose — keep it brief but evocative."
    )

    gpt = GPTClient()
    return gpt.call(
        system_prompt="You are a fantasy narrator describing magical item awakenings.",
        user_prompt=prompt,
        temperature=0.85,
        max_tokens=80
    )

def gpt_flavor_reveal_full_item(item):
    """
    Uses GPT to generate immersive text for when an item is fully identified.
    """
    name = item.get("identified_name", item.get("name", "Unknown Item"))
    effects = item.get("identified_effects", [])
    effect_list = ", ".join(effects) if effects else "mysterious latent properties"

    prompt = (
        f"The item '{name}' has now revealed all its effects: {effect_list}.\n"
        "Describe what the character experiences as this magical unveiling happens. "
        "Make it vivid, mystical, and narrative-driven."
    )

    gpt = GPTClient()
    return gpt.call(
        system_prompt="You are a fantasy narrator describing magical item awakenings.",
        user_prompt=prompt,
        temperature=0.85,
        max_tokens=150
    )

def get_goodwill_label(score):
    if score <= 6:
        return "Loathes"
    elif score <= 12:
        return "Hates"
    elif score < 18:
        return "Dislikes"
    elif score == 24:
        return "Neutral"
    elif score <= 30:
        return "Likes"
    elif score <= 36:
        return "Loves"
    return "Adores"

# app/utils/gpt_utils.py

def log_usage(model_name: str, usage: dict):
    if usage:
        logging.info(
            f"[GPT USAGE] model={model_name} | "
            f"prompt={usage.get('prompt_tokens')} | "
            f"completion={usage.get('completion_tokens')} | "
            f"total={usage.get('total_tokens')}"
        )
    else:
        logging.info(f"[GPT USAGE] model={model_name} | no usage data provided.")
