import os
import json
import logging

PROJECT_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../"))
RULES_PATH = os.path.join(PROJECT_ROOT, "rules_json")

def load_json(filename_or_path, use_rules_path=True):
    """
    Loads a JSON file.
    If use_rules_path is True, loads from rules_json/ folder.
    Otherwise, uses the given full path.
    """
    if use_rules_path:
        path = os.path.join(RULES_PATH, filename_or_path)
    else:
        path = filename_or_path

    print(f"📂 Loading from path: {path}")
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        logging.error(f"Error loading JSON from {path}: {e}")
        return {}
