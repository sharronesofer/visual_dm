import json
import shutil
from collections import defaultdict

TASKS_PATH = 'tasks/tasks.json'
DONE_PATH = 'tasks/done_tasks.json'
TASKS_BAK = 'tasks/tasks.json.bak'
DONE_BAK = 'tasks/done_tasks.json.bak'

def load_json(path):
    with open(path, 'r') as f:
        return json.load(f)

def save_json(path, data):
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)

def backup_file(src, dst):
    shutil.copy2(src, dst)

def index_tasks(tasks):
    """Return a dict of id -> task for fast lookup."""
    return {str(task['id']): task for task in tasks}

def is_done(task):
    if task.get('status') == 'done':
        return True
    # Check subtasks
    for sub in task.get('subtasks', []):
        if sub.get('status') == 'done':
            return True
    return False

def move_done_tasks():
    # Backup files
    backup_file(TASKS_PATH, TASKS_BAK)
    backup_file(DONE_PATH, DONE_BAK)

    # Load files
    with open(TASKS_PATH) as f:
        tasks_data = json.load(f)
    with open(DONE_PATH) as f:
        done_data = json.load(f)

    tasks = tasks_data.get('tasks', [])
    done_tasks = done_data.get('tasks', [])

    # Index done tasks by id for deduplication
    done_index = index_tasks(done_tasks)
    moved = []
    kept = []

    for task in tasks:
        if task.get('status') == 'done':
            # Move whole task
            done_index[str(task['id'])] = task
            moved.append(task)
        else:
            # Remove done subtasks
            subtasks = task.get('subtasks', [])
            new_subtasks = [sub for sub in subtasks if sub.get('status') != 'done']
            if len(new_subtasks) != len(subtasks):
                # Some subtasks were removed, move them
                for sub in subtasks:
                    if sub.get('status') == 'done':
                        # Wrap subtask as a top-level task for legacy file
                        sub_copy = dict(sub)
                        sub_copy['parentTaskId'] = task['id']
                        done_index[f"{task['id']}.{sub['id']}"] = sub_copy
                        moved.append(sub_copy)
            # Keep the task if it or its subtasks are not done
            task['subtasks'] = new_subtasks
            kept.append(task)

    # Write updated files
    save_json(TASKS_PATH, {'tasks': kept})
    save_json(DONE_PATH, {'tasks': list(done_index.values())})

    print(f"Moved {len(moved)} tasks/subtasks to done_tasks.json.")
    print(f"tasks.json now has {len(kept)} tasks.")
    print(f"done_tasks.json now has {len(done_index)} tasks.")

if __name__ == '__main__':
    move_done_tasks() 