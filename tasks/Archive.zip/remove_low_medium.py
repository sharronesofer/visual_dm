import json
import os
from pathlib import Path
import shutil

def process_task(task):
    """Process a task and its subtasks, returning None if it should be removed."""
    # Check if this is a task-like object
    if not isinstance(task, dict):
        return task
        
    priority = task.get('priority', '').lower()
    
    # If task is low or medium priority, remove it and all its subtasks
    if priority in ['low', 'medium']:
        return None
        
    # If task has subtasks, process them
    if 'subtasks' in task and isinstance(task['subtasks'], list):
        filtered_subtasks = []
        for subtask in task['subtasks']:
            processed_subtask = process_task(subtask)
            if processed_subtask is not None:
                filtered_subtasks.append(processed_subtask)
        task['subtasks'] = filtered_subtasks
        
    return task

def remove_low_medium_tasks():
    # File paths
    current_dir = Path(__file__).parent
    tasks_file = current_dir / 'tasks.json'
    backup_file = current_dir / 'tasks.json.bak'
    
    # Create backup if it doesn't exist
    if not backup_file.exists():
        shutil.copy(tasks_file, backup_file)
        print(f"Created backup at: {backup_file}")
    
    try:
        # Read tasks
        print("Reading tasks.json...")
        with open(tasks_file, 'r') as f:
            data = json.load(f)
            
        # Process tasks
        if isinstance(data, dict) and 'tasks' in data:
            tasks = data['tasks']
            original_count = len(tasks)
            filtered_tasks = []
            
            for task in tasks:
                processed_task = process_task(task)
                if processed_task is not None:
                    filtered_tasks.append(processed_task)
                    
            remaining_count = len(filtered_tasks)
            removed_count = original_count - remaining_count
            
            # Update the tasks list while preserving the structure
            data['tasks'] = filtered_tasks
            
            # Write filtered tasks back to file
            with open(tasks_file, 'w') as f:
                json.dump(data, f, indent=2)
                
            print(f"Original tasks: {original_count}")
            print(f"Tasks removed: {removed_count}")
            print(f"Tasks remaining: {remaining_count}")
            
        else:
            print("Error: tasks.json does not have the expected structure")
            
    except Exception as e:
        print(f"Error processing tasks: {str(e)}")
        # Restore from backup if something went wrong
        if backup_file.exists():
            shutil.copy(backup_file, tasks_file)
            print("Restored from backup due to error")

if __name__ == '__main__':
    remove_low_medium_tasks() 