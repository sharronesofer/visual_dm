import json
from pathlib import Path

def recover_tasks():
    current_dir = Path(__file__).parent
    source_file = current_dir / 'tasks_next.json'
    
    try:
        # Read the tasks_next.json file
        with open(source_file, 'r') as f:
            tasks = json.load(f)
        
        # Recreate each task file
        for task in tasks:
            task_id = task.get('id')
            if not task_id:
                continue
                
            task_file = current_dir / f'task_{task_id.zfill(3)}.txt'
            
            # Create task file content
            content = [
                f"Task ID: {task_id}",
                f"Title: {task.get('title', '')}",
                f"Priority: {task.get('priority', '')}",
                f"Status: {task.get('status', '')}",
                f"Description: {task.get('description', '')}"
            ]
            
            # Write the task file
            with open(task_file, 'w') as f:
                f.write('\n\n'.join(content))
            print(f"Recovered: {task_file.name}")
            
        print(f"\nRecovery Summary:")
        print(f"- Recovered {len(tasks)} task files from {source_file}")
        
    except Exception as e:
        print(f"Error during recovery: {str(e)}")

if __name__ == '__main__':
    recover_tasks() 