import json
from pathlib import Path
import shutil

def filter_tasks_json():
    current_dir = Path(__file__).parent
    tasks_file = current_dir / 'tasks.json'
    backup_file = current_dir / 'tasks.json.backup'
    
    try:
        # Create a backup first
        shutil.copy(tasks_file, backup_file)
        print(f"Created backup at: {backup_file}")
        
        # Read the tasks.json file
        with open(tasks_file, 'r') as f:
            tasks = json.load(f)
        
        # Debug: Print structure
        print("\nDebug: Task structure example:")
        if isinstance(tasks, list) and len(tasks) > 0:
            print(f"First task type: {type(tasks[0])}")
            print(f"First task content: {tasks[0]}")
        else:
            print(f"Tasks type: {type(tasks)}")
            print(f"Tasks content: {tasks}")
            
        # Filter based on structure
        if isinstance(tasks, list):
            original_count = len(tasks)
            # Try different ways to check priority
            high_priority_tasks = []
            for task in tasks:
                priority = None
                if isinstance(task, dict):
                    priority = task.get('priority', '')
                elif isinstance(task, str):
                    # Try to parse JSON string if needed
                    try:
                        task_dict = json.loads(task)
                        priority = task_dict.get('priority', '')
                    except Exception:  # autofix: specify exception
                        print("Exception occurred")  # autofix: handle error
                
                if not priority or priority.lower() not in ['low', 'medium']:
                    high_priority_tasks.append(task)
            
            # Write back to tasks.json
            with open(tasks_file, 'w') as f:
                json.dump(high_priority_tasks, f, indent=2)
            
            print(f"\nSummary:")
            print(f"- Original task count: {original_count}")
            print(f"- Removed tasks: {original_count - len(high_priority_tasks)}")
            print(f"- Remaining high priority tasks: {len(high_priority_tasks)}")
        else:
            print("Error: Tasks data is not in the expected format")
            # Restore backup
            shutil.copy(backup_file, tasks_file)
            print("Restored from backup due to unexpected format")
        
    except FileNotFoundError:
        print(f"Error: Could not find {tasks_file}")
    except Exception as e:
        print(f"Error: {str(e)}")
        # Try to restore from backup if something went wrong
        if backup_file.exists():
            shutil.copy(backup_file, tasks_file)
            print(f"Restored from backup due to error")

if __name__ == '__main__':
    filter_tasks_json() 