import requests

def post_character_to_backend(character_data):
    try:
        res = requests.post("http://localhost:5050/character/create", json=character_data)
        return res.status_code == 200
    except Exception as e:
        print(f"Error posting character: {e}")
        return False
