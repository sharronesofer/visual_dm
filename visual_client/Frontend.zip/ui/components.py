
import pygame

class Button:
    def __init__(self, rect, text, callback, font, bg_color=(70, 70, 70), text_color=(255, 255, 255)):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.callback = callback
        self.font = font
        self.bg_color = bg_color
        self.text_color = text_color
        self.hovered = False

    def draw(self, surface):
        color = self.bg_color if not self.hovered else (min(self.bg_color[0]+30,255), min(self.bg_color[1]+30,255), min(self.bg_color[2]+30,255))
        pygame.draw.rect(surface, color, self.rect)
        text_surf = self.font.render(self.text, True, self.text_color)
        text_rect = text_surf.get_rect(center=self.rect.center)
        surface.blit(text_surf, text_rect)

    def handle_event(self, event):
        if event.type == pygame.MOUSEMOTION:
            self.hovered = self.rect.collidepoint(event.pos)
        elif event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.callback()

class Dropdown:
    def __init__(self, rect, options, font, callback, bg_color=(70, 70, 70), text_color=(255, 255, 255)):
        self.rect = pygame.Rect(rect)
        self.options = options
        self.font = font
        self.callback = callback
        self.bg_color = bg_color
        self.text_color = text_color
        self.active = False
        self.selected = options[0] if options else ""

    def draw(self, surface):
        pygame.draw.rect(surface, self.bg_color, self.rect)
        text_surf = self.font.render(self.selected, True, self.text_color)
        surface.blit(text_surf, self.rect.topleft)
        if self.active:
            for i, option in enumerate(self.options):
                option_rect = pygame.Rect(self.rect.x, self.rect.y + (i+1)*self.rect.height, self.rect.width, self.rect.height)
                pygame.draw.rect(surface, self.bg_color, option_rect)
                option_surf = self.font.render(option, True, self.text_color)
                surface.blit(option_surf, option_rect.topleft)

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.rect.collidepoint(event.pos):
                self.active = not self.active
            elif self.active:
                for i, option in enumerate(self.options):
                    option_rect = pygame.Rect(self.rect.x, self.rect.y + (i+1)*self.rect.height, self.rect.width, self.rect.height)
                    if option_rect.collidepoint(event.pos):
                        self.selected = option
                        self.callback(option)
                        self.active = False
                        return
                self.active = False

class Tooltip:
    def __init__(self, font, bg_color=(50, 50, 50), text_color=(255, 255, 255), wrap_width=200):
        self.font = font
        self.bg_color = bg_color
        self.text_color = text_color
        self.text_lines = []
        self.visible = False
        self.position = (0, 0)
        self.wrap_width = wrap_width

    def set_text(self, text, position):
        self.position = position
        self.text_lines = self.wrap_text(text)
        self.visible = True

    def wrap_text(self, text):
        words = text.split(' ')
        lines = []
        current_line = ''
        for word in words:
            test_line = current_line + word + ' '
            if self.font.size(test_line)[0] <= self.wrap_width:
                current_line = test_line
            else:
                lines.append(current_line.strip())
                current_line = word + ' '
        if current_line:
            lines.append(current_line.strip())
        return lines

    def hide(self):
        self.visible = False

    def draw(self, surface):
        if self.visible and self.text_lines:
            max_width = max(self.font.size(line)[0] for line in self.text_lines)
            height = self.font.get_height() * len(self.text_lines)
            background_rect = pygame.Rect(self.position[0], self.position[1], max_width + 10, height + 10)
            pygame.draw.rect(surface, self.bg_color, background_rect)
            for i, line in enumerate(self.text_lines):
                text_surf = self.font.render(line, True, self.text_color)
                surface.blit(text_surf, (self.position[0] + 5, self.position[1] + 5 + i * self.font.get_height()))
