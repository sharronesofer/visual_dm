import pygame

class MultilineTextBox:
    def __init__(self, rect, font, text_color=(255, 255, 255), bg_color=(0, 0, 0), max_lines=5):
        self.rect = pygame.Rect(rect)
        self.font = font
        self.text_color = text_color
        self.bg_color = bg_color
        self.text = ""
        self.active = False
        self.max_lines = max_lines
        self.line_spacing = 5

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)

        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_RETURN:
                self.text += "\n"
            elif event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            else:
                self.text += event.unicode

    def get_text(self):
        return self.text.strip()

    def wrap_text(self):
        words = self.text.split(" ")
        lines = []
        current_line = ""

        for word in words:
            test_line = f"{current_line} {word}".strip()
            if self.font.size(test_line)[0] <= self.rect.width:
                current_line = test_line
            else:
                lines.append(current_line)
                current_line = word
        if current_line:
            lines.append(current_line)

        return lines[-self.max_lines:]

    def draw(self, surface):
        pygame.draw.rect(surface, self.bg_color, self.rect)
        pygame.draw.rect(surface, (255, 255, 255), self.rect, 2 if self.active else 1)

        x, y = self.rect.topleft
        line_height = self.font.get_height() + self.line_spacing
        for line in self.wrap_text():
            surface.blit(self.font.render(line, True, self.text_color), (x + 5, y + 5))
            y += line_height
