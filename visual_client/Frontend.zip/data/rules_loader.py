import os
import json

BASE_PATH = "/Users/Sharrone/visual_dm/rules_json"

def load_json_file(filename):
    path = os.path.join(BASE_PATH, filename)
    if not os.path.isfile(path):
        print(f"Warning: File not found: {path}")
        return {}
    with open(path, "r") as f:
        return json.load(f)

def extract_named_pairs(data):
    if isinstance(data, dict):
        return [(name, info.get("description", "")) for name, info in data.items()]
    elif isinstance(data, list):
        return [(entry.get("name", "Unnamed"), entry.get("description", "")) for entry in data]
    else:
        return []

def get_races():
    return extract_named_pairs(load_json_file("races.json"))

def get_feats():
    return extract_named_pairs(load_json_file("feats.json"))

def get_skills():
    return extract_named_pairs(load_json_file("skills.json"))

def get_backgrounds():
    return extract_named_pairs(load_json_file("backgrounds.json"))

def get_kits():
    return extract_named_pairs(load_json_file("starter_kits.json"))

