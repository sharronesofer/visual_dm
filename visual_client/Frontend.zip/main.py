import pygame
import visual_client                    # activates the requests-timeout patch

from visual_client.screens.main_menu import MainMenuScreen
from visual_client.screens.pause_menu import PauseMenu

# You can add other screens here if you wire them in later:
from visual_client.screens.character_browser import CharacterBrowser
from visual_client.screens.start_game import StartGameScreen
from visual_client.screens.region_map_screen import RegionMapScreen
from visual_client.screens.combat_screen import CombatScreen
from visual_client.screens.journal_screen import JournalScreen
from visual_client.screens.world_inspector_panel import WorldInspectorPanel


def main() -> None:
    pygame.init()
    screen = pygame.display.set_mode((1024, 760))
    pygame.display.set_caption("Visual DM 6")

    clock          = pygame.time.Clock()
    running        = True
    current_screen = MainMenuScreen(screen)

    while running:
        # ---------- event handling -------------------------------------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                break

            # Global ESC → pause
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                if not isinstance(current_screen, MainMenuScreen):
                    pause = PauseMenu(screen)
                    choice = pause.run()
                    if choice == "Save and Exit":
                        running = False
                    elif choice == "Quit to Main Menu":
                        current_screen = MainMenuScreen(screen)
                continue  # skip sending ESC to the underlying screen

            # Delegate other events
            if hasattr(current_screen, "handle_event"):
                result = current_screen.handle_event(event)
                if result:
                    if hasattr(current_screen, "run_selection"):
                        current_screen.run_selection(result)

        # ---------- screen update / draw -------------------------------
        if hasattr(current_screen, "update"):
            current_screen.update()

        if hasattr(current_screen, "draw"):
            current_screen.draw()

        # ---------- screen switching -----------------------------------
        # MainMenuScreen triggers changes via .next_screen
        if getattr(current_screen, "next_screen", None):
            print(f"🔄 Switching to {current_screen.next_screen.__class__.__name__}")
            current_screen = current_screen.next_screen

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()


if __name__ == "__main__":
    main()
