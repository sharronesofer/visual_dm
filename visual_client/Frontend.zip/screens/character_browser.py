import pygame
import requests

from visual_client.screens.start_game import StartGameScreen

class CharacterBrowser:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 28)
        self.large_font = pygame.font.SysFont(None, 36)
        self.characters = []
        self.selected = 0
        self.load_characters()
        self.next_screen = None

    def load_characters(self):
        try:
            res = requests.get("http://localhost:5050/character/all")
            if res.status_code == 200:
                self.characters = res.json()
                print("✅ Loaded characters:", self.characters)
            else:
                print("❌ Failed to load characters")
        except Exception as e:
            print("❌ Error loading characters:", e)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                self.selected = (self.selected + 1) % len(self.characters)
            elif event.key == pygame.K_UP:
                self.selected = (self.selected - 1) % len(self.characters)
            elif event.key == pygame.K_RETURN and self.characters:
                char_id = self.characters[self.selected]["character_id"]
                char_data = requests.get(f"http://localhost:5050/character/{char_id}").json()
                self.next_screen = StartGameScreen(self.screen, char_data)
            elif event.key == pygame.K_DELETE and self.characters:
                char_id = self.characters[self.selected]["character_id"]
                self.delete_character(char_id)
            elif event.key == pygame.K_ESCAPE:
                self.next_screen = None  # Signal to go back to menu

    def delete_character(self, char_id):
        try:
            res = requests.delete(f"http://localhost:5050/character/delete/{char_id}")
            if res.status_code == 200:
                print(f"✅ Character {char_id} deleted.")
                self.load_characters()
                self.selected = 0
            else:
                print("❌ Failed to delete character")
        except Exception as e:
            print("❌ Error deleting character:", e)

    def update(self):
        pass

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.large_font.render("Character Browser", True, (255, 255, 0)), (60, 40))

        y = 100
        if not self.characters:
            self.screen.blit(self.font.render("No characters found.", True, (200, 200, 200)), (80, y))
        else:
            for i, char in enumerate(self.characters):
                name = f"{char['character_name']} ({char.get('race', '?')})"
                color = (255, 255, 255) if i != self.selected else (0, 255, 100)
                text = self.font.render(name, True, color)
                self.screen.blit(text, (80, y))
                y += 40

        pygame.display.flip()
