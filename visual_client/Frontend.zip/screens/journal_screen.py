import pygame
import requests

class JournalScreen:
    def __init__(self, screen, character_id, region_id):
        self.screen = screen
        self.character_id = character_id
        self.region_id = region_id
        self.font = pygame.font.SysFont(None, 24)
        self.large_font = pygame.font.SysFont(None, 32)

        self.tabs = ["Quests", "Rumors", "Notes"]
        self.selected_tab = 0
        self.data = {"Quests": [], "Rumors": [], "Notes": []}

        self.new_note = ""
        self.new_note_active = False

        self.load_data()

    def load_data(self):
        try:
            q = requests.get(f"http://localhost:5050/quests/{self.character_id}")
            if q.status_code == 200:
                self.data["Quests"] = q.json()
        except Exception as e:
            print("❌ Error loading quests:", e)

        try:
            r = requests.get(f"http://localhost:5050/rumors/{self.region_id}")
            if r.status_code == 200:
                self.data["Rumors"] = r.json()
        except Exception as e:
            print("❌ Error loading rumors:", e)

        try:
            n = requests.get(f"http://localhost:5050/notes/{self.character_id}")
            if n.status_code == 200:
                self.data["Notes"] = n.json()
        except Exception as e:
            print("❌ Error loading notes:", e)

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RIGHT:
                self.selected_tab = (self.selected_tab + 1) % len(self.tabs)
            elif event.key == pygame.K_LEFT:
                self.selected_tab = (self.selected_tab - 1) % len(self.tabs)
            elif self.new_note_active:
                if event.key == pygame.K_RETURN:
                    self.save_new_note()
                elif event.key == pygame.K_BACKSPACE:
                    self.new_note = self.new_note[:-1]
                else:
                    self.new_note += event.unicode
            elif event.key == pygame.K_n and self.tabs[self.selected_tab] == "Notes":
                self.new_note_active = True
                self.new_note = ""

    def save_new_note(self):
        try:
            res = requests.post(f"http://localhost:5050/notes/{self.character_id}", json={"note": self.new_note})
            if res.status_code == 200:
                print("✅ Note saved.")
                self.load_data()
            else:
                print("❌ Failed to save note")
        except Exception as e:
            print("❌ Error saving note:", e)
        self.new_note_active = False
        self.new_note = ""

    def update(self):
        pass

    def draw(self):
        self.screen.fill((0, 0, 0))

        # Draw Tabs
        x = 100
        for i, tab in enumerate(self.tabs):
            color = (255, 255, 0) if i == self.selected_tab else (200, 200, 200)
            label = self.large_font.render(tab, True, color)
            self.screen.blit(label, (x, 20))
            x += 200

        # Draw Current Tab Content
        tab_name = self.tabs[self.selected_tab]
        entries = self.data.get(tab_name, [])

        y = 100
        if not entries:
            self.screen.blit(self.font.render(f"No {tab_name.lower()} found.", True, (150, 150, 150)), (100, y))
        else:
            for entry in entries:
                line = entry if isinstance(entry, str) else str(entry)
                rendered = self.font.render(line, True, (180, 220, 180))
                self.screen.blit(rendered, (100, y))
                y += 30

        # If adding a new note
        if self.new_note_active:
            self.screen.blit(self.font.render("New Note (Enter to Save):", True, (255, 255, 0)), (100, 550))
            note_surface = self.font.render(self.new_note, True, (255, 255, 255))
            self.screen.blit(note_surface, (100, 580))

        pygame.display.flip()
