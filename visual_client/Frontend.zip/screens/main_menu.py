import pygame
import requests
from uuid import uuid4
import uuid
from visual_client.screens.character_creation import CharacterCreationScreen
from visual_client.screens.load_character import LoadCharacterMenu
from visual_client.screens.start_game import StartGameScreen

class MainMenuScreen:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 36)
        self.options = ["New Character", "Load Character", "Test Character", "Exit"]
        self.selected_option = 0
        self.next_screen = None

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_UP:
                self.selected_option = (self.selected_option - 1) % len(self.options)
            elif event.key == pygame.K_DOWN:
                self.selected_option = (self.selected_option + 1) % len(self.options)
            elif event.key == pygame.K_RETURN:
                self.activate_selected_option()

        elif event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            y = 200
            for i, option in enumerate(self.options):
                rect = pygame.Rect(320, y, 300, 40)
                if rect.collidepoint(mouse_pos):
                    self.selected_option = i
                    self.activate_selected_option()
                y += 50

    def activate_selected_option(self):
        choice = self.options[self.selected_option]
        if choice == "New Character":
            from visual_client.screens.character_creation import CharacterCreationScreen
            self.next_screen = CharacterCreationScreen(self.screen)
        elif choice == "Load Character":
            from visual_client.screens.load_character import LoadCharacterMenu
            self.next_screen = LoadCharacterMenu(self.screen)
        elif choice == "Test Character":
            from visual_client.screens.start_game import StartGameScreen
            from app.characters.character_utils import generate_fake_character
            fake_char = generate_fake_character()
            self.next_screen = StartGameScreen(self.screen, fake_char)
        elif choice == "Exit":
            pygame.quit()
            exit()

    def draw(self):
        self.screen.fill((0, 0, 0))
        title = self.font.render("Main Menu", True, (255, 255, 255))
        self.screen.blit(title, (320, 100))
        y = 200
        for i, option in enumerate(self.options):
            color = (255, 255, 0) if i == self.selected_option else (200, 200, 200)
            text = self.font.render(option, True, color)
            self.screen.blit(text, (320, y))
            y += 50
        pygame.display.flip()

    def update(self):
        pass

    def run_selection(self, choice):
        if choice == "New Character":
            self.next_screen = CharacterCreationScreen(self.screen)
        elif choice == "Load Character":
            selector = LoadCharacterMenu(self.screen)
            while True:
                for event in pygame.event.get():
                    selected = selector.handle_event(event)
                    if selected == "menu":
                        return
                    elif selected:
                        char_data = requests.get(f"http://localhost:5050/character/{selected}").json()
                        self.next_screen = StartGameScreen(self.screen, char_data)
                        return
                selector.update()
                selector.draw()
                pygame.display.flip()
        elif choice == "Test Character":
            fake_data = {
                "character_id": f"test_{uuid.uuid4().hex[:8]}",
                "character_name": "Testy McTestface",
                "race": "Human",
                "gender": "Nonbinary",
                "age": "Adult",
                "alignment": "True Neutral",
                "region_id": "capital_hub",
                "attributes": {
                    "STR": 12, "DEX": 12, "CON": 12,
                    "INT": 12, "WIS": 12, "CHA": 12
                },
                "skills": {
                    "Athletics": 3, "Divine": 2, "Occult": 1,
                    "Stealth": 0, "Insight": 1, "Perform": 0
                },
                "feats": ["War Priest", "Turn Undead"],
                "background": "Raised in a holy order, Testy seeks wisdom beyond the monastery walls.",
                "kit": "Standard Cleric Gear",
                "portrait_url": ""
            }
            self.next_screen = StartGameScreen(self.screen, fake_data)
        elif choice == "Exit":
            pygame.quit()
            exit()
