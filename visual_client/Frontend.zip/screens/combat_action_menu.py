import pygame

class CombatActionMenu:
    def __init__(self, screen, actions_enabled=None):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 24)

        self.actions = ["Attack", "Cast", "Skill", "Item"]
        self.actions_enabled = actions_enabled or {a: True for a in self.actions}

        self.button_rects = {}
        self.selected_action = None

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_pos = event.pos
            for action, rect in self.button_rects.items():
                if rect.collidepoint(mouse_pos):
                    if self.actions_enabled.get(action, False):
                        self.selected_action = action
                        print(f"✅ Action selected: {action}")
                        return action  # Return action name
        return None

    def set_enabled_actions(self, enabled_dict):
        """ Update which actions are enabled or disabled. """
        self.actions_enabled = enabled_dict

    def update(self):
        pass

    def draw(self):
        panel_y = 620
        panel_height = 140
        pygame.draw.rect(self.screen, (20, 20, 20), (0, panel_y, 1024, panel_height))

        button_width = 200
        button_height = 50
        spacing = 40
        x = 100

        self.button_rects = {}

        for action in self.actions:
            enabled = self.actions_enabled.get(action, False)
            color = (0, 200, 100) if enabled else (100, 100, 100)
            rect = pygame.Rect(x, panel_y + 40, button_width, button_height)
            pygame.draw.rect(self.screen, color, rect)
            label = self.font.render(action, True, (0, 0, 0))
            self.screen.blit(label, (rect.x + 20, rect.y + 10))

            self.button_rects[action] = rect
            x += button_width + spacing

        pygame.display.flip()
