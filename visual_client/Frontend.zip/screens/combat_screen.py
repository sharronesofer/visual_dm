import pygame
import requests
import math
import random

from visual_client.screens.combat_action_menu import CombatActionMenu

class CombatScreen:
    def __init__(self, screen, character_data):
        self.screen = screen
        self.character_data = character_data
        self.font = pygame.font.SysFont(None, 24)

        self.grid_radius = 5
        self.tile_size = 40
        self.tiles = []
        self.build_hex_grid()

        self.player_pos = (0, 0)
        self.enemy_pos = (2, -2)

        self.turn = "player"  # or "enemy"
        self.combat_over = False
        self.result_text = ""
        self.next_screen = None

        # Action menu
        self.action_menu = CombatActionMenu(self.screen)
        self.available_actions = {
            "Attack": True,
            "Cast": False,
            "Skill": True,
            "Item": False
        }

    def build_hex_grid(self):
        self.tiles = []
        for q in range(-self.grid_radius, self.grid_radius + 1):
            for r in range(-self.grid_radius, self.grid_radius + 1):
                if -q - r >= -self.grid_radius and -q - r <= self.grid_radius:
                    self.tiles.append((q, r))

    def handle_event(self, event):
        if self.combat_over:
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.next_screen = None
            return

        if self.turn == "player":
            action = self.action_menu.handle_event(event)
            if action:
                self.process_player_action(action)

    def process_player_action(self, action):
        print(f"🎯 Player selected {action}")
        # Dummy POST to backend combat system
        try:
            res = requests.post("http://localhost:5050/combat/turn", json={
                "encounter_id": "placeholder_encounter",  # replace with real
                "action": action
            })
            if res.status_code == 200:
                print("✅ Action processed.")
            else:
                print("❌ Action backend error")
        except Exception as e:
            print("❌ Error during action POST:", e)

        # Advance turn
        if action == "Attack":
            # Simple attack logic: if adjacent enemy, win
            if self.distance(self.player_pos, self.enemy_pos) <= 1:
                self.result_text = "Victory! Enemy Defeated!"
                self.combat_over = True
            else:
                self.turn = "enemy"

        elif action == "Skill":
            # Skill works like attack here
            self.turn = "enemy"

        elif action == "Cast":
            self.turn = "enemy"

        elif action == "Item":
            self.turn = "enemy"

    def distance(self, pos1, pos2):
        q1, r1 = pos1
        q2, r2 = pos2
        return max(abs(q1 - q2), abs(r1 - r2), abs((-q1 - r1) - (-q2 - r2)))

    def update(self):
        if self.combat_over:
            return

        if self.turn == "enemy":
            eq, er = self.enemy_pos
            pq, pr = self.player_pos

            # Move enemy toward player
            if eq < pq: eq += 1
            elif eq > pq: eq -= 1
            if er < pr: er += 1
            elif er > pr: er -= 1

            self.enemy_pos = (eq, er)

            if self.enemy_pos == self.player_pos:
                self.result_text = "You have been defeated!"
                self.combat_over = True
            else:
                self.turn = "player"

    def hex_to_pixel(self, q, r):
        x = self.tile_size * (3/2 * q)
        y = self.tile_size * (math.sqrt(3) * (r + q/2))
        return int(x + 400), int(y + 300)

    def draw_hex(self, q, r):
        center = self.hex_to_pixel(q, r)
        points = []
        for i in range(6):
            angle_deg = 60 * i
            angle_rad = math.radians(angle_deg)
            x = center[0] + self.tile_size * 0.9 * math.cos(angle_rad)
            y = center[1] + self.tile_size * 0.9 * math.sin(angle_rad)
            points.append((x, y))
        pygame.draw.polygon(self.screen, (80, 80, 80), points, 1)

    def draw(self):
        self.screen.fill((0, 0, 0))

        # Draw hex grid
        for q, r in self.tiles:
            self.draw_hex(q, r)

        # Draw player
        px, py = self.hex_to_pixel(*self.player_pos)
        pygame.draw.circle(self.screen, (0, 255, 0), (px, py), 12)

        # Draw enemy
        ex, ey = self.hex_to_pixel(*self.enemy_pos)
        pygame.draw.circle(self.screen, (255, 0, 0), (ex, ey), 12)

        if self.combat_over:
            result_surface = self.font.render(self.result_text, True, (255, 255, 0))
            self.screen.blit(result_surface, (300, 550))
            back_surface = self.font.render("Press ESC to return", True, (200, 200, 200))
            self.screen.blit(back_surface, (280, 580))

        # Draw action menu
        if not self.combat_over:
            self.action_menu.set_enabled_actions(self.available_actions)
            self.action_menu.draw()

        pygame.display.flip()
