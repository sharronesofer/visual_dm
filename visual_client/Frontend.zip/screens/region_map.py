
import pygame
import requests

class RegionMapScreen:
    def __init__(self, screen, region_id, character_id):
        self.screen = screen
        self.region_id = region_id
        self.character_id = character_id
        self.font = pygame.font.SysFont("Courier", 24)
        self.tile_size = 40
        self.tiles = {}
        self.player_pos = (0, 0)
        self.viewport_offset = (0, 0)
        self.load_map_data()

    def load_map_data(self):
        print(f"📡 Fetching region tiles for '{self.region_id}'...")
        res = requests.get(f"http://localhost:5050/region_map/{self.region_id}")
        if res.status_code == 200:
            self.tiles = res.json().get("tiles", {})
            print(f"✅ Loaded {len(self.tiles)} tiles.")
        else:
            print("❌ Failed to load region map data.")

        res = requests.get(f"http://localhost:5050/character/{self.character_id}")
        if res.status_code == 200:
            pos = res.json().get("position", {})
            self.player_pos = (pos.get("x", 0), pos.get("y", 0))
            self.viewport_offset = (self.player_pos[0] - 3, self.player_pos[1] - 3)
            print("🎯 Player starts at:", self.player_pos)
        else:
            print("⚠️ Could not load player position.")

    def handle_event(self, event):
        x, y = self.player_pos
        moved = False
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT: x -= 1; moved = True
            elif event.key == pygame.K_RIGHT: x += 1; moved = True
            elif event.key == pygame.K_UP: y -= 1; moved = True
            elif event.key == pygame.K_DOWN: y += 1; moved = True
        if moved:
            self.player_pos = (x, y)
            vx, vy = self.viewport_offset
            if x - vx < 2: vx = x - 2
            elif x - vx > 4: vx = x - 4
            if y - vy < 2: vy = y - 2
            elif y - vy > 4: vy = y - 4
            self.viewport_offset = (vx, vy)

    def update(self): pass

    def draw(self):
        self.screen.fill((0, 0, 0))
        vx, vy = self.viewport_offset

        terrain_lookup = {
            'grassland': ('🌾', (150, 180, 80)),
            'forest': ('🌲', (50, 100, 50)),
            'riverlands': ('🏜️', (220, 180, 100)),
            'hills': ('💀', (200, 50, 50)),
            'wetlands': ('⛰️', (100, 100, 100)),
            'desert': ('🌊', (60, 100, 200)),
            'tundra': ('🐸', (80, 110, 90)),
            'mountains': ('🔥', (255, 80, 0)),
            'savanna': ('❄️', (160, 220, 255)),
            'jungle': ('💎', (180, 120, 255)),
            'coastal': ('🌌', (100, 0, 200)),
            'volcano': ('⚙️', (180, 180, 180)),
            'cursed_lands': ('🌾', (150, 180, 80)),
            'toxic_swamp': ('🌲', (50, 100, 50)),
            'necrotic_fields': ('🏜️', (220, 180, 100)),
            'haunted_woods': ('💀', (200, 50, 50)),
            'frozen_wastes': ('⛰️', (100, 100, 100)),
            'scorched_plains': ('🌊', (60, 100, 200)),
            'shattered_mountains': ('🐸', (80, 110, 90)),
            'wasteland': ('🔥', (255, 80, 0)),
            'ruins': ('❄️', (160, 220, 255)),
            'arcane_storm': ('💎', (180, 120, 255)),
            'celestial_plateau': ('🌌', (100, 0, 200)),
            'void_rift': ('⚙️', (180, 180, 180)),
            'floating_isles': ('🌾', (150, 180, 80)),
            'crystal_forest': ('🌲', (50, 100, 50)),
            'grave_valley': ('🏜️', (220, 180, 100)),
            'fungal_jungle': ('💀', (200, 50, 50)),
            'sunken_city': ('⛰️', (100, 100, 100)),
            'clockwork_canyon': ('🌊', (60, 100, 200)),
            'obsidian_sea': ('🐸', (80, 110, 90))
        }

        for dx in range(7):
            for dy in range(7):
                x, y = vx + dx, vy + dy
                coord = f"{x}_{y}"
                tile = self.tiles.get(coord, {})
                tags = [t.lower() for t in tile.get("tags", [])]
                color = (40, 40, 40)
                symbol = "."

                for tag in tags:
                    if tag in terrain_lookup:
                        symbol, color = terrain_lookup[tag]
                        break

                if tile.get("poi") and symbol == ".":
                    symbol, color = "❓", (120, 160, 200)

                px, py = dx * self.tile_size, dy * self.tile_size
                pygame.draw.rect(self.screen, color, (px, py, self.tile_size, self.tile_size))
                pygame.draw.rect(self.screen, (80, 80, 80), (px, py, self.tile_size, self.tile_size), 1)

                glyph = self.font.render("🧍" if (x, y) == self.player_pos else symbol, True, (255, 255, 255))
                self.screen.blit(glyph, (px, py))

        # === Footer Info ===
        footer_y = 7 * self.tile_size + 20
        hover_tile = self.tiles.get(f"{self.player_pos[0]}_{self.player_pos[1]}", {})
        terrain_tags = hover_tile.get("tags", [])
        coord_text = f"📍 You are at {self.player_pos[0]}, {self.player_pos[1]}"
        terrain_text = f"🗺 Terrain: {', '.join(terrain_tags).title() if terrain_tags else 'Unknown'}"

        coord_surface = self.font.render(coord_text, True, (255, 255, 255))
        terrain_surface = self.font.render(terrain_text, True, (180, 220, 180))
        self.screen.blit(coord_surface, (40, footer_y))
        self.screen.blit(terrain_surface, (40, footer_y + 30))

        pygame.display.flip()
