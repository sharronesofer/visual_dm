import pygame, requests
from pathlib import Path

# ── constants ──────────────────────────────────────────────────────────────
TIMEOUT      = 5        # seconds for HTTP
VIEW_RADIUS  = 3        # tiles around player kept visible
TILE_SIZE    = 40       # pixels
FONT_PATH    = (Path(__file__).resolve()
                .parents[1] / "assets" / "fonts" / "NotoColorEmoji-Regular.ttf")

# ── helper wrappers ────────────────────────────────────────────────────────
def _safe_get(url):
    try:
        r = requests.get(url, timeout=TIMEOUT)
        r.raise_for_status()
        return r.json()
    except requests.RequestException as exc:
        print(f"❌ GET {url} – {exc}")
        return {}

def _safe_post(url, payload):
    try:
        r = requests.post(url, json=payload, timeout=TIMEOUT)
        r.raise_for_status()
    except requests.RequestException as exc:
        print(f"❌ POST {url} – {exc}")

# ── main class ─────────────────────────────────────────────────────────────
class RegionMapScreen:
    """7×7 tile viewer with arrow-key movement and backend sync."""

    def __init__(self, screen, region_id, character_id):
        self.screen        = screen
        self.region_id     = region_id
        self.character_id  = character_id

        self.font          = pygame.font.Font(str(FONT_PATH), 24)
        self.tile_size     = TILE_SIZE
        self.tiles         = {}
        self.player_pos    = (0, 0)
        self.viewport_off  = (0, 0)
        self.next_screen   = None

        self._load_map_data()

    # ── data fetch ────────────────────────────────────────────────────────
    def _load_map_data(self):
        # tiles
        data      = _safe_get(f"http://localhost:5050/region_map/{self.region_id}")
        self.tiles = data.get("tiles", {})
        print(f"✅ Loaded {len(self.tiles)} tiles for region “{self.region_id}”.")
        # player
        pdata     = _safe_get(f"http://localhost:5050/character/{self.character_id}")
        pos       = pdata.get("position", {})
        self.player_pos   = (pos.get("x", 0), pos.get("y", 0))
        self.viewport_off = (self.player_pos[0] - VIEW_RADIUS,
                             self.player_pos[1] - VIEW_RADIUS)

    # ── input ─────────────────────────────────────────────────────────────
    def handle_event(self, event):
        if event.type != pygame.KEYDOWN:
            return

        x, y = self.player_pos
        if   event.key == pygame.K_LEFT:  x -= 1
        elif event.key == pygame.K_RIGHT: x += 1
        elif event.key == pygame.K_UP:    y -= 1
        elif event.key == pygame.K_DOWN:  y += 1
        else: return

        self.player_pos = (x, y)
        vx, vy          = self.viewport_off
        if x - vx < 2:      vx = x - 2
        elif x - vx > 4:    vx = x - 4
        if y - vy < 2:      vy = y - 2
        elif y - vy > 4:    vy = y - 4
        self.viewport_off = (vx, vy)

        _safe_post("http://localhost:5050/move_player", {
            "character_id": self.character_id,
            "new_location": {"x": x, "y": y}
        })

    # ── game loop hooks ───────────────────────────────────────────────────
    def update(self):
        pass  # future animations

    def draw(self):
        self.screen.fill((0, 0, 0))
        vx, vy = self.viewport_off
        ts     = self.tile_size

        # minimalist palette
        terrain_lookup = {
            "grassland": ("🌾", (150, 180,  80)),
            "forest":    ("🌲", ( 50, 100,  50)),
            "mountains": ("⛰️", (100, 100, 100)),
            "desert":    ("🏜️", (220, 180, 100)),
            "river":     ("🌊", ( 60, 100, 200)),
            "ruins":     ("🏚️", (160, 160, 160)),
        }

        # 7 × 7 visible grid
        for dy in range(7):
            for dx in range(7):
                gx, gy = vx + dx, vy + dy
                tile   = self.tiles.get(f"{gx}_{gy}", {})
                tag    = tile.get("tags", ["unknown"])[0]
                ch, col = terrain_lookup.get(tag, ("?", (80, 80, 80)))

                px, py = 60 + dx*ts, 60 + dy*ts
                pygame.draw.rect(self.screen, col, (px, py, ts, ts))
                self.screen.blit(self.font.render(ch, True, (0, 0, 0)),
                                 (px + 10, py + 6))

        # player highlight
        px = 60 + (self.player_pos[0] - vx) * ts
        py = 60 + (self.player_pos[1] - vy) * ts
        pygame.draw.rect(self.screen, (255, 255, 0), (px, py, ts, ts), 3)

        # footer
        footer_y   = 60 + 7*ts + 20
        hover_tile = self.tiles.get(f"{self.player_pos[0]}_{self.player_pos[1]}", {})
        terr_tags  = hover_tile.get("tags", [])
        self.screen.blit(self.font.render(f"📍 {self.player_pos}", True, (255, 255, 255)),
                         (40, footer_y))
        self.screen.blit(self.font.render(
            "🗺 " + (", ".join(terr_tags).title() or "Unknown"),
            True, (180, 220, 180)), (40, footer_y + 30))

        pygame.display.flip()
