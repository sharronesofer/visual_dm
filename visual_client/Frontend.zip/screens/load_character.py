import pygame
import requests
from visual_client.screens.start_game import StartGameScreen

class LoadCharacterMenu:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 28)
        self.large_font = pygame.font.SysFont(None, 36)
        self.characters = []
        self.selected = 0
        self.next_screen = None
        self.load_characters()
        self.placeholder_image = pygame.image.load("./assets/placeholder_portrait.png")
        self.placeholder_image = pygame.transform.scale(self.placeholder_image, (128, 128))

        # Paging config
        self.items_per_page = 10
        self.start_index = 0

    def load_characters(self):
        try:
            res = requests.get("http://localhost:5050/character/all")
            if res.status_code == 200:
                self.characters = res.json()  # ✅
                print("✅ Loaded characters:", self.characters)
            else:
                print("❌ Failed to load characters")
        except Exception as e:
            print("❌ Error loading characters:", e)

    def handle_event(self, event):
        if not self.characters:
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_DOWN:
                self.selected = (self.selected + 1) % len(self.characters)
                self.adjust_viewport()
            elif event.key == pygame.K_UP:
                self.selected = (self.selected - 1) % len(self.characters)
                self.adjust_viewport()
            elif event.key == pygame.K_RETURN:
                self.activate_selected_character()
                from visual_client.screens.main_menu import MainMenuScreen
            elif event.key == pygame.K_ESCAPE:
                self.next_screen = MainMenuScreen(self.screen)

    def adjust_viewport(self):
        if self.selected < self.start_index:
            self.start_index = self.selected
        elif self.selected >= self.start_index + self.items_per_page:
            self.start_index = self.selected - self.items_per_page + 1

    def activate_selected_character(self):
        selected_character = self.characters[self.selected]
        char_id = selected_character["character_id"]

        try:
            res = requests.get(f"http://localhost:5050/character/{char_id}")
            if res.status_code == 200:
                full_character = res.json()
                self.next_screen = StartGameScreen(self.screen, full_character)
            else:
                print("❌ Failed to load character:", res.status_code)
        except Exception as e:
            print("❌ Error loading character:", e)

    def update(self):
        pass

    def draw(self):
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.large_font.render("Select a Character", True, (255, 255, 0)), (60, 40))

        if not self.characters:
            self.screen.blit(self.font.render("No saved characters.", True, (200, 200, 200)), (80, 120))
            return

        end_index = min(self.start_index + self.items_per_page, len(self.characters))
        y = 120

        for i in range(self.start_index, end_index):
            char = self.characters[i]
            char_name = char.get('character_name', "Unnamed")
            race = char.get('race', "???")
            region = char.get('region_id', "unknown")

            label = f"{char_name} ({race}) [{region}]"
            color = (255, 255, 255) if i != self.selected else (0, 255, 100)

            text = self.font.render(label, True, color)
            self.screen.blit(text, (80, y))
            y += 40

        # 🔥 Draw selected character's portrait on the right
        if self.characters:
            selected_char = self.characters[self.selected]
            portrait_x = 700
            portrait_y = 200

            # Future enhancement: check for selected_char.get('portrait_url')
            # For now, always draw placeholder
            self.screen.blit(self.placeholder_image, (portrait_x, portrait_y))
