import pygame
import requests
from uuid import uuid4
from textwrap import wrap
import uuid
from visual_client.screens.region_map_screen import RegionMapScreen

class StartGameScreen:
    def __init__(self, screen, character_data):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 24)
        self.large_font = pygame.font.SysFont(None, 32)
        self.character_data = character_data
        self.character_id = character_data.get("character_id", "char_" + uuid.uuid4().hex[:8])
        self.region_id = character_data.get("region_id", "capital_hub")

        self.response_text = "Generating your starting world..."
        self.full_text = ""
        self.visible_text = ""
        self.status = "waiting"
        self.confirm_button = pygame.Rect(100, 500, 200, 40)

        self._start_time = pygame.time.get_ticks()
        self._char_index = 0
        self._last_update = pygame.time.get_ticks()

        self.spinner_chars = ["|", "/", "-", "\\"]
        self._spinner_index = 0

        self.next_screen = None

        self._generate_world_description()

    def _generate_world_description(self):
        try:
            prompt = (
                f"Describe the fantasy world for this character in 250 words or fewer. "
                f"Include a capital city. Write for a player starting a quest.\n\n"
                f"Background: {self.character_data.get('background', '')}"
            )
            res = requests.post(
                "http://localhost:5050/dm_response",
                json={
                    "mode": "start_game",
                    "character_id": self.character_id,
                    "prompt": prompt
                },
                timeout=60
            )
            res.raise_for_status()
            self.full_text = res.json().get("text", "")
            self.status = "complete"
        except requests.RequestException as e:
            print("📜 GPT response text:", e)
            self.status = "error"

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.confirm_button.collidepoint(event.pos) and self.status == "done":
                self.next_screen = RegionMapScreen(self.screen, self.region_id, self.character_id)

    def update(self):
        if self.status == "typing":
            now = pygame.time.get_ticks()
            if now - self._last_update > 30 and self._char_index < len(self.full_text):
                self.visible_text += self.full_text[self._char_index]
                self._char_index += 1
                self._last_update = now
            elif self._char_index >= len(self.full_text):
                self.status = "done"

        if self.status == "waiting":
            if pygame.time.get_ticks() - self._last_update > 150:
                self._spinner_index = (self._spinner_index + 1) % len(self.spinner_chars)
                self._last_update = pygame.time.get_ticks()

    def draw(self):
        self.screen.fill((0, 0, 0))
        y = 40
        self.screen.blit(self.large_font.render("Your Journey Begins", True, (255, 255, 0)), (100, y))
        y += 50

        if self.status == "waiting":
            spinner = self.spinner_chars[self._spinner_index]
            loading = f"{self.response_text} {spinner}"
            self.screen.blit(self.font.render(loading, True, (255, 255, 255)), (100, y))
        else:
            for line in wrap(self.visible_text if self.status != "done" else self.full_text, width=80):
                rendered = self.font.render(line, True, (200, 255, 200))
                self.screen.blit(rendered, (100, y))
                y += 25

            if self.status == "done":
                pygame.draw.rect(self.screen, (0, 200, 100), self.confirm_button)
                self.screen.blit(self.font.render("Enter the World", True, (0, 0, 0)), self.confirm_button.topleft)

        pygame.display.flip()

    def create_new_region():
        try:
            response = requests.post("http://localhost:5000/generate_new_region")
            if response.status_code == 200:
                data = response.json()
                print(f"🌎 New Region Generated: {data['region_id']} with {data['total_tiles']} tiles!")
                return data["region_id"]
            else:
                print("❌ Failed to create new region:", response.text)
                return None
        except Exception as e:
            print(f"Error calling /generate_new_region: {e}")
            return None