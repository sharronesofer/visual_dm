import pygame
from uuid import uuid4
import requests
from textwrap import wrap
import threading
from urllib.request import urlopen
from datetime import datetime
import io
import os
import json
import re
import uuid
from visual_client.screens.start_game import StartGameScreen
from visual_client.ui.components import Tooltip
from visual_client.data.rules_loader import get_races, load_json_file, get_kits
from visual_client.ui.textbox import MultilineTextBox  

FEATS_INDEX_PATH = os.path.join(os.path.dirname(__file__), "../../rules_json/feats_index.json")
with open(FEATS_INDEX_PATH) as f:
    FEATS_INDEX = json.load(f)

print("✅ Loaded FEATS_INDEX keys:", list(FEATS_INDEX.keys())[:5])  # Debug

def ensure_home_region():
    try:
        res = requests.get("http://localhost:5050/global_state")
        data = res.json()
        home_region = data.get("home_region")

        if not home_region:
            print("🌍 No home region found — generating new region...")
            regen = requests.post("http://localhost:5050/generate_new_region")
            if regen.status_code == 200:
                region_id = regen.json()["region_id"]
                requests.post("http://localhost:5050/global_state/update", json={"home_region": region_id})
                return region_id
            else:
                raise Exception("Failed to generate home region")
        else:
            print("✅ Existing home region:", home_region)
            return home_region

    except Exception as e:
        print("❌ Error ensuring home region:", str(e))
        return "capital_hub"

def feat_prereqs_met(name, known_feats, skills, attributes):
    """
    Checks whether a feat is available given current skills, attributes, and known feats.
    Prereqs come from feats_index.json (parsed as strings).
    """
    prereqs = FEATS_INDEX.get(name, {}).get("prerequisites", [])
    print(f"🧠 Checking prereqs for: {name}")

    for line in prereqs:
        # Handle numeric conditions like "Skill >= N" or "Attribute >= N"
        match = re.match(r"(\w+)\s*>=\s*(\d+)", line)
        if match:
            key = match.group(1)
            required_val = int(match.group(2))

            # Pull value from skills or attributes
            if key in skills:
                actual_val = skills[key]
            elif key in attributes:
                actual_val = attributes[key]
            else:
                actual_val = 0  # default fallback

            if actual_val < required_val:
                print(f"   ✖ {name}: {key} = {actual_val} < {required_val}")
                return False
            continue

        # Handle feat prerequisites like "Feat: Sneak Attack"
        elif line.startswith("Feat:"):
            required_feats = [f.strip() for f in line[5:].split(",")]
            for feat in required_feats:
                if feat and feat not in known_feats:
                    print(f"   ✖ {name}: missing required feat '{feat}'")
                    return False
            continue

        # Unknown prereq format (safety fallback)
        else:
            print(f"   ⚠️ Unhandled prereq format: '{line}'")
            continue

    print(f"   ✅ {name}: prerequisites met.")
    return True

def reset_step_state(self):
    # Clear per-step flags that could cause issues across transitions
    self.randomizing_background = False
    self.entering_custom_background = False
    self._gpt_started = False
    self._portrait_started = False
    self.custom_bg_textbox = None  # Added to __init__ for safety


class CharacterCreationScreen:
    def __init__(self, screen):
        self.screen = screen
        self.font = pygame.font.SysFont(None, 24)
        self.large_font = pygame.font.SysFont(None, 28)
        self.character_data = {}
        self.current_step = 0
        self.scroll_offset = 0
        self.scroll_step = 40

        self.skills = {}
        self.attributes = {}
        self.feats = []
        self.feats_max = 7

        self.kits = []
        self.generated_background = ""
        self._gpt_started = False
        self._gpt_thread = None
        self._portrait_started = False
        self.portrait_start_time = None
        self.custom_bg_textbox = None

        self.selected_race = None
        self.selected_feat = None
        self.selected_kit = None

        self.randomizing_background = False
        self.entering_custom_background = False

        self.tooltip = Tooltip(self.font)
        self.confirm_button = pygame.Rect(400, 500, 200, 40)
        self.races = get_races()

        self.reset_step_state()

    def assign_skills(self, skills: dict):
        for skill, rank in skills.items():
            self.skills[skill] = rank

    def reset_step_state(self):
        self.randomizing_background = False
        self.entering_custom_background = False
        self.generated_background = ""
        self._gpt_started = False
        self._portrait_started = False
        self.custom_bg_textbox = None
        self.selected_feat = None
        self.selected_skill = None

    def handle_event(self, event):
        print(f"[EVENT] Step {self.current_step} - {event}")
        handlers = [
            self._handle_race_selection,
            self._handle_attributes_assignment,
            self._handle_skills_selection,
            self._handle_feats_selection,
            self._handle_kit_selection,
            self._handle_basic_info_selection,
            self._handle_background_selection,
            self._handle_summary_screen
        ]
        if self.current_step < len(handlers):
            handlers[self.current_step](event)

    def draw(self):
        if self.current_step == -1 and hasattr(self, "next_screen"):
            self.next_screen.draw()
            return

        step_methods = [
            self.race_selection,
            self.attributes_assignment,
            self.skills_selection,
            self.feats_selection,
            self.kit_selection,
            self.basic_info_selection,
            self.background_selection,
            self.summary_screen
        ]
        if self.current_step < len(step_methods):
            step_methods[self.current_step]()

    def run_portrait_generation_async(self):
        def do_portrait():
            try:
                print("🎨 Starting portrait generation...")

                required_keys = ["character_id", "race", "attributes", "skills", "feats"]
                if not all(k in self.character_data for k in required_keys):
                    print("❌ Character not complete — skipping portrait generation.")
                    self.character_data["portrait_url"] = "Error: Character is incomplete"
                    return

                if "region_id" not in self.character_data:
                    self.character_data["region_id"] = "capital_hub"

                print("🎨 Posting character to backend...")
                requests.post("http://localhost:5050/character/create", json=self.character_data)

                print("🎨 Sending portrait generation request...")
                res = requests.post("http://localhost:5050/generate_portrait", json={
                    "character": self.character_data
                })

                print("🎨 Status:", res.status_code)
                print("🎨 Response:", res.text)

                if res.status_code == 200:
                    self.character_data["portrait_url"] = res.json().get("url", "N/A")
                    # Save again with portrait
                    requests.post("http://localhost:5050/character/create", json=self.character_data)
                else:
                    self.character_data["portrait_url"] = f"Error {res.status_code}: {res.text}"
            except Exception as e:
                self.character_data["portrait_url"] = f"Request failed: {str(e)}"
                print("❌ Portrait generation failed:", e)

        threading.Thread(target=do_portrait).start()

    def draw_progress_bar(self, surface, x, y, width, height, progress, color=(0, 200, 255)):
        pygame.draw.rect(surface, (60, 60, 60), (x, y, width, height))  # background
        fill_width = int(width * progress)
        pygame.draw.rect(surface, color, (x, y, fill_width, height))  # fill
        pygame.draw.rect(surface, (255, 255, 255), (x, y, width, height), 2)  # border

    def run_gpt_background_prompt(self):
        def do_gpt():
            try:
                print("🚀 Calling GPT for background...")
                name = self.character_data.get("name", "")
                race = self.character_data.get("race", "")
                gender = self.character_data.get("gender", "")
                age = self.character_data.get("age", "")

                if not name or not race:
                    self.generated_background = "⚠️ Cannot generate background — name or race missing."
                    print("⚠️ Missing name or race.")
                    return

                attrs = self.character_data.get("attributes", {})
                skills = self.character_data.get("skills", {})
                feats = self.character_data.get("feats", [])

                if "character_id" not in self.character_data:
                    self.character_data["character_id"] = "char_" + uuid.uuid4().hex[:8]

                prompt = (
                    f"Write a fantasy RPG background for a character named {name}.\n"
                    f"Only return the background text. Do not include greetings or the character's name in your output.\n\n"
                    f"Race: {race}\n"
                    f"Gender: {gender}\n"
                    f"Age: {age}\n"
                    f"Attributes: {json.dumps(attrs)}\n"
                    f"Skills: {json.dumps(skills)}\n"
                    f"Feats: {', '.join(feats)}"
                )

                res = requests.post("http://localhost:5050/dm_response", json={
                    "mode": "background_prompt",
                    "character_id": self.character_data["character_id"],
                    "prompt": prompt
                })

                print("📬 GPT Response Status:", res.status_code)
                if res.status_code == 200:
                    try:
                        reply = res.json().get("reply", "No background generated.")
                    except Exception:
                        reply = res.text or "Unparsable GPT response"
                    print("🧠 GPT REPLY:", reply)
                    self.generated_background = reply
                else:
                    self.generated_background = f"Error {res.status_code}: {res.text}"
            except Exception as e:
                self.generated_background = f"Request failed: {str(e)}"
                print("❌ GPT Error:", e)

        if self._gpt_thread and self._gpt_thread.is_alive():
            print("⚠️ GPT thread already running — ignoring new request.")
            return

        self._gpt_thread = threading.Thread(target=do_gpt)
        self._gpt_thread.start()

    def race_selection(self):
        self.screen.fill((0, 0, 0))
        y = 80
        self.screen.blit(self.large_font.render("Choose a Race:", True, (255, 255, 0)), (100, 40))
        for name, desc in self.races:
            rect = pygame.Rect(100, y, 200, 30)
            pygame.draw.rect(self.screen, (50, 50, 150) if name != self.selected_race else (0, 200, 0), rect)
            self.screen.blit(self.font.render(name, True, (255, 255, 255)), rect.topleft)
            y += 40

        if self.selected_race:
            pygame.draw.rect(self.screen, (0, 200, 100), self.confirm_button)
            self.screen.blit(self.font.render("Confirm Race", True, (0, 0, 0)), self.confirm_button.topleft)
            self._draw_race_details(self.selected_race)

    def _handle_race_selection(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()
            y = 80
            for name, _ in self.races:
                rect = pygame.Rect(100, y, 200, 30)
                if rect.collidepoint(mouse):
                    self.selected_race = name
                    return
                y += 40
            if self.selected_race and self.confirm_button.collidepoint(mouse):
                self.character_data["race"] = self.selected_race
                self.character_data["attributes"] = {
                    "STR": 0, "DEX": 0, "CON": 0, "INT": 0, "WIS": 0, "CHA": 0
                }
                self.attr_points_left = 10
                self.current_step += 1
                self.reset_step_state()

    def _draw_race_details(self, race_name):
        data = load_json_file("races.json").get(race_name, {})
        y = 100
        x = 350
        description_lines = wrap(data.get("description", ""), width=50)
        self.screen.blit(self.font.render("Description:", True, (255, 255, 255)), (x, y))
        y += 20
        for line in description_lines:
            self.screen.blit(self.font.render(line, True, (200, 200, 200)), (x, y))
            y += 20

        # Attribute Modifiers
        mods = data.get("ability_modifiers", {})
        if mods:
            y += 10
            mods_str = "Attribute Modifiers: " + ", ".join(f"{k} {v:+}" for k, v in mods.items())
            for line in wrap(mods_str, 50):
                self.screen.blit(self.font.render(line, True, (200, 255, 200)), (x, y))
                y += 20

        # Skill Bonuses
        skills = data.get("skill_bonuses", {})
        if skills:
            y += 10
            skill_str = "Skill Bonuses: " + ", ".join(f"{k} +{v}" for k, v in skills.items())
            for line in wrap(skill_str, 50):
                self.screen.blit(self.font.render(line, True, (200, 255, 255)), (x, y))
                y += 20

        # Special Traits
        traits = data.get("special_traits", [])
        if traits:
            y += 10
            trait_strs = []
            for trait in traits:
                if trait["type"] == "save_bonus":
                    amount = trait.get("amount", "")
                    vs = trait.get("vs", "").replace("_", " ").title()
                    trait_strs.append(f"+{amount} vs {vs} saves")
                elif trait["type"] == "vision":
                    desc = trait.get("effect", "").replace("_", " ").title()
                    trait_strs.append(f"{desc} vision")
                elif trait["type"] == "immunity":
                    effect = trait.get("effect", "").replace("_", " ").title()
                    trait_strs.append(f"Immunity to {effect}")
                else:
                    desc = trait.get("effect", "") or trait.get("detail", "") or trait.get("type", "")
                    trait_strs.append(desc.replace("_", " ").title())

            self.screen.blit(self.font.render("Special Traits:", True, (255, 255, 180)), (x, y))
            y += 20
            for line in wrap(", ".join(trait_strs), 50):
                self.screen.blit(self.font.render(line, True, (255, 255, 180)), (x, y))
                y += 20

    def attributes_assignment(self):
        self.screen.fill((0, 0, 0))
        base_attrs = self.character_data.setdefault("attributes", {
            "STR": 0, "DEX": 0, "CON": 0, "INT": 0, "WIS": 0, "CHA": 0
        })

        race_name = self.character_data.get("race")
        races_json = load_json_file("races.json")
        race_mods = races_json.get(race_name, {}).get("ability_modifiers", {}) if race_name else {}

        if not hasattr(self, "attr_points_left"):
            self.attr_points_left = 10

        self.attr_rects = {}
        y = 80
        self.screen.blit(self.large_font.render("Distribute Attribute Points", True, (255, 255, 0)), (100, 30))

        for stat in base_attrs:
            val = base_attrs[stat]
            mod = race_mods.get(stat, 0)
            final = val + mod
            display = f"{stat}: {val} {'+' if mod >= 0 else '-'} {abs(mod)} = {final}"
            self.screen.blit(self.font.render(display, True, (255, 255, 255)), (100, y))

            plus = pygame.Rect(320, y, 30, 30)
            minus = pygame.Rect(360, y, 30, 30)
            pygame.draw.rect(self.screen, (0, 255, 0), plus)
            pygame.draw.rect(self.screen, (255, 0, 0), minus)
            self.screen.blit(self.font.render("+", True, (0, 0, 0)), plus.topleft)
            self.screen.blit(self.font.render("-", True, (0, 0, 0)), minus.topleft)

            self.attr_rects[stat] = {"plus": plus, "minus": minus}
            y += 50

        self.screen.blit(self.font.render(f"Points Left: {self.attr_points_left}", True, (255, 255, 0)), (100, y))
        if self.attr_points_left == 0:
            confirm_btn = pygame.Rect(100, y + 50, 200, 30)
            pygame.draw.rect(self.screen, (0, 128, 255), confirm_btn)
            self.screen.blit(self.font.render("Confirm Attributes", True, (255, 255, 255)), confirm_btn.topleft)
            self.confirm_attr_rect = confirm_btn

    def _handle_attributes_assignment(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            base_attrs = self.character_data["attributes"]
            race_name = self.character_data["race"]
            races_json = load_json_file("races.json")
            race_mods = races_json.get(race_name, {}).get("ability_modifiers", {}) if race_name else {}
            mouse = pygame.mouse.get_pos()

            for stat, rects in self.attr_rects.items():
                val = base_attrs[stat]
                # Increase logic
                if rects["plus"].collidepoint(mouse):
                    if val < 5:
                        cost = 2 if val == 4 else 1
                        if self.attr_points_left >= cost:
                            base_attrs[stat] += 1
                            self.attr_points_left -= cost
                # Decrease logic
                elif rects["minus"].collidepoint(mouse):
                    if val > -3:
                        refund = 2 if val == 5 else 1
                        base_attrs[stat] -= 1
                        self.attr_points_left += refund

            if self.attr_points_left == 0 and hasattr(self, "confirm_attr_rect") and self.confirm_attr_rect.collidepoint(mouse):
                final = {stat: base_attrs[stat] + race_mods.get(stat, 0) for stat in base_attrs}
                self.character_data["attributes"] = final
                self.current_step += 1
                self.reset_step_state()

    def skills_selection(self):
        self.screen.fill((0, 0, 0))
        skills_json = load_json_file("skills.json")
        skills_data = [(name, entry["description"], entry["ability"]) for name, entry in skills_json.items()]

        # Ensure all skills are initialized
        expected_skills = [name for name, *_ in skills_data]
        if not self.skills or set(self.skills.keys()) != set(expected_skills):
            self.skills = {name: 0 for name in expected_skills}
            int_mod = self.character_data.get("attributes", {}).get("INT", 0)
            self.skill_points_total = 12 + max(int_mod, 0)
            self.skill_points_left = self.skill_points_total
            self.selected_skill = None

        self.skill_rects = {}

        y = 80
        for skill, desc, attr in skills_data:
            cap = 4
            cur = self.skills.get(skill, 0)
            mod = self.character_data["attributes"].get(attr, 0)
            final = cur + mod
            label = f"{skill}: {cur} {'+' if mod >= 0 else '-'} {abs(mod)} {attr} = {final}"

            rect = pygame.Rect(100, y, 260, 30)
            pygame.draw.rect(self.screen, (50, 50, 150), rect)
            self.screen.blit(self.font.render(label, True, (255, 255, 255)), rect.topleft)

            plus = pygame.Rect(370, y, 30, 30)
            minus = pygame.Rect(410, y, 30, 30)
            pygame.draw.rect(self.screen, (0, 255, 0), plus)
            pygame.draw.rect(self.screen, (255, 0, 0), minus)
            self.screen.blit(self.font.render("+", True, (0, 0, 0)), plus.topleft)
            self.screen.blit(self.font.render("-", True, (0, 0, 0)), minus.topleft)

            self.skill_rects[skill] = {"main": rect, "plus": plus, "minus": minus}
            y += 40

        self.screen.blit(self.large_font.render(f"Distribute Skill Points ({self.skill_points_left} left)", True, (255, 255, 0)), (100, 30))

        if self.skill_points_left == 0:
            confirm_btn = pygame.Rect(800, 720, 200, 40)
            pygame.draw.rect(self.screen, (0, 200, 100), confirm_btn)
            self.screen.blit(self.font.render("Confirm Skills", True, (0, 0, 0)), confirm_btn.topleft)
            self.confirm_skills_rect = confirm_btn

        if self.selected_skill:
            desc = next((d for s, d, _ in skills_data if s == self.selected_skill), "")
            y = 80
            x = 600
            self.screen.blit(self.large_font.render(self.selected_skill, True, (255, 255, 255)), (x, y))
            y += 30
            for line in wrap(desc, 40):
                self.screen.blit(self.font.render(line, True, (200, 255, 200)), (x, y))
                y += 20

    def _handle_skills_selection(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()
            for skill, btns in self.skill_rects.items():
                cap = 4
                if btns["plus"].collidepoint(mouse) and self.skill_points_left > 0 and self.skills[skill] < cap:
                    self.skills[skill] += 1
                    self.skill_points_left -= 1
                    self.selected_skill = skill
                elif btns["minus"].collidepoint(mouse) and self.skills[skill] > 0:
                    self.skills[skill] -= 1
                    self.skill_points_left += 1
                    self.selected_skill = skill
                elif btns["main"].collidepoint(mouse):
                    self.selected_skill = skill

            if self.skill_points_left == 0 and hasattr(self, "confirm_skills_rect") and self.confirm_skills_rect.collidepoint(mouse):
                self.character_data["skills"] = self.skills
                self.current_step += 1
                self.reset_step_state()
                
    def feats_selection(self):
        from collections import defaultdict
        self.screen.fill((0, 0, 0))

        feats_data = load_json_file("feats.json")
        if isinstance(feats_data, list):
            feats_data = {feat["name"]: feat for feat in feats_data if "name" in feat}

        if not hasattr(self, "feats"):
            self.feats = []
            self.selected_feat = None
            self.feat_rects = {}
            self.scroll_offset = 0
            self.scroll_step = 40
            self.feats_max = 7

        raw_skills = self.character_data.get("skills", {}).copy()
        attributes = self.character_data.get("attributes", {}).copy()

        all_skills = [
            "Acrobatics", "Athletics", "Arcane", "Divine", "Occult", "Stealth",
            "Insight", "Nature", "Survival", "Medicine", "Perform", "Deception",
            "Persuasion", "Social"
        ]
        all_attributes = ["STR", "DEX", "CON", "INT", "WIS", "CHA"]

        for skill in all_skills:
            if skill not in raw_skills:
                raw_skills[skill] = 0
        for attr in all_attributes:
            if attr not in attributes:
                attributes[attr] = 0

        # Apply attribute modifiers to skills
        skills = raw_skills.copy()
        skills_json = load_json_file("skills.json")
        for name, entry in skills_json.items():
            attr = entry.get("ability")
            if name in skills and attr in attributes:
                skills[name] += attributes[attr]

        print("🧠 Checking feats with skills:", skills)
        print("🧠 Attributes:", attributes)

        # Filter feats
        valid_feats = {
            name: data
            for name, data in feats_data.items()
            if feat_prereqs_met(name, self.feats, skills, attributes)
        }

        # Group valid feats by category
        grouped_feats = defaultdict(list)
        for name, data in valid_feats.items():
            category = data.get("category", "General")
            grouped_feats[category].append((name, data.get("description", ""), data))

        self.feat_rects = {}

        self.screen.blit(self.large_font.render("Choose Feats", True, (255, 255, 0)), (100, 30))
        self.screen.blit(self.font.render(f"Selected: {len(self.feats)} / {self.feats_max}", True, (255, 255, 255)), (100, 80))

        box_rect = pygame.Rect(90, 150, 340, 500)
        pygame.draw.rect(self.screen, (80, 80, 80), box_rect)
        clip_surface = self.screen.subsurface(box_rect)
        clip_surface.fill((80, 80, 80))

        y = -self.scroll_offset
        for category in sorted(grouped_feats):
            clip_surface.blit(self.font.render(f"[{category.upper()}]", True, (255, 255, 100)), (10, y))
            y += 30
            for feat, desc, data in grouped_feats[category]:
                rect = pygame.Rect(10, y, 300, 30)
                pygame.draw.rect(clip_surface, (0, 200, 0) if feat in self.feats else (100, 0, 100), rect)
                clip_surface.blit(self.font.render(feat, True, (255, 255, 255)), rect.topleft)
                self.feat_rects[feat] = pygame.Rect(box_rect.x + rect.x, box_rect.y + rect.y, rect.width, rect.height)
                y += 40

        if len(self.feats) == self.feats_max:
            confirm_btn = pygame.Rect(800, 720, 200, 40)
            pygame.draw.rect(self.screen, (0, 200, 100), confirm_btn)
            self.screen.blit(self.font.render("Confirm Feats", True, (0, 0, 0)), confirm_btn.topleft)
            self.confirm_feats_rect = confirm_btn

        if self.selected_feat:
            x = 500
            y = 80
            selected_data = valid_feats.get(self.selected_feat, {})
            self.screen.blit(self.large_font.render(self.selected_feat, True, (255, 255, 255)), (x, y))
            y += 30
            for line in wrap(selected_data.get("description", ""), 40):
                self.screen.blit(self.font.render(line, True, (200, 255, 200)), (x, y))
                y += 20

    def _handle_feats_selection(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button != 1:  # prevent click on scroll gestures
                return
            mouse = pygame.mouse.get_pos()
            for feat, rect in self.feat_rects.items():
                if rect.collidepoint(mouse):
                    if feat in self.feats:
                        self.feats.remove(feat)
                    elif len(self.feats) < self.feats_max:
                        self.feats.append(feat)
                    self.selected_feat = feat
                    return
            if len(self.feats) == self.feats_max and hasattr(self, "confirm_feats_rect") and self.confirm_feats_rect.collidepoint(mouse):
                self.character_data["feats"] = self.feats
                self.current_step += 1
                self.reset_step_state()

        elif event.type == pygame.MOUSEWHEEL:
            self.scroll_offset -= event.y * self.scroll_step
            self.scroll_offset = max(0, self.scroll_offset)
    
    def background_selection(self):
        self.screen.fill((0, 0, 0))

        if self.custom_bg_textbox is None:
            self.custom_bg_textbox = MultilineTextBox((100, 300, 800, 150), self.font)

        self.screen.blit(self.large_font.render("Choose Background Method", True, (255, 255, 0)), (100, 30))

        self.write_own_rect = pygame.Rect(100, 100, 300, 40)
        self.rand_gen_rect = pygame.Rect(100, 160, 300, 40)

        pygame.draw.rect(self.screen, (0, 100, 200), self.write_own_rect)
        pygame.draw.rect(self.screen, (100, 0, 200), self.rand_gen_rect)
        self.screen.blit(self.font.render("Write Your Own", True, (255, 255, 255)), self.write_own_rect.topleft)
        self.screen.blit(self.font.render("Generate Background", True, (255, 255, 255)), self.rand_gen_rect.topleft)

        if self.entering_custom_background:
            self.screen.blit(self.font.render("Enter your background below:", True, (200, 200, 255)), (100, 260))
            self.custom_bg_textbox.draw(self.screen)
            self.confirm_bg_rect = pygame.Rect(800, 720, 200, 40)
            pygame.draw.rect(self.screen, (0, 200, 100), self.confirm_bg_rect)
            self.screen.blit(self.font.render("Confirm Background", True, (0, 0, 0)), self.confirm_bg_rect.topleft)

        elif self.randomizing_background:
            x, y = 100, 230
            self.screen.blit(self.font.render("Generated Background:", True, (255, 255, 0)), (x, y))
            y += 30
            print("🎬 Background displayed:", self.generated_background)

            if not self._gpt_started:
                self.generate_bg_rect = pygame.Rect(100, y + 10, 300, 40)
                pygame.draw.rect(self.screen, (0, 100, 200), self.generate_bg_rect)
                self.screen.blit(self.font.render("Generate Background", True, (255, 255, 255)), self.generate_bg_rect.topleft)

            elif self.generated_background == "":
                self.screen.blit(self.font.render("⏳ Generating background, please wait...", True, (255, 255, 255)), (x, y))
                if not hasattr(self, "gpt_start_time"):
                    self.gpt_start_time = pygame.time.get_ticks()
                elapsed = (pygame.time.get_ticks() - self.gpt_start_time) % 3000
                progress = abs((elapsed / 1500.0) - 1)
                self.draw_progress_bar(self.screen, x, y + 30, 400, 20, progress)

            else:
                for line in wrap(self.generated_background, 80):
                    self.screen.blit(self.font.render(line, True, (200, 255, 200)), (x, y))
                    y += 25

                if not self.generated_background.startswith("Error"):
                    self.confirm_bg_rect = pygame.Rect(800, 720, 200, 40)
                    pygame.draw.rect(self.screen, (0, 200, 100), self.confirm_bg_rect)
                    self.screen.blit(self.font.render("Accept This", True, (0, 0, 0)), self.confirm_bg_rect.topleft)

    def _handle_background_selection(self, event):
        if self.custom_bg_textbox is None:
            self.custom_bg_textbox = MultilineTextBox((100, 300, 800, 150), self.font)

        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()

            if self.write_own_rect.collidepoint(mouse):
                self.entering_custom_background = True
                self.randomizing_background = False
                self.custom_bg_textbox.active = True
                return

            if self.rand_gen_rect.collidepoint(mouse):
                self.randomizing_background = True
                self.entering_custom_background = False
                return

            if self.entering_custom_background:
                if self.custom_bg_textbox.rect.collidepoint(mouse):
                    self.custom_bg_textbox.active = True
                if hasattr(self, "confirm_bg_rect") and self.confirm_bg_rect.collidepoint(mouse):
                    self.character_data["background"] = self.custom_bg_textbox.get_text()
                    self.current_step += 1
                    self.reset_step_state()
                return

            if self.randomizing_background:
                if not self._gpt_started and hasattr(self, "generate_bg_rect") and self.generate_bg_rect.collidepoint(mouse):
                    self._gpt_started = True
                    self.gpt_start_time = pygame.time.get_ticks()
                    self.run_gpt_background_prompt()
                    print("🧠 GPT background triggered")
                    return

                if hasattr(self, "confirm_bg_rect") and self.confirm_bg_rect.collidepoint(mouse):
                    self.character_data["background"] = self.generated_background
                    self.current_step += 1
                    self.reset_step_state()
                    return

        elif event.type == pygame.KEYDOWN and self.entering_custom_background:
            self.custom_bg_textbox.handle_event(event)

    def kit_selection(self):
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.large_font.render("Choose a Starter Kit", True, (255, 255, 0)), (100, 30))

        if not hasattr(self, "kits") or not self.kits:
            self.kits = get_kits()

        if not hasattr(self, "selected_kit"):
            self.selected_kit = None

        self.kit_rects = {}  # Reset each frame

        y = 80
        for kit, desc in self.kits:
            rect = pygame.Rect(100, y, 300, 30)
            pygame.draw.rect(self.screen, (64, 128, 64) if kit != self.selected_kit else (0, 200, 0), rect)
            self.screen.blit(self.font.render(kit, True, (255, 255, 255)), rect.topleft)
            self.kit_rects[kit] = rect
            y += 40

        if self.selected_kit:
            confirm_btn = pygame.Rect(800, 720, 200, 40)
            pygame.draw.rect(self.screen, (0, 200, 100), confirm_btn)
            self.screen.blit(self.font.render("Confirm Kit", True, (0, 0, 0)), confirm_btn.topleft)
            self.confirm_kit_rect = confirm_btn

            # Description pane
            x = 500
            y = 80
            self.screen.blit(self.large_font.render(self.selected_kit, True, (255, 255, 255)), (x, y))
            y += 30
            selected_desc = next((d for k, d in self.kits if k == self.selected_kit), "")
            for line in wrap(selected_desc, 40):
                self.screen.blit(self.font.render(line, True, (200, 255, 200)), (x, y))
                y += 20


    def _handle_kit_selection(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()

            for kit, rect in self.kit_rects.items():
                if rect.collidepoint(mouse):
                    self.selected_kit = kit
                    return

            if self.selected_kit and hasattr(self, "confirm_kit_rect") and self.confirm_kit_rect.collidepoint(mouse):
                self.character_data["kit"] = self.selected_kit
                self.current_step += 1
                self.reset_step_state()

    def basic_info_selection(self):
        self.screen.fill((0, 0, 0))
        self.screen.blit(self.large_font.render("Enter Character Info", True, (255, 255, 0)), (100, 30))

        if not hasattr(self, "info_inputs"):
            self.info_inputs = {
                "name": MultilineTextBox((100, 100, 400, 30), self.font),
            }
            self.gender_options = ["Male", "Female", "Non-Gendered", "Object", "Other"]
            self.selected_gender = self.gender_options[0]
            self.gender_rects = [pygame.Rect(100, 160 + i * 35, 200, 30) for i in range(len(self.gender_options))]

            self.age_options = ["Teen", "Young Adult", "Middle Aged", "Older Adult", "Elder", "Ancient"]
            self.selected_age = self.age_options[2]
            self.age_rects = [pygame.Rect(350, 160 + i * 35, 200, 30) for i in range(len(self.age_options))]

            self.alignments = [
                "Lawful Good", "Neutral Good", "Chaotic Good",
                "Lawful Neutral", "True Neutral", "Chaotic Neutral",
                "Lawful Evil", "Neutral Evil", "Chaotic Evil"
            ]
            self.selected_alignment = self.alignments[0]
            self.alignment_rects = []
            grid_x = 100
            grid_y = 400
            spacing = 220
            for i, alignment in enumerate(self.alignments):
                row = i // 3
                col = i % 3
                rect = pygame.Rect(grid_x + col * spacing, grid_y + row * 40, 200, 30)
                self.alignment_rects.append(rect)

        # Draw Name input
        y = 100
        self.screen.blit(self.font.render("Name:", True, (255, 255, 255)), (100, y - 25))
        self.info_inputs["name"].draw(self.screen)

        # Gender
        self.screen.blit(self.font.render("Gender:", True, (255, 255, 255)), (100, 130))
        for i, gender in enumerate(self.gender_options):
            rect = self.gender_rects[i]
            pygame.draw.rect(self.screen, (0, 200, 100) if gender == self.selected_gender else (100, 100, 100), rect)
            self.screen.blit(self.font.render(gender, True, (0, 0, 0)), rect.topleft)

        # Age
        self.screen.blit(self.font.render("Age:", True, (255, 255, 255)), (350, 130))
        for i, age in enumerate(self.age_options):
            rect = self.age_rects[i]
            pygame.draw.rect(self.screen, (0, 200, 100) if age == self.selected_age else (100, 100, 100), rect)
            self.screen.blit(self.font.render(age, True, (0, 0, 0)), rect.topleft)

        # Alignment
        self.screen.blit(self.font.render("Alignment:", True, (255, 255, 255)), (100, 370))
        for i, alignment in enumerate(self.alignments):
            rect = self.alignment_rects[i]
            pygame.draw.rect(self.screen, (0, 200, 100) if alignment == self.selected_alignment else (100, 100, 100), rect)
            self.screen.blit(self.font.render(alignment, True, (0, 0, 0)), rect.topleft)

        # Confirm
        confirm_btn = pygame.Rect(540, 700, 200, 40)
        pygame.draw.rect(self.screen, (0, 200, 100), confirm_btn)
        self.screen.blit(self.font.render("Confirm Info", True, (0, 0, 0)), confirm_btn.topleft)
        self.confirm_info_rect = confirm_btn

    def _handle_basic_info_selection(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse = pygame.mouse.get_pos()
            for box in self.info_inputs.values():
                box.active = box.rect.collidepoint(mouse)
            for i, rect in enumerate(self.gender_rects):
                if rect.collidepoint(mouse):
                    self.selected_gender = self.gender_options[i]
            for i, rect in enumerate(self.age_rects):
                if rect.collidepoint(mouse):
                    self.selected_age = self.age_options[i]
            for i, rect in enumerate(self.alignment_rects):
                if rect.collidepoint(mouse):
                    self.selected_alignment = self.alignments[i]
            if hasattr(self, "confirm_info_rect") and self.confirm_info_rect.collidepoint(mouse):
                for key, box in self.info_inputs.items():
                    self.character_data[key] = box.get_text()
                self.character_data["gender"] = self.selected_gender
                self.character_data["age"] = self.selected_age
                self.character_data["alignment"] = self.selected_alignment
                name = self.info_inputs["name"].get_text()
                if len(name.strip()) < 3:
                    print("⚠️ Name must be at least 3 characters.")
                    return  # don’t proceed

                self.current_step += 1
                self.reset_step_state()
            if event.type == pygame.MOUSEBUTTONDOWN and event.button != 1:
                return 
        elif event.type == pygame.KEYDOWN:
            for box in self.info_inputs.values():
                box.handle_event(event)

    def summary_screen(self):
        self.screen.fill((0, 0, 0))
        y = 40
        self.screen.blit(self.large_font.render("Summary", True, (255, 255, 255)), (100, y))
        y += 40

        for key, value in self.character_data.items():
            display = f"{key}: {value}"
            self.screen.blit(self.font.render(display, True, (255, 255, 255)), (100, y))
            y += 25

        # === Buttons ===
        self.save_button_rect = pygame.Rect(100, 380, 200, 30)
        self.restart_button_rect = pygame.Rect(100, 430, 200, 30)

        pygame.draw.rect(self.screen, (0, 200, 100), self.save_button_rect)
        self.screen.blit(self.font.render("Save & Begin", True, (0, 0, 0)), self.save_button_rect.topleft)

        pygame.draw.rect(self.screen, (200, 100, 0), self.restart_button_rect)
        self.screen.blit(self.font.render("Restart", True, (0, 0, 0)), self.restart_button_rect.topleft)

        # === Portrait Rendering ===
        portrait_url = self.character_data.get("portrait_url", "")
        portrait_rect = pygame.Rect(520, 80, 256, 256)

        if portrait_url and not portrait_url.startswith("Error"):
            if not hasattr(self, "_portrait_image"):
                try:
                    from urllib.request import urlopen
                    import io
                    raw_img = urlopen(portrait_url).read()
                    img_surface = pygame.image.load(io.BytesIO(raw_img)).convert_alpha()
                    self._portrait_image = pygame.transform.scale(img_surface, (256, 256))
                except Exception as e:
                    self._portrait_image = None
                    print("Portrait image load failed:", e)

            if hasattr(self, "_portrait_image") and self._portrait_image:
                self.screen.blit(self._portrait_image, portrait_rect.topleft)
                self.screen.blit(self.font.render("🖼️ Portrait Loaded", True, (200, 255, 200)), (portrait_rect.x, portrait_rect.bottom + 10))

        elif portrait_url.startswith("Error"):
            self.screen.blit(self.font.render("❌ Portrait Failed", True, (255, 100, 100)), (520, 80))
            for line in wrap(portrait_url, 40):
                y += 25
                self.screen.blit(self.font.render(line, True, (255, 100, 100)), (520, y))

    def _handle_summary_screen(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN:
            return

        mouse = pygame.mouse.get_pos()

        save_button = pygame.Rect(100, 380, 200, 30)
        restart_button = pygame.Rect(100, 430, 200, 30)

        if save_button.collidepoint(mouse):
            print("✅ Save & Begin clicked")

            # 🛠 Merge live session data into character_data
            self.character_data["skills"] = self.skills
            self.character_data["attributes"] = self.attributes
            self.character_data["feats"] = self.feats
            self.character_data["kit"] = self.selected_kit

            if "character_id" not in self.character_data:
                self.character_data["character_id"] = "char_" + uuid.uuid4().hex[:8]

            try:
                # 🧠 Ensure home region exists
                self.character_data["region_id"] = self.ensure_home_region()

                print("📤 Final character payload:", self.character_data)
                res = requests.post("http://localhost:5050/character/create", json=self.character_data)
                if res.status_code != 200:
                    print(f"❌ Failed to save character: {res.status_code} {res.text}")

                # Background arc
                background = self.character_data.get("background", "")
                arc_prompt = f"Player begins their journey. Background: '{background}'"
                arc_res = requests.post(f"http://localhost:5050/arc/{self.character_data['character_id']}", json={"event": arc_prompt})
                if arc_res.status_code != 200:
                    print(f"❌ Failed to create arc: {arc_res.status_code} {arc_res.text}")

                # Generate portrait
                portrait_res = requests.post("http://localhost:5050/generate_portrait", json={
                    "character": self.character_data
                })
                if portrait_res.status_code == 200:
                    self.character_data["portrait_url"] = portrait_res.json().get("url", "N/A")
                else:
                    self.character_data["portrait_url"] = f"Error {portrait_res.status_code}: {portrait_res.text}"

            except Exception as e:
                print("❌ Error during save:", e)

            from visual_client.screens.start_game import StartGameScreen
            self.next_screen = StartGameScreen(self.screen, self.character_data)
            self.current_step = -1
            return

        elif restart_button.collidepoint(mouse):
            print("🔁 Restart clicked")
            self.character_data = {}
            self.current_step = 0
            self.reset_step_state()

    def update(self):
        if self.randomizing_background and hasattr(self, "generated_background") and self.generated_background:
            now = pygame.time.get_ticks()
            if not hasattr(self, "gpt_index"):
                self.gpt_index = 0
                self.gpt_tick = now
                self.generated_background_visible = ""
            if now - self.gpt_tick > 30 and self.gpt_index < len(self.generated_background):
                self.generated_background_visible += self.generated_background[self.gpt_index]
                self.gpt_index += 1
                self.gpt_tick = now

    def draw_generated_background(self, surface):
        if hasattr(self, "generated_background_visible"):
            lines = self.generated_background_visible.split("\n")
            y = 230
            for line in lines:
                text_surface = self.font.render(line, True, (200, 255, 200))
                surface.blit(text_surface, (100, y))
                y += 25
                self.screen.blit(self.font.render(line, True, (255, 100, 100)), (520, y))

    def begin_game(character_id):
        # 🔥 Send POST to start_game endpoint
        response = requests.post(f"{API_URL}/start_game/{character_id}")

        if response.status_code == 200:
            game_data = response.json()

            character = game_data["character"]
            region_tiles = game_data["region_tiles"]
            starting_tile = game_data["starting_tile_info"]

            # Now load your UI!
            load_region_map(region_tiles)
            load_character_state(character)
            move_player_to(starting_tile)

        else:
            print("Error:", response.json())